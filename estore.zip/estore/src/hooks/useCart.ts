import { useState, useEffect } from 'react';
import { Product, CartItem } from '../types';

export const useCart = (showNotification: (m: string, t?: 'success' | 'error' | 'info') => void) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [itemToRemove, setItemToRemove] = useState<string | null>(null);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  // Load cart from localStorage
  useEffect(() => {
    const savedCart = localStorage.getItem('shopping_cart');
    if (savedCart && savedCart !== "undefined") {
      try {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error('Failed to parse cart', e);
        localStorage.removeItem('shopping_cart');
      }
    }
  }, []);

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem('shopping_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product, selectedVariants?: Record<string, string>) => {
    if (product.isOutOfStock || (product.stock !== undefined && product.stock <= 0)) {
      showNotification("This product is out of stock.", "error");
      return;
    }
    setCart(prev => {
      const variantString = selectedVariants ? JSON.stringify(selectedVariants) : '';
      const existing = prev.find(item => 
        item.id === product.id && 
        (item.selectedVariants ? JSON.stringify(item.selectedVariants) : '') === variantString
      );

      if (existing) {
        const nextQty = existing.quantity + 1;
        
        // Check Stock Limit
        if (product.stock !== undefined && nextQty > product.stock) {
          showNotification("Limited stock available. Cannot add more than available stock.", "error");
          return prev;
        }

        // Check Order Limit
        if (product.orderLimit && product.orderLimit > 0 && nextQty > product.orderLimit) {
          return prev;
        }

        return prev.map(item => 
          (item.id === product.id && (item.selectedVariants ? JSON.stringify(item.selectedVariants) : '') === variantString) 
            ? { ...item, quantity: nextQty } 
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, selectedVariants }];
    });
  };

  const updateQuantity = (id: string, delta: number, selectedVariants?: Record<string, string>) => {
    const variantString = selectedVariants ? JSON.stringify(selectedVariants) : '';
    setCart(prev => prev.map(item => {
      const itemVariantString = item.selectedVariants ? JSON.stringify(item.selectedVariants) : '';
      if (item.id === id && itemVariantString === variantString) {
        const newQty = Math.max(1, item.quantity + delta);
        
        // Check Stock Limit
        if (delta > 0 && item.stock !== undefined && newQty > item.stock) {
          showNotification("Limited stock available. Cannot add more than available stock.", "error");
          return item;
        }

        // Check Order Limit
        if (item.orderLimit && item.orderLimit > 0 && newQty > item.orderLimit && delta > 0) {
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeItem = (id: string, selectedVariants?: Record<string, string>) => {
    setItemToRemove(JSON.stringify({ id, selectedVariants }));
    setIsConfirmModalOpen(true);
  };

  const handleConfirmRemove = () => {
    if (itemToRemove) {
      const { id, selectedVariants } = JSON.parse(itemToRemove);
      const variantString = selectedVariants ? JSON.stringify(selectedVariants) : '';
      setCart(prev => prev.filter(item => {
        const itemVariantString = item.selectedVariants ? JSON.stringify(item.selectedVariants) : '';
        return !(item.id === id && itemVariantString === variantString);
      }));
      setItemToRemove(null);
      setIsConfirmModalOpen(false);
    }
  };

  const clearCart = () => setCart([]);

  return {
    cart,
    setCart,
    isCartOpen,
    setIsCartOpen,
    itemToRemove,
    setItemToRemove,
    isConfirmModalOpen,
    setIsConfirmModalOpen,
    addToCart,
    updateQuantity,
    removeItem,
    handleConfirmRemove,
    clearCart
  };
};
