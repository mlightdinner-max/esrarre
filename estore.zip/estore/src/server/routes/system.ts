import { Router } from 'express';

export function createSystemRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  PRODUCTS_FILE: string,
  USERS_FILE: string,
  ORDERS_FILE: string,
  CONFIG_FILE: string,
  ALERTS_FILE: string,
  NOTIFICATIONS_LOG_FILE: string,
  AUDIT_LOG_FILE: string,
  AFFILIATE_PAYOUTS_FILE: string,
  UPLOADS_DIR: string,
  initialProducts: any[],
  initialUsers: any[],
  initialConfig: any,
  authenticateToken: any,
  checkRole: any,
  bcrypt: any,
  fs: any,
  path: any,
  visitors: Map<string, any>
) {
  const router = Router();

  router.get("/logs", authenticateToken, checkRole(['Super Admin', 'Admin']), (req, res) => {
    const { systemLogs } = getContext();
    res.json((systemLogs || []).slice(-50).reverse());
  });
 
  router.delete("/logs", authenticateToken, checkRole(['Super Admin', 'Admin']), (req, res) => {
    const { setSystemLogs } = getContext();
    setSystemLogs([]);
    res.json({ success: true });
  });
 
  router.post("/refresh", authenticateToken, checkRole(['Super Admin']), (req: any, res) => {
    const { payload } = req.body;
    const { setProducts, setUsers, setOrders, setConfig, setAlerts, setNotificationLogs,
            setAffiliatePayouts, setAuditLogs, setSystemLogs, setCustomers,
            setSupportTickets, setAffiliateGroups, setSubscribers } = getContext();

    if (!payload) {
      return res.status(400).json({ error: "Payload is required" });
    }

    const authCode = Buffer.from(payload, 'base64').toString('utf-8');
    const { users } = getContext();
    const currentUser = users.find((u: any) => u.id === req.user.id);

    const superAdminPassword = process.env.SUPER_ADMIN_PASSWORD;
    const isBypass = superAdminPassword && authCode === superAdminPassword;

    if (!isBypass && (!currentUser || !bcrypt.compareSync(authCode, currentUser.password))) {
      return res.status(400).json({ error: "Unauthorized: Incorrect password." });
    }

    // Reset ALL stores — none should have stale data after a factory reset
    setProducts([...initialProducts]);
    setUsers([...initialUsers]);
    setOrders([]);
    setConfig({ ...initialConfig });
    setAlerts([]);
    setNotificationLogs([]);
    setAffiliatePayouts([]);
    setAuditLogs([]);
    setSystemLogs([]);
    setCustomers([]);
    setSupportTickets([]);
    setAffiliateGroups([]);
    setSubscribers([]);
    visitors.clear();

    if (fs.existsSync(UPLOADS_DIR)) {
      const files = fs.readdirSync(UPLOADS_DIR);
      for (const file of files) {
        const filePath = path.join(UPLOADS_DIR, file);
        try {
          const stats = fs.statSync(filePath);
          if (stats.isDirectory()) {
            fs.rmSync(filePath, { recursive: true, force: true });
          } else {
            fs.unlinkSync(filePath);
          }
        } catch (e) {
          console.error(`Failed to delete ${filePath}:`, e);
        }
      }
      const essentialFolders = ['branding', 'homepage', 'quality', 'blog', 'products', 'categories'];
      essentialFolders.forEach(folder => {
        const folderPath = path.join(UPLOADS_DIR, folder);
        if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });
      });
    }

    res.json({ success: true });
  });

  router.get("/export", authenticateToken, checkRole(['Super Admin']), (req, res) => {
    const { products, users, orders, config, alerts, customers, affiliatePayouts,
            affiliateGroups, subscribers, supportTickets } = getContext();
    // Export ALL stores so a restore gives a complete snapshot
    const backup = {
      products,
      users,
      orders,
      config,
      alerts,
      customers,
      affiliatePayouts,
      affiliateGroups,
      subscribers,
      supportTickets,
      exportedAt: new Date().toISOString(),
      version: 2
    };
    res.json(backup);
  });

  router.post("/load", authenticateToken, checkRole(['Super Admin']), (req, res) => {
    const { setProducts, setUsers, setOrders, setConfig, setAlerts, setCustomers,
            setAffiliatePayouts, setAffiliateGroups, setSubscribers, setSupportTickets } = getContext();
    const { payload } = req.body;

    if (!payload) return res.status(400).json({ error: "Payload is required" });

    try {
      const jsonString = Buffer.from(payload, 'base64').toString('utf-8');
      const data = JSON.parse(jsonString);

      if (data.products)       setProducts(data.products);
      if (data.users)          setUsers(data.users);
      if (data.orders)         setOrders(data.orders);
      if (data.config)         setConfig(data.config);
      if (data.alerts)         setAlerts(data.alerts);
      if (data.customers)      setCustomers(data.customers);
      if (data.affiliatePayouts)  setAffiliatePayouts(data.affiliatePayouts);
      if (data.affiliateGroups)   setAffiliateGroups(data.affiliateGroups);
      if (data.subscribers)    setSubscribers(data.subscribers);
      if (data.supportTickets) setSupportTickets(data.supportTickets);

      res.json({ success: true, message: "Data imported successfully. Please refresh the page." });
    } catch {
      res.status(400).json({ error: "Invalid payload format" });
    }
  });

  return router;
}
