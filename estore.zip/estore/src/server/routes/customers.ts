import { Router } from 'express';

export function createCustomersRouter(
  getContext: () => any,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  router.get("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { customers } = getContext();

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? customers.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const total = customers.length;
    const pages = all ? 1 : Math.ceil(total / pageSize);
    const data = all ? customers : customers.slice((page - 1) * pageSize, page * pageSize);

    res.json({ data, total, page: all ? 1 : page, pages });
  });

  router.get("/:id", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { customers, orders } = getContext();
    const customer = customers.find((c: any) => c.id === req.params.id);
    if (!customer) return res.status(404).json({ error: "Customer not found" });
    
    const customerOrders = orders.filter((o: any) => o.customerId === customer.id);
    res.json({ ...customer, orders: customerOrders });
  });

  router.patch("/:id/status", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { customers, setCustomers } = getContext();
    const { status } = req.body;
    
    const index = (customers || []).findIndex((c: any) => c.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: "Customer not found" });
    
    const newCustomers = [...customers];
    newCustomers[index] = { ...newCustomers[index], status };
    setCustomers(newCustomers);
    
    res.json({ success: true });
  });

  return router;
}
