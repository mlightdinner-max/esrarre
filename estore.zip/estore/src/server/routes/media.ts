import { Router } from 'express';
import fs from 'fs';
import path from 'path';

export function createMediaRouter(
  UPLOADS_DIR: string,
  upload: any,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  /**
   * Sanitise a user-supplied sub-path so it can be safely joined with UPLOADS_DIR.
   * Strategy:
   *  1. URL-decode to catch %2e%2e and %2F encoded traversal sequences.
   *  2. Normalise backslashes to forward slashes.
   *  3. Split on '/' and discard empty, '.', and '..' segments.
   *  4. Re-join — result is a relative path with no traversal sequences.
   */
  const sanitizePath = (sub: string): string => {
    let decoded = sub;
    try { decoded = decodeURIComponent(sub); } catch { /* keep original if malformed */ }
    return decoded
      .replace(/\\/g, '/')
      .split('/')
      .filter(seg => seg !== '' && seg !== '.' && seg !== '..')
      .join('/');
  };

  /**
   * Hard confinement guard — must pass even if sanitizePath somehow misses something.
   * Rejects any resolved path that does not start with UPLOADS_DIR.
   */
  const assertInsideUploads = (target: string): boolean => {
    const resolved = path.resolve(target);
    const base = path.resolve(UPLOADS_DIR);
    return resolved === base || resolved.startsWith(base + path.sep);
  };

  router.get("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    try {
      const subPath = sanitizePath((req.query.path as string) || "");
      const targetDir = path.join(UPLOADS_DIR, subPath);

      if (!assertInsideUploads(targetDir)) {
        return res.status(400).json({ error: "Invalid path" });
      }
      if (!fs.existsSync(targetDir)) {
        return res.status(404).json({ error: "Directory not found" });
      }

      const items = fs.readdirSync(targetDir);
      const media = items.map(item => {
        const fullPath = path.join(targetDir, item);
        const stats = fs.statSync(fullPath);
        const isDirectory = stats.isDirectory();
        const relativePath = `${subPath ? subPath + '/' : ''}${item}`;
        return {
          name: item,
          url: isDirectory ? relativePath : `/uploads/${relativePath}`,
          size: stats.size,
          createdAt: stats.birthtime,
          isDirectory
        };
      });
      res.json(media);
    } catch {
      res.status(500).json({ error: "Failed to list media" });
    }
  });

  router.post("/folders", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    try {
      const { name, path: subPathRaw } = req.body;
      const subPath = sanitizePath(subPathRaw || "");
      const safeName = sanitizePath(name || "");
      if (!safeName) return res.status(400).json({ error: "Folder name is required" });

      const targetDir = path.join(UPLOADS_DIR, subPath, safeName);
      if (!assertInsideUploads(targetDir)) {
        return res.status(400).json({ error: "Invalid path" });
      }
      if (fs.existsSync(targetDir)) {
        return res.status(400).json({ error: "Folder already exists" });
      }

      fs.mkdirSync(targetDir, { recursive: true });
      res.status(201).json({ message: "Folder created" });
    } catch {
      res.status(500).json({ error: "Failed to create folder" });
    }
  });

  router.post("/upload", authenticateToken, checkRole(['Admin', 'Super Admin']), upload.single("image"), (req: any, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const subPath = sanitizePath(req.body.path || "");
    if (subPath) {
      const targetDir = path.join(UPLOADS_DIR, subPath);
      if (!assertInsideUploads(targetDir)) {
        try { fs.unlinkSync(req.file.path); } catch { /* ignore */ }
        return res.status(400).json({ error: "Invalid upload path" });
      }
      if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

      const oldPath = req.file.path;
      const newPath = path.join(targetDir, req.file.filename);
      fs.renameSync(oldPath, newPath);

      res.json({
        url: `/uploads/${subPath}/${req.file.filename}`,
        name: req.file.filename
      });
    } else {
      res.json({
        url: `/uploads/${req.file.filename}`,
        name: req.file.filename
      });
    }
  });

  router.delete("/:filename", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const subPath = sanitizePath((req.query.path as string) || "");
    const safeFilename = sanitizePath(req.params.filename);
    const filePath = path.join(UPLOADS_DIR, subPath, safeFilename);

    if (!assertInsideUploads(filePath)) {
      return res.status(400).json({ error: "Invalid path" });
    }

    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.isDirectory()) {
        fs.rmSync(filePath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(filePath);
      }
      res.status(204).send();
    } else {
      res.status(404).json({ error: "File not found" });
    }
  });

  return router;
}
