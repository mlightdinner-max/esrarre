import { Router } from 'express';
import bcrypt from 'bcryptjs';

/** Fields that must never be returned to any client — read from env vars on the server only. */
const _SECRET_FIELDS = [
  'resetPassword',
  'geminiApiKey',
  'notificationSettings',   // contains smtpPass, accountSid, webhook secret — strip entire block from public endpoint
] as const;

/** For admin endpoints we return notificationSettings but scrub embedded credentials. */
function scrubNotificationSecrets(settings: any): any {
  if (!settings) return settings;
  return {
    ...settings,
    email: settings.email ? {
      ...settings.email,
      smtpPass: settings.email.smtpPass ? '••••••••' : undefined,
    } : undefined,
    whatsapp: settings.whatsapp ? {
      ...settings.whatsapp,
      apiKey: settings.whatsapp.apiKey ? '••••••••' : undefined,
      accountSid: settings.whatsapp.accountSid ? '••••••••' : undefined,
    } : undefined,
    webhook: settings.webhook ? {
      ...settings.webhook,
      secret: settings.webhook.secret ? '••••••••' : undefined,
    } : undefined,
  };
}

function stripPublicSecrets(config: any) {
  const { resetPassword: _rp, geminiApiKey: _gk, notificationSettings: _ns, ...publicConfig } = config as any;
  return publicConfig;
}

function stripAdminSecrets(config: any) {
  const { resetPassword: _rp, geminiApiKey: _gk, notificationSettings, ...rest } = config as any;
  return {
    ...rest,
    // Return notification settings with passwords masked so the UI can show connection status
    notificationSettings: scrubNotificationSecrets(notificationSettings),
    // Tell the client whether a Gemini key is configured without exposing the key itself
    geminiApiKeyConfigured: !!(process.env.GEMINI_API_KEY || _gk),
  };
}

export function createConfigRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  CONFIG_FILE: string,
  logAction: (user: any, action: string, details: any) => void,
  authenticateToken: any,
  checkRole: any,
  visitors: Map<string, any>
) {
  const router = Router();

  // Public endpoint — storefront reads store name, logo, colours, etc.
  // Never returns any secrets or credentials.
  router.get("/", (req, res) => {
    const { config } = getContext();
    res.json({ ...stripPublicSecrets(config), visitorCount: visitors.size });
  });

  router.post("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const { config, setConfig } = getContext();
    const updateData = { ...req.body };

    // Reject attempts to set geminiApiKey via config — it must be an env var
    if ('geminiApiKey' in updateData) {
      delete updateData.geminiApiKey;
    }

    // Only Super Admin can change the system reset password
    if (updateData.resetPassword) {
      if (req.user.role !== 'Super Admin') {
        return res.status(403).json({ error: 'Only Super Admin can change the system reset password.' });
      }
      updateData.resetPassword = bcrypt.hashSync(updateData.resetPassword, 10);
    }

    const newConfig = { ...config, ...updateData };
    setConfig(newConfig);
    logAction(req.user, 'UPDATE_CONFIG', { changes: Object.keys(req.body) });
    res.json(stripAdminSecrets(newConfig));
  });

  // Admin-only full config — secrets masked, never plaintext
  router.get("/full", authenticateToken, checkRole(['Admin', 'Super Admin']), (_req, res) => {
    const { config } = getContext();
    res.json(stripAdminSecrets(config));
  });

  return router;
}
