import { Router } from 'express';
import crypto from 'crypto';

export function createNewsletterRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  CONFIG_FILE: string,
  authenticateToken: any,
  checkRole: any,
  nodemailer: any,
  logAction: any
) {
  const router = Router();

  router.get("/", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { subscribers } = getContext();
    const all_subs = subscribers || [];

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? all_subs.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const total = all_subs.length;
    const pages = all ? 1 : Math.ceil(total / pageSize);
    const data = all ? all_subs : all_subs.slice((page - 1) * pageSize, page * pageSize);

    res.json({ data, total, page: all ? 1 : page, pages });
  });

  router.post("/subscribe", (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    // Basic email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: "Invalid email address" });
    }
    
    const { subscribers, setSubscribers } = getContext();
    
    if (subscribers.some((s: any) => s.email === email)) {
      return res.status(400).json({ error: "Email already subscribed" });
    }

    const newSubscriber = {
      id: crypto.randomUUID(),
      email,
      joinedAt: new Date().toISOString(),
      status: 'Active'
    };
    
    setSubscribers([...subscribers, newSubscriber]);
    res.status(201).json({ message: "Subscribed successfully" });
  });

  router.post('/unsubscribe', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });
    const { subscribers, setSubscribers } = getContext();
    const index = (subscribers || []).findIndex((s: any) => s.email === email);
    if (index === -1) return res.status(404).json({ error: 'Subscriber not found' });
    const updated = [...subscribers];
    updated[index] = { ...updated[index], status: 'Unsubscribed' };
    setSubscribers(updated);
    res.json({ success: true });
  });

  router.post("/send-campaign", authenticateToken, checkRole(['Admin', 'Super Admin']), async (req, res) => {
    const { subject, content } = req.body;
    if (!subject || !content) return res.status(400).json({ error: "Subject and content required" });

    const { config, subscribers, setConfig } = getContext();
    const activeSubscribers = (subscribers || []).filter((s: any) => s.status === 'Active');
    
    if (activeSubscribers.length === 0) {
      return res.status(400).json({ error: "No active subscribers found" });
    }

    const settings = config.integrations?.orderEmail;
    let sentCount = 0;
    let failedCount = 0;

    if (settings?.enabled && settings.host && settings.user && settings.pass) {
      try {
        const transporter = nodemailer.createTransport({
          host: settings.host,
          port: settings.port || 587,
          secure: settings.port === 465,
          auth: {
            user: settings.user,
            pass: settings.pass,
          },
        });

        // Implement basic batching (5 at a time) to avoid SMTP rate limit violations
        const BATCH_SIZE = 5;
        for (let i = 0; i < activeSubscribers.length; i += BATCH_SIZE) {
          const batch = activeSubscribers.slice(i, i + BATCH_SIZE);
          await Promise.all(batch.map(async (sub: any) => {
            try {
              await transporter.sendMail({
                from: settings.from || config.contactEmail,
                to: sub.email,
                subject: subject,
                html: content,
                text: content.replace(/<[^>]*>?/gm, '')
              });
              sentCount++;
            } catch (err) {
              failedCount++;
              console.error(`Failed to send newsletter to ${sub.email}:`, err);
            }
          }));
          
          // Small delay between batches if there are more
          if (i + BATCH_SIZE < activeSubscribers.length) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      } catch (error) {
        console.error("Newsletter transport failed:", error);
        return res.status(500).json({ error: "Newsletter relay failure" });
      }
    }

    const newCampaign = {
      id: crypto.randomUUID(),
      subject,
      content,
      sentAt: new Date().toISOString(),
      status: 'Sent',
      recipients: subscribers.length,
      sentCount,
      failedCount
    };

    const updatedConfig = { ...config, campaigns: [newCampaign, ...(config.campaigns || [])] };
    setConfig(updatedConfig);
    
    const user = (req as any).user;
    logAction(user, 'NEWSLETTER_CAMPAIGN', `Sent campaign "${subject}" to ${sentCount} subscribers`);

    res.json({ success: true, campaign: newCampaign });
  });

  return router;
}
