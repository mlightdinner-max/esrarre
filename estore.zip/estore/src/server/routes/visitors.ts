import { Router } from 'express';

export function createVisitorsRouter(
  visitors: Map<string, any>,
  broadcastVisitors: () => void,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  router.post("/ping", (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const { currentPage, deviceType, locale, timezone } = req.body;
    const userAgent = req.headers['user-agent'] || 'unknown';
    
    const existing = visitors.get(ip);
    visitors.set(ip, {
      ip,
      lastSeen: Date.now(),
      sessionStart: existing ? existing.sessionStart : Date.now(),
      currentPage: currentPage || '/',
      deviceType: deviceType || 'desktop',
      userAgent,
      locale,
      timezone
    });
    
    broadcastVisitors();
    res.json({ success: true, count: visitors.size });
  });

  router.get("/count", (req, res) => {
    res.json({ count: visitors.size });
  });

  router.get("/list", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    res.json(Array.from(visitors.values()));
  });

  return router;
}
