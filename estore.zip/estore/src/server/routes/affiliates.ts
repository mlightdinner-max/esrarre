import { Router } from 'express';
import crypto from 'crypto';

export function createAffiliatesRouter(
  getContext: () => any,
  writeData: (file: string, data: any) => void,
  AFFILIATE_GROUPS_FILE: string,
  AFFILIATE_PAYOUTS_FILE: string,
  USERS_FILE: string,
  logAction: (user: any, action: string, details: any) => void,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  // --- Affiliate Group Routes ---
  router.get("/groups", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { affiliateGroups } = getContext();
    res.json(affiliateGroups || []);
  });

  router.post("/groups", authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { affiliateGroups, setAffiliateGroups } = getContext();
    const group = {
      ...req.body,
      id: `GRP-${crypto.randomUUID().split('-')[0].toUpperCase()}`,
      memberCount: 0
    };
    const newGroups = [...(affiliateGroups || []), group];
    setAffiliateGroups(newGroups);
    res.status(201).json(group);
  });

  router.get("/payouts", authenticateToken, (req: any, res) => {
    const { affiliatePayouts } = getContext();
    const payouts = affiliatePayouts || [];
    if (req.user.role === 'Affiliate') {
      return res.json(payouts.filter((p: any) => p.affiliateId === req.user.affiliateId));
    }
    if (req.user.role === 'Admin' || req.user.role === 'Super Admin') {
      return res.json(payouts);
    }
    res.status(403).json({ error: "Forbidden" });
  });

  // --- POST /payouts — admin marks a payout as paid ---
  router.post('/payouts', authenticateToken, checkRole(['Admin', 'Super Admin']), (req: any, res) => {
    const { affiliatePayouts, setAffiliatePayouts } = getContext();
    const payout = {
      ...req.body,
      id: `PAY-${crypto.randomUUID().split('-')[0].toUpperCase()}`,
      status: 'paid',
      paidAt: new Date().toISOString()
    };
    setAffiliatePayouts([...(affiliatePayouts || []), payout]);
    logAction(req.user, 'PROCESS_AFFILIATE_PAYOUT', { payoutId: payout.id, affiliateId: payout.affiliateId, amount: payout.amount });
    res.status(201).json(payout);
  });

  // --- POST /payouts/request — affiliate requests payout for eligible orders ---
  router.post('/payouts/request', authenticateToken, checkRole(['Affiliate']), (req: any, res) => {
    const { orderIds } = req.body;
    if (!Array.isArray(orderIds) || orderIds.length === 0) {
      return res.status(400).json({ error: 'orderIds array is required.' });
    }

    const { orders, _users, affiliatePayouts, setAffiliatePayouts } = getContext();
    const affiliateId = req.user.affiliateId;
    if (!affiliateId) return res.status(400).json({ error: 'No affiliate ID on account.' });

    // Only count orders belonging to this affiliate
    const eligibleOrders = (orders || []).filter((o: any) =>
      orderIds.includes(o.id) &&
      o.affiliateId === affiliateId &&
      o.affiliatePayoutStatus !== 'Paid' &&
      o.affiliatePayoutStatus !== 'Requested'
    );

    if (eligibleOrders.length === 0) {
      return res.status(400).json({ error: 'No eligible orders found for payout request.' });
    }

    const totalAmount = eligibleOrders.reduce((sum: number, o: any) => sum + (o.commissionAmount || 0), 0);

    const newPayout = {
      id: `PAY-${crypto.randomUUID().split('-')[0].toUpperCase()}`,
      affiliateId,
      orderIds: eligibleOrders.map((o: any) => o.id),
      amount: totalAmount,
      status: 'pending',
      requestedAt: new Date().toISOString()
    };

    setAffiliatePayouts([...(affiliatePayouts || []), newPayout]);
    res.status(201).json(newPayout);
  });

  // Bounded map for affiliate click deduplication.
  // Stores expiry timestamp per key; pruned when it grows large.
  const MAX_CLICK_ENTRIES = 10_000;
  const COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours
  const clickedIps = new Map<string, number>(); // key -> expiry timestamp

  router.post("/click", (req, res) => {
    const { users, setUsers } = getContext();
    const { affiliateId } = req.body;
    if (!affiliateId) return res.status(400).json({ error: "Affiliate ID required" });

    const ip = (req.ip || req.headers["x-forwarded-for"] || "unknown") as string;
    const clickKey = `${affiliateId}-${ip}`;
    const now = Date.now();

    // Prune expired entries when map grows large
    if (clickedIps.size > MAX_CLICK_ENTRIES) {
      for (const [key, expiry] of clickedIps) {
        if (now > expiry) clickedIps.delete(key);
      }
    }

    if (clickedIps.has(clickKey) && now < (clickedIps.get(clickKey) || 0)) {
      return res.json({ success: true, duplicated: true });
    }

    const affIndex = users.findIndex((u: any) => u.role === "Affiliate" && u.affiliateId === affiliateId);
    if (affIndex !== -1) {
      clickedIps.set(clickKey, now + COOLDOWN_MS);
      const newUsers = [...users];
      newUsers[affIndex] = { ...newUsers[affIndex], referralClicks: (newUsers[affIndex].referralClicks || 0) + 1 };
      setUsers(newUsers);
      return res.json({ success: true });
    }
    res.status(404).json({ error: "Affiliate not found" });
  });

  return router;
}
