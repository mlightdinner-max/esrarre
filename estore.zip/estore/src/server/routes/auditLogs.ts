import { Router } from 'express';

export function createAuditLogsRouter(
  getContext: () => any,
  authenticateToken: any,
  checkRole: any
) {
  const router = Router();

  router.get('/', authenticateToken, checkRole(['Admin', 'Super Admin']), (req, res) => {
    const { auditLogs } = getContext();
    const logs = [...(auditLogs || [])].reverse(); // newest first

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = parseInt(req.query.limit as string);
    const all = limit === 0;
    const pageSize = all ? logs.length : (limit > 0 ? Math.min(limit, 200) : 50);

    const total = logs.length;
    const pages = all ? 1 : Math.ceil(total / pageSize);
    const data = all ? logs : logs.slice((page - 1) * pageSize, page * pageSize);

    res.json({ data, total, page: all ? 1 : page, pages });
  });

  return router;
}
