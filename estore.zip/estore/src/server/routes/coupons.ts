import { Router } from 'express';

export function createCouponsRouter(
  getContext: () => any
) {
  const router = Router();

  router.get("/validate", (req, res) => {
    const { code } = req.query;
    if (!code) return res.status(400).json({ error: "Coupon code is required" });

    const { config } = getContext();
    const currentConfig = config || {};

    if (!currentConfig.coupons) currentConfig.coupons = [];
    const coupon = currentConfig.coupons.find((c: any) => c.code.toUpperCase() === (code as string).toUpperCase());

    if (!coupon) {
      return res.status(404).json({ error: "Invalid coupon code" });
    }

    if (coupon.status?.toLowerCase() !== 'active') {
      return res.status(400).json({ error: "This coupon is no longer active" });
    }

    if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
      return res.status(400).json({ error: "This coupon has expired" });
    }

    res.json(coupon);
  });

  return router;
}
