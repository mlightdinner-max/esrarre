import React, { useState, useMemo } from 'react';
import {
  History, ShoppingBag, Users, Activity, Clock, LayoutDashboard, DollarSign
} from 'lucide-react';
import { Order, Product } from '../../types';
import { LOCALIZATION } from '../../constants';
import AdminAnalytics from './AdminAnalytics';
import { AdminPageWrapper } from './AdminPageWrapper';
import { StatsCard } from './StatsCard';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface AdminOverviewProps {
  products: Product[];
  orders: Order[];
  user: any;
  setActiveTab: (tab: string) => void;
  aiStatus?: any;
  config?: any;
}

const AdminOverview = ({ products, orders, user, setActiveTab, aiStatus, config }: AdminOverviewProps) => {
  const [timeRange, setTimeRange] = useState<'today' | 'yesterday' | '7d' | '30d' | 'this-month' | 'all' | 'custom'>('7d');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');

  const isAffiliate = user?.role === 'Affiliate';

  const filteredOrders = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    let baseOrders = orders;
    if (isAffiliate) {
      baseOrders = orders.filter(o => o.affiliateId === user.affiliateId);
    }

    return baseOrders.filter(o => {
      const orderDate = new Date(o.createdAt);
      const isStatusValid = o.status !== 'Cancelled' && o.status !== 'Returned';
      
      if (!isStatusValid) return false;

      if (timeRange === 'today') return orderDate >= today;
      if (timeRange === 'yesterday') {
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);
        return orderDate >= yesterday && orderDate < today;
      }
      if (timeRange === '7d') {
        const sevenDaysAgo = new Date(today);
        sevenDaysAgo.setDate(today.getDate() - 7);
        return orderDate >= sevenDaysAgo;
      }
      if (timeRange === '30d') {
        const thirtyDaysAgo = new Date(today);
        thirtyDaysAgo.setDate(today.getDate() - 30);
        return orderDate >= thirtyDaysAgo;
      }
      if (timeRange === 'this-month') {
        const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        return orderDate >= firstOfMonth;
      }
      if (timeRange === 'custom' && customStartDate && customEndDate) {
        const start = new Date(customStartDate);
        const end = new Date(customEndDate);
        end.setHours(23, 59, 59, 999);
        return orderDate >= start && orderDate <= end;
      }
      return true;
    });
  }, [orders, timeRange, customStartDate, customEndDate, isAffiliate, user]);

  const stats = useMemo(() => {
    const validOrders = filteredOrders.filter(o => o.status !== 'Cancelled' && o.status !== 'Returned');
    const totalRevenue = validOrders.reduce((sum, o) => sum + o.total, 0);
    const totalOrders = filteredOrders.length;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const totalCustomers = new Set(filteredOrders.map(o => o.email)).size;

    const recentOrders = [...filteredOrders]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);

    return { totalRevenue, totalOrders, avgOrderValue, totalCustomers, recentOrders };
  }, [filteredOrders]);

  return (
    <AdminPageWrapper
      title={config?.homeWelcomeMessage || "Overview"}
      description={config?.homeSummaryMessage || "Welcome back. Here's what's happening with your store today."}
      icon={LayoutDashboard}
      options={[
        { label: "Quick Stats", description: "View revenue, orders, and active visitors at a glance." },
        { label: "Recent Activity", description: "Monitor the latest orders and system events." }
      ]}
      toolbar={
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 w-full">
          <div className="flex items-center gap-3 w-full md:w-auto">
            {/* Decorative element to balance layout */}
            <div className="hidden md:flex items-center gap-2 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <Activity size={14} className="text-emerald-500 animate-pulse" />
                <span className="section-label">Live Status</span>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <select 
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="px-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-900/10 transition-all shadow-sm"
            >
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="this-month">This Month</option>
              <option value="all">All Time</option>
              <option value="custom">Custom Range</option>
            </select>
            
            {timeRange === 'custom' && (
              <div className="flex items-center gap-2">
                <input 
                  type="date" 
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="px-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-900/10 transition-all shadow-sm"
                />
                <span className="text-slate-400 font-bold">-</span>
                <input 
                  type="date" 
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="px-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-900/10 transition-all shadow-sm"
                />
              </div>
            )}

            <button 
              onClick={() => setActiveTab('ai-settings')}
              className={`px-6 py-3 border rounded-2xl text-xs font-medium uppercase tracking-wider transition-all shadow-sm flex items-center gap-2 ${
                aiStatus?.isAvailable 
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100' 
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${aiStatus?.isAvailable ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-slate-300'}`} />
              AI Orchestrator: {aiStatus?.isAvailable ? 'Active' : 'Offline'}
            </button>
            <button 
              onClick={() => setActiveTab('audit')}
              className="px-6 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-600 hover:bg-slate-50 transition-all shadow-sm flex items-center gap-2"
            >
              <History size={14} />
              Activity Log
            </button>
          </div>
        </div>
      }
    >

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Total Revenue" 
          value={`${LOCALIZATION.CURRENCY}${stats.totalRevenue.toLocaleString()}`} 
          icon={DollarSign} 
          color="emerald"
          delay={0.1}
        />
        <StatsCard 
          label="Total Orders" 
          value={stats.totalOrders} 
          icon={ShoppingBag} 
          color="blue"
          delay={0.2}
        />
        <StatsCard 
          label="Avg Order Value" 
          value={`${LOCALIZATION.CURRENCY}${Math.round(stats.avgOrderValue).toLocaleString()}`} 
          icon={Activity} 
          color="amber"
          delay={0.3}
        />
        <StatsCard 
          label="Total Customers" 
          value={stats.totalCustomers} 
          icon={Users} 
          color="purple"
          delay={0.4}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="premium-heading text-sm text-slate-950 flex items-center gap-2">
              <Clock size={16} className="text-slate-400" />
              Recent Orders
            </h3>
            <button 
              onClick={() => setActiveTab('orders')}
              className="section-label hover:text-slate-900 transition-colors"
            >
              View All
            </button>
          </div>
          
          <Table>
            <TableHeader>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableHeader>
            <TableBody>
              {stats.recentOrders.length > 0 ? (
                stats.recentOrders.map((order, oIdx) => (
                  <TableRow key={`${order.id}-${oIdx}`}>
                    <TableCell>
                      <span className="text-xs font-black text-slate-950 uppercase tracking-tight">#{order.id.slice(0, 8)}</span>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-0.5">
                        <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{order.customerName}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{new Date(order.createdAt).toLocaleDateString()}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium uppercase tracking-wider ${
                        order.status === 'Completed' ? 'bg-emerald-50 text-emerald-600' :
                        order.status === 'Pending' ? 'bg-amber-50 text-amber-600' :
                        'bg-blue-50 text-blue-600'
                      }`}>
                        <div className={`w-1 h-1 rounded-full ${
                          order.status === 'Completed' ? 'bg-emerald-500' :
                          order.status === 'Pending' ? 'bg-amber-500' :
                          'bg-blue-500'
                        }`} />
                        {order.status}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="text-xs font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{order.total.toLocaleString()}</span>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="py-12 text-center">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No orders found</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Stock Status Summary */}
        <div className="space-y-4">
          <h3 className="premium-heading text-sm text-slate-950 flex items-center gap-2 px-2">
            <ShoppingBag size={16} className="text-slate-400" />
            Stock Status
          </h3>
          <div className="bg-slate-900 rounded-2xl p-5 sm:p-8 text-white space-y-6 shadow-2xl shadow-slate-950/40 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
              <ShoppingBag size={80} />
            </div>
            <div className="space-y-2 relative">
              <h4 className="premium-heading text-xl">Inventory Health</h4>
              <p className="section-label">Real-time Stock Monitor</p>
            </div>
            <div className="space-y-4 relative">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                <p className="text-xs font-medium text-slate-300 leading-relaxed">
                  {products.filter(p => (p.stock || 0) === 0).length} products are currently <span className="text-rose-400 font-bold">Out of Stock</span>. 
                  {products.filter(p => (p.stock || 0) > 0 && (p.stock || 0) < 5).length} items are running low.
                </p>
              </div>
              <button 
                onClick={() => setActiveTab('products')}
                className="btn-secondary"
              >
                Manage Inventory
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Analytics Charts */}
      <div className="pt-8 border-t border-slate-200">
        <AdminAnalytics orders={filteredOrders} products={products} hideMetrics />
      </div>
    </AdminPageWrapper>
  );
};

export default AdminOverview;
