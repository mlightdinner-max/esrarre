import React, { useState, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, X, LogOut, ExternalLink, Package
} from 'lucide-react';
import { ADMIN_MENU_GROUPS } from './AdminMenuSchema';
import { DEFAULT_PERMISSIONS } from '../../constants';

interface AdminSidebarProps {
  activeTab: string;
  setActiveTab: (t: string) => void;
  user: any;
  onLogout: () => void;
  isOpen: boolean;
  onClose: () => void;
  config: any;
}

const AdminSidebar = ({ activeTab, setActiveTab, user, onLogout, isOpen, onClose, config }: AdminSidebarProps) => {
  const role = user?.role || 'Customer';
  const isSuperAdmin = role === 'Super Admin';
  const isAffiliate = role === 'Affiliate';
  const [menuSearch, setMenuSearch] = useState('');
  const baseTab = activeTab.split('/')[0];

  const userPermissions = useMemo(() => {
    if (isSuperAdmin) return ['*'];
    const perms = config.profilePermissions || DEFAULT_PERMISSIONS;
    return perms[role] || [];
  }, [config.profilePermissions, role, isSuperAdmin]);

  const canView = useCallback((moduleId: string, superAdminOnly: boolean = false) => {
    if (isSuperAdmin) return true;
    if (superAdminOnly) return false;
    return userPermissions.includes(moduleId);
  }, [isSuperAdmin, userPermissions]);
  
  const groups = useMemo(() => {
    return ADMIN_MENU_GROUPS.map(group => ({
      ...group,
      label: (isAffiliate && group.affiliateLabel) ? group.affiliateLabel : group.label,
      items: group.items.map(item => ({
        ...item,
        label: (isAffiliate && (item as any).affiliateLabel) ? (item as any).affiliateLabel : item.label,
        show: canView(item.id, (item as any).superAdminOnly)
      })).filter(item => 
        item.show && 
        (item.label.toLowerCase().includes(menuSearch.toLowerCase()) || 
         group.label.toLowerCase().includes(menuSearch.toLowerCase()))
      )
    })).filter(g => g.items.length > 0);
  }, [canView, isAffiliate, menuSearch]);

  return (
    <>
      {/* Mobile overlay backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 z-[105] lg:hidden backdrop-blur-sm"
          onClick={onClose}
          aria-hidden="true"
        />
      )}
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 w-60 bg-white border-r border-slate-200 flex flex-col z-[110] transform transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-4 pb-2 space-y-4">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center space-x-2.5 group">
              <div className="w-7 h-7 bg-slate-900 rounded-lg flex items-center justify-center shadow-lg shadow-slate-900/10 group-hover:scale-105 transition-transform">
                {config.logoUrl ? (
                  <img src={config.logoUrl} alt="Logo" className="h-4 w-auto object-contain invert" referrerPolicy="no-referrer" />
                ) : (
                  <Package className="text-white" size={14} />
                )}
              </div>
              <div>
                <h2 className="premium-heading text-sm text-slate-950 leading-none">{config.storeName || 'Admin'}</h2>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.3em] mt-1">Control Panel</p>
              </div>
            </Link>
            <button onClick={onClose} aria-label="Close sidebar" className="lg:hidden p-1.5 text-slate-400 hover:text-slate-900 rounded-md hover:bg-slate-50 transition-colors">
              <X size={18} />
            </button>
          </div>

          {/* Menu Search */}
          <div className="relative group">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={12} />
            <input 
              type="text"
              placeholder="Search menu..."
              value={menuSearch}
              onChange={(e) => setMenuSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all text-xs font-bold"
            />
            {menuSearch && (
              <button 
                onClick={() => setMenuSearch('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-900"
              >
                <X size={12} />
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-3 custom-scrollbar">
          <div className="space-y-5">
            {groups.map((group, idx) => {
              const visibleItems = group.items.filter(i => i.show);
              if (visibleItems.length === 0) return null;
              return (
                <div key={idx} className="space-y-2">
                  <h3 className="px-2.5 section-label">{group.label}</h3>
                  <div className="space-y-0.5">
                    {visibleItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          onClose();
                        }}
                        className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all duration-200 group ${
                          baseTab === item.id 
                            ? 'bg-slate-900 text-white shadow-md shadow-slate-900/10' 
                            : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                        }`}
                      >
                        <item.icon size={14} className={`${baseTab === item.id ? 'text-white' : 'text-slate-400 group-hover:text-slate-900'} transition-colors`} />
                        <span className="flex-1 text-left">{item.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-3 border-t border-slate-100 space-y-3">
          <div className={`p-2.5 rounded-lg border space-y-2 ${config.isLive ? 'bg-primary/5 border-primary/10' : 'bg-red-50 border-red-100'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className={`w-1 h-1 rounded-full animate-pulse ${config.isLive ? 'bg-primary/80' : 'bg-red-500'}`} />
                <span className={`text-xs font-medium uppercase tracking-wider ${config.isLive ? 'text-primary' : 'text-red-600'}`}>
                  {config.isLive ? 'Store Live' : 'Store Offline'}
                </span>
              </div>
              <ExternalLink size={10} className={config.isLive ? 'text-primary/60' : 'text-red-400'} />
            </div>
            <a 
              href="/" 
              className={`w-full py-1.5 text-white text-xs font-medium uppercase tracking-wider rounded-md shadow-sm transition-all flex items-center justify-center space-x-2 ${config.isLive ? 'bg-primary hover:bg-primary-dark' : 'bg-red-600 hover:bg-red-700'}`}
            >
              <span>{config.isLive ? 'Access Store' : 'View Offline'}</span>
            </a>
          </div>
          <div className="flex items-center space-x-2.5 px-1">
            <div className="w-7 h-7 bg-slate-100 rounded-lg flex items-center justify-center text-slate-500 font-bold text-xs border border-slate-200">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-900 truncate">{user?.name}</p>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-widest truncate">{user?.role}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-2 px-2.5 py-1.5 rounded-md text-xs font-bold text-red-600 hover:bg-red-50 transition-all border border-transparent hover:border-red-100"
          >
            <LogOut size={14} />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default AdminSidebar;
