import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ExternalLink
} from 'lucide-react';
import { Product, Config, User, Order } from '../../types';
import { LOCALIZATION } from '../../constants';
import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface AffiliateProgramManagementProps {
  config: Config;
  onUpdateConfig: (c: Config) => void;
  products: Product[];
  users: User[];
  orders: Order[];
  onNavigateToPayouts: () => void;
}

const AffiliateProgramManagement = ({ 
  config, 
  onUpdateConfig, 
  products, 
  users, 
  orders,
  onNavigateToPayouts 
}: AffiliateProgramManagementProps) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'settings'>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const affiliates = useMemo(() => {
    return users.filter(u => u.role === 'Affiliate').map(u => {
        const affOrders = orders.filter(o => o.affiliateId === u.affiliateId && o.status === 'Completed');
        return {
            ...u,
            totalSales: affOrders.reduce((sum, o) => sum + o.total, 0),
            orderCount: affOrders.length
        };
    });
  }, [users, orders]);

  const filteredAffiliates = affiliates.filter(a => 
    a.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.affiliateId?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminPageWrapper
      title="Affiliate Programme"
      description="Manage your affiliate program, payouts, and settings."
      actions={
        <button
          onClick={onNavigateToPayouts}
          className="flex items-center space-x-2 px-6 py-2.5 bg-slate-100 text-slate-900 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-200 transition-all border border-slate-200"
        >
          <ExternalLink size={14} />
          <span>Go to Payouts</span>
        </button>
      }
      toolbar={
        <AdminToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search affiliates by name or ID..."
          leftActions={
            <div className="flex bg-slate-200/50 p-1 rounded-2xl w-fit">
              {['overview', 'settings'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${
                    activeTab === tab ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          }
        />
      }
    >
      {/* Main Content */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 min-h-[400px]">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div 
                key="overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                <Table>
                  <TableHeader>
                    <TableHead>Affiliate</TableHead>
                    <TableHead>Code</TableHead>
                    <TableHead>Total Sales</TableHead>
                    <TableHead>Orders</TableHead>
                    <TableHead>Status</TableHead>
                  </TableHeader>
                  <TableBody>
                    {filteredAffiliates.length > 0 ? filteredAffiliates.map((affiliate: any) => (
                      <TableRow key={affiliate.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 font-black text-xs">
                              {affiliate.name?.charAt(0)}
                            </div>
                            <div>
                              <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{affiliate.name}</p>
                              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{affiliate.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-xs font-black text-slate-950 font-mono uppercase tracking-widest">{affiliate.affiliateId}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-xs font-black text-slate-950">{LOCALIZATION.CURRENCY}{(affiliate.totalSales || 0).toLocaleString()}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-xs font-black text-slate-950">{affiliate.orderCount || 0}</span>
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium uppercase tracking-wider ${
                            !affiliate.isBlocked ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                          }`}>
                            {!affiliate.isBlocked ? 'Active' : 'Suspended'}
                          </span>
                        </TableCell>
                      </TableRow>
                    )) : (
                      <TableRow>
                        <TableCell colSpan={5} className="py-12 text-center">
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No affiliates found</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6 max-w-2xl"
              >
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Default Commission Rate (%)</label>
                    <input 
                      type="number"
                      value={config.affiliateSettings?.defaultCommissionRate || 10}
                      onChange={(e) => onUpdateConfig({ ...config, affiliateSettings: { ...config.affiliateSettings, defaultCommissionRate: Number(e.target.value) } })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Minimum Payout Amount ({LOCALIZATION.CURRENCY})</label>
                    <input 
                      type="number"
                      value={config.affiliateSettings?.minPayoutAmount || 1000}
                      onChange={(e) => onUpdateConfig({ ...config, affiliateSettings: { ...config.affiliateSettings, minPayoutAmount: Number(e.target.value) } })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Cookie Duration (Days)</label>
                    <input 
                      type="number"
                      value={config.affiliateSettings?.cookieDuration || 30}
                      onChange={(e) => onUpdateConfig({ ...config, affiliateSettings: { ...config.affiliateSettings, cookieDuration: Number(e.target.value) } })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Allowed Products for Affiliates</label>
                    <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl bg-slate-50 p-2 space-y-1">
                      {products.map(product => (
                        <label key={product.id} className="flex items-center space-x-2 p-2 hover:bg-white rounded-lg cursor-pointer transition-colors">
                          <input
                            type="checkbox"
                            checked={!config.affiliateSettings?.excludedProducts?.includes(product.id)}
                            onChange={(e) => {
                              const excluded = config.affiliateSettings?.excludedProducts || [];
                              const newExcluded = e.target.checked 
                                ? excluded.filter((id: string) => id !== product.id)
                                : [...excluded, product.id];
                              onUpdateConfig({ ...config, affiliateSettings: { ...config.affiliateSettings, excludedProducts: newExcluded } });
                            }}
                            className="rounded border-slate-300 text-slate-900 focus:ring-slate-900/20"
                          />
                          <span className="text-xs font-bold text-slate-700">{product.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AffiliateProgramManagement;
