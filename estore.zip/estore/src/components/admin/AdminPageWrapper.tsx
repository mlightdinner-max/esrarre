import React from 'react';
import { LucideIcon } from 'lucide-react';
import { AdminSectionHeader } from './AdminSectionHeader';
import { motion, AnimatePresence } from 'motion/react';

interface AdminPageWrapperProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  actions?: React.ReactNode;
  toolbar?: React.ReactNode;
  children: React.ReactNode;
  isLoading?: boolean;
  isEmpty?: boolean;
  emptyState?: React.ReactNode;
  /** Legacy prop — accepted for compatibility but not rendered */
  options?: { label: string; description: string }[];
}

export const AdminPageWrapper: React.FC<AdminPageWrapperProps> = ({
  title,
  description,
  icon,
  actions,
  toolbar,
  children,
  isLoading,
  isEmpty,
  emptyState
}) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 pb-8 min-h-screen"
    >
      <AdminSectionHeader 
        title={title} 
        description={description} 
        icon={icon}
      />
      
      {(actions || toolbar) && (
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 px-1">
          <div className="flex items-center gap-4 flex-1 w-full">
            {toolbar}
          </div>
          {actions && (
            <div className="flex items-center gap-4 self-end xl:self-auto shrink-0">
              {actions}
            </div>
          )}
        </div>
      )}

      <div className="relative">
        <AnimatePresence mode="wait">
          {isLoading ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-32 space-y-4 bg-white rounded-2xl border border-slate-100 shadow-sm"
            >
              <div className="w-12 h-12 border-4 border-slate-200 border-t-slate-900 rounded-full animate-spin" />
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider animate-pulse">Syncing Intelligence...</p>
            </motion.div>
          ) : isEmpty ? (
            <motion.div 
              key="empty"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm p-20 text-center space-y-4"
            >
              {emptyState}
            </motion.div>
          ) : (
            <motion.div 
              key="content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-8"
            >
              {children}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};
