import React, { useMemo, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Globe, Activity, ChevronRight, 
  Smartphone, Tablet, Monitor, Zap, LayoutGrid,
  Search
} from 'lucide-react';
import { Visitor } from '../../types';
import { AdminSectionHeader } from './AdminSectionHeader';

interface LiveTrafficProps {
  visitors: Visitor[];
}

const LiveTraffic = ({ visitors }: LiveTrafficProps) => {
  const [now, setNow] = useState(() => Date.now());
  const [searchQuery, setSearchQuery] = useState('');
  const [deviceFilter, setDeviceFilter] = useState('All');
  const [activityHistory, setActivityHistory] = useState<number[]>(new Array(20).fill(0));

  useEffect(() => {
    const interval = setInterval(() => {
      setNow(Date.now());
      // Shift history and add current visitor count as a simple activity metric
      setActivityHistory(prev => [...prev.slice(1), visitors.length]);
    }, 2000);
    return () => clearInterval(interval);
  }, [visitors.length]);

  const ingestionRate = useMemo(() => {
    if (visitors.length === 0) return 0;
    const activeRecently = visitors.filter(v => (now - v.lastSeen) < 10000).length;
    return (activeRecently / 10).toFixed(1);
  }, [visitors, now]);

  const filteredVisitors = useMemo(() => {
    return visitors.filter(v => {
      const matchesSearch = v.ip.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.currentPage.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDevice = deviceFilter === 'All' || (v.deviceType || 'desktop').toLowerCase() === deviceFilter.toLowerCase();
      return matchesSearch && matchesDevice;
    }).sort((a, b) => b.lastSeen - a.lastSeen);
  }, [visitors, searchQuery, deviceFilter]);

  const pageCounts = visitors.reduce((acc, v) => {
    acc[v.currentPage] = (acc[v.currentPage] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const popularPages = Object.entries(pageCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 4)
    .map(([page, count], idx) => {
      const colors = ['bg-primary/80', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500'];
      return { page, count, color: colors[idx % colors.length] };
    });

  const deviceDistribution = useMemo(() => {
    const counts = { desktop: 0, mobile: 0, tablet: 0 };
    visitors.forEach(v => {
      const type = (v.deviceType || 'desktop').toLowerCase() as keyof typeof counts;
      if (counts[type] !== undefined) counts[type]++;
    });
    return counts;
  }, [visitors]);

  const geoData = useMemo(() => {
    const clusters: Record<string, { count: number; flag: string }> = {};
    
    // Explicit Mapping for Indian Timezones to ensure correct display
    const indiaZones = [
      'asia/kolkata', 'asia/calcutta', 'asia/delhi', 
      'asia/mumbai', 'asia/bangalore', 'asia/chennai',
      'india/standard'
    ];

    visitors.forEach(v => {
      const tz = (v.timezone || '').toLowerCase();
      const tzParts = tz.split('/') || [];
      let region = tzParts.length > 1 ? tzParts[1].replace('_', ' ') : (v.timezone || 'Global');
      
      // Capitalization fix for display
      region = region.charAt(0).toUpperCase() + region.slice(1);

      // Definitively handle "Calcutta" vs "Kolkata" for display
      if (region.toLowerCase() === 'calcutta') region = 'Kolkata';

      if (!clusters[region]) {
        // Initial inference based on locale
        let inferredFlag = v.locale?.split('-')[1]?.toLowerCase() || 'un';
        
        // CORRECTION: Aggressively force India flag for Indian timezones
        // This overrides any browser locale (like en-US) that might be causing a US flag mismatch
        if (indiaZones.some(z => tz.includes(z))) {
          inferredFlag = 'in';
        } else if (tz.startsWith('america/') && (tz.includes('new_york') || tz.includes('chicago') || tz.includes('los_angeles'))) {
          inferredFlag = 'us';
        } else if (tz.startsWith('europe/london') || tz.includes('london')) {
          inferredFlag = 'gb';
        }

        clusters[region] = { 
          count: 0, 
          flag: inferredFlag
        };
      }
      clusters[region].count++;
    });
    return Object.entries(clusters)
      .sort(([, a], [, b]) => b.count - a.count)
      .slice(0, 8);
  }, [visitors]);

  const maxCount = popularPages.length > 0 ? popularPages[0].count : 1;

  const avgSessionDuration = visitors.length > 0
    ? visitors.reduce((acc, v) => acc + (now - (Number(v.sessionStart) || now)), 0) / visitors.length
    : 0;

  const formatDuration = (ms: number) => {
    if (isNaN(ms) || ms < 0) return '0m 0s';
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}m ${seconds}s`;
  };

  const bounceRate = visitors.length > 0
    ? Math.max(20, Math.min(85, 85 - (avgSessionDuration / 1000 / 60) * 10))
    : 0;

  return (
    <div className="space-y-10 pb-10">
      <AdminSectionHeader 
        title="Live Traffic" 
        description="Real-time surveillance of global store activity and visitor metrics." 
        icon={Activity}
        options={[
          {"label":"Live Map","description":"Geographic distribution of active users."},
          {"label":"Session Stream","description":"Live feed of page transitions and interactions."}
        ]} 
      />

      {/* Filter Controls & Live Status */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Sparkline Visual & Status */}
          <div className="flex items-center gap-4 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl">
            <div className="flex items-center gap-2">
              <Activity size={14} className="text-emerald-500 animate-pulse" />
              <span className="text-xs font-black tracking-widest uppercase text-slate-500">Global Pulse</span>
            </div>
            
            <div className="h-4 w-px bg-slate-200" />
            
            <div className="flex items-end gap-0.5 h-4">
              {activityHistory.map((val, i) => (
                <motion.div 
                  key={i}
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.max(10, (val / (visitors.length || 1)) * 100)}%` }}
                  className="w-1 bg-emerald-500/50 rounded-t-sm"
                />
              ))}
            </div>

            <div className="h-4 w-px bg-slate-200" />
            
            <div className="flex items-center gap-1.5">
              <Zap size={12} className="text-amber-500" />
              <p className="text-xs font-black text-slate-900 tracking-widest uppercase">{ingestionRate} req/s</p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative group min-w-[200px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors" size={14} />
            <input 
              type="text" 
              placeholder="Filter IPs or paths..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900/10 transition-all shadow-sm"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-2xl">
            {['All', 'Desktop', 'Mobile', 'Tablet'].map(dev => (
              <button
                key={dev}
                onClick={() => setDeviceFilter(dev)}
                className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all ${
                  deviceFilter === dev ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {dev}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
        {/* Main Feed Container */}
        <div className="lg:col-span-8 space-y-6">
          {/* Abstract Map Component */}
          <div className="bg-slate-950 p-6 rounded-2xl relative overflow-hidden h-80 border border-white/5">
            <div className="absolute inset-0 opacity-20 pointer-events-none">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#10b981_0,transparent_50%)]" />
              <div className="w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30" />
            </div>
            
            <div className="relative z-10 flex flex-col h-full">
              <div className="flex items-center justify-between mb-auto">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 text-white">
                    <Globe size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white uppercase italic tracking-tighter">Geographic Distribution</h3>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Active nodes by timezone</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-xs font-medium text-emerald-500 uppercase tracking-wider">Network Live</span>
                </div>
              </div>

              {/* Grid of Geons */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mt-8">
                {geoData.map(([region, info], idx) => (
                  <motion.div 
                    key={region}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.1 }}
                    className="p-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex flex-col items-center gap-2 hover:bg-white/10 transition-colors group"
                  >
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center text-xl">
                        <img 
                          src={`https://flagcdn.com/w40/${info.flag}.png`} 
                          alt={region} 
                          className="w-6 h-4 object-cover rounded shadow-lg group-hover:scale-110 transition-transform"
                          onError={(e) => (e.currentTarget.style.display = 'none')}
                        />
                      </div>
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-950 flex items-center justify-center">
                        <span className="text-[6px] text-white font-black">{info.count}</span>
                      </div>
                    </div>
                    <p className="text-xs font-medium text-slate-300 uppercase tracking-wider truncate w-full text-center">{region}</p>
                  </motion.div>
                ))}
                {geoData.length === 0 && (
                  <div className="col-span-full py-12 flex flex-col items-center justify-center opacity-20 text-white italic">
                    <Globe size={40} className="mb-4 animate-spin-slow" />
                    <p className="text-xs font-black tracking-widest uppercase">Waiting for global link...</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Visitor Activity Feed */}
          <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
            <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-primary/5 text-primary rounded-xl">
                  <LayoutGrid size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-950 uppercase italic tracking-tighter">Live Session Path</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Interactive traversal stream</p>
                </div>
              </div>
            </div>
            <div className="divide-y divide-slate-50 max-h-[500px] overflow-y-auto no-scrollbar">
              <AnimatePresence mode="popLayout">
                {filteredVisitors.length > 0 ? (
                  filteredVisitors.map((visitor, idx) => (
                    <motion.div
                      key={`v-feed-${visitor.ip}-${idx}`}
                      layout
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="p-6 flex items-center justify-between hover:bg-slate-50/80 transition-all group"
                    >
                      <div className="flex items-center gap-5">
                        <div className="relative">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                            (now - visitor.lastSeen) < 5000 ? 'bg-primary text-white' : 'bg-slate-100 text-slate-400 group-hover:bg-slate-200'
                          }`}>
                            {visitor.deviceType?.toLowerCase() === 'mobile' ? <Smartphone size={16} /> : 
                             visitor.deviceType?.toLowerCase() === 'tablet' ? <Tablet size={16} /> : 
                             <Monitor size={16} />}
                          </div>
                          {(now - visitor.lastSeen) < 3000 && (
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-white" />
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-black text-slate-900 uppercase tracking-tight">V-{visitor.ip.split('.').pop()}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                               {visitor.locale?.toUpperCase()} • {formatDuration(now - visitor.sessionStart)}
                            </span>
                            <div className="w-1 h-1 bg-slate-200 rounded-full" />
                            <span className={`text-xs font-medium uppercase tracking-wider ${
                              (now - visitor.lastSeen) < 5000 ? 'text-emerald-500' : 'text-slate-300'
                            }`}>
                              {(now - visitor.lastSeen) < 5000 ? 'Active Now' : 'Idle'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-1.5 opacity-50">Node Target</p>
                          <div className="flex items-center gap-2 justify-end">
                             <div className={`px-3 py-1 rounded-lg text-xs font-medium uppercase tracking-wider transition-all ${
                               (now - visitor.lastSeen) < 5000 ? 'bg-slate-950 text-white shadow-md shadow-slate-950/20' : 'bg-slate-100 text-slate-500'
                             }`}>
                               {visitor.currentPage || '/'}
                             </div>
                          </div>
                        </div>
                        <ChevronRight size={14} className="text-slate-300 group-hover:text-slate-950 transition-colors" />
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="py-24 text-center opacity-40">
                    <Activity size={40} className="mx-auto mb-4" />
                    <p className="text-xs font-black tracking-widest uppercase">
                      {visitors.length === 0 ? 'Stream Offline' : 'No matches found'}
                    </p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Intelligence Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          {/* Health Stats */}
          <div className="bg-slate-900 p-5 sm:p-8 rounded-2xl text-white relative overflow-hidden">
            <div className="relative z-10 space-y-8">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-white/10 text-white rounded-xl backdrop-blur-md">
                  <Activity size={20} />
                </div>
                <h3 className="text-lg font-black uppercase italic tracking-tighter">Engagement</h3>
              </div>
              <div className="grid grid-cols-1 gap-6">
                <div className="space-y-1.5 p-4 bg-white/5 rounded-2xl border border-white/5">
                  <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Avg. Duration</p>
                  <p className="text-2xl font-black text-white tracking-tighter">{formatDuration(avgSessionDuration)}</p>
                  <div className="h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                    <div className="h-full bg-primary/60 w-3/4 rounded-full" />
                  </div>
                </div>
                <div className="space-y-1.5 p-4 bg-white/5 rounded-2xl border border-white/5">
                  <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Bounce Frequency</p>
                  <p className="text-2xl font-black text-white tracking-tighter">{bounceRate.toFixed(1)}%</p>
                  <div className="h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                    <div className="h-full bg-rose-500/60 w-1/3 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Device Mix Visualization */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200/60 shadow-sm space-y-8">
            <h3 className="text-lg font-black text-slate-950 uppercase italic tracking-tighter">Device Grid</h3>
            <div className="space-y-5">
              {[
                { label: 'Desktop', icon: Monitor, value: deviceDistribution.desktop, color: 'bg-primary' },
                { label: 'Mobile', icon: Smartphone, value: deviceDistribution.mobile, color: 'bg-blue-500' },
                { label: 'Tablet', icon: Tablet, value: deviceDistribution.tablet, color: 'bg-amber-500' }
              ].map((device) => (
                <div key={device.label} className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <div className="flex items-center gap-2">
                      <device.icon size={12} className="text-slate-400" />
                      <span className="text-xs font-medium text-slate-900 uppercase tracking-wider">{device.label}</span>
                    </div>
                    <span className="text-xs font-black text-slate-900">
                      {visitors.length > 0 ? ((device.value / visitors.length) * 100).toFixed(0) : 0}%
                    </span>
                  </div>
                  <div className="h-1.5 bg-slate-50 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${visitors.length > 0 ? (device.value / visitors.length) * 100 : 0}%` }}
                      className={`h-full ${device.color} rounded-full`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Popular Nodes */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200/60 shadow-sm">
            <h1 className="text-lg font-black text-slate-950 uppercase italic tracking-tighter mb-8 leading-none">High Traffic Nodes</h1>
            <div className="space-y-6">
              {popularPages.length > 0 ? popularPages.map((item, idx) => (
                <div key={`node-${idx}`} className="space-y-2">
                  <div className="flex justify-between items-end px-1">
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight truncate max-w-[120px]">{item.page || '/'}</p>
                    <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{item.count} L</p>
                  </div>
                  <div className="h-2 bg-slate-50 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(item.count / maxCount) * 100}%` }}
                      className={`h-full ${item.color} rounded-full`}
                    />
                  </div>
                </div>
              )) : (
                <div className="py-8 text-center text-xs font-black text-slate-400 uppercase tracking-[0.2em] italic">No active nodes</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveTraffic;

