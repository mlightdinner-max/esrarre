import React, { useState, useMemo } from 'react';
import { 
  Trash2, 
  User as UserIcon, 
  Calendar, 
  UserPlus,
  Shield,
  UserCheck,
  Ban,
  X,
  Mail,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../../types';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface AdminUsersProps {
  users: User[];
  onAddUser: (u: any) => void;
  onUpdateUser: (id: string, u: any) => void;
  onDeleteUser: (id: string) => void;
  user?: any;
  products?: any[];
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

const AdminUsers = ({ 
  users, 
  onAddUser,
  onUpdateUser,
  onDeleteUser
}: AdminUsersProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'Admin' });

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      const matchesSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           u.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = roleFilter === 'All' || u.role === roleFilter;
      const matchesStatus = statusFilter === 'All' || 
                           (statusFilter === 'Active' && !u.isBlocked) ||
                           (statusFilter === 'Blocked' && u.isBlocked);
      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchQuery, roleFilter, statusFilter]);

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.name || !newUser.email || !newUser.password) return;
    
    onAddUser({
      id: crypto.randomUUID(),
      name: newUser.name,
      email: newUser.email,
      password: newUser.password,
      role: newUser.role,
      joined: new Date().toISOString()
    });
    setNewUser({ name: '', email: '', password: '', role: 'Customer' });
    setIsAddingUser(false);
  };

  return (
    <AdminPageWrapper
      title="Admin Users"
      description="Manage staff, affiliates, and customer accounts."
      icon={UserPlus}
      options={[
        {"label":"Add New User","description":"Create a new user account with specific roles."},
        {"label":"Manage Access","description":"Block or unblock users from accessing the system."}
      ]}
      actions={
        <button 
          onClick={() => setIsAddingUser(true)}
          className="btn-primary flex items-center gap-2"
        >
          <UserPlus size={14} />
          <span>Add User</span>
        </button>
      }
      isEmpty={filteredUsers.length === 0}
      emptyState={
        <div className="space-y-4">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300">
            <UserIcon size={32} />
          </div>
          <p className="text-sm font-black text-slate-900 uppercase tracking-widest">No users found</p>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No users match your current filters.</p>
        </div>
      }
      toolbar={
        <AdminToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search users by name, email or ID..."
          filters={
            <div className="flex flex-wrap items-center gap-3">
              <select 
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="All">All Roles</option>
                {['Super Admin', 'Admin', 'Affiliate', 'Customer Support'].map(r => <option key={r} value={r}>{r}</option>)}
              </select>
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="All">All Status</option>
                <option value="Active">Active</option>
                <option value="Blocked">Blocked</option>
              </select>
            </div>
          }
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
        <Table>
          <TableHeader>
            <TableHead>User</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Joined</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableHeader>
          <TableBody>
            {filteredUsers.length > 0 ? filteredUsers.map((u, uIdx) => (
              <TableRow key={`${u.id}-${uIdx}`}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black border shadow-sm ${
                      u.role === 'Super Admin' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                      u.role === 'Admin' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                      u.role === 'Affiliate' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                      'bg-slate-50 text-slate-600 border-slate-200'
                    }`}>
                      {u.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{u.name}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{u.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    {u.role === 'Super Admin' || u.role === 'Admin' ? <Shield size={12} className="text-slate-400" /> : <UserIcon size={12} className="text-slate-400" />}
                    <span className="text-xs font-medium uppercase tracking-wider text-slate-600">
                      {u.role}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${u.isBlocked ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                    <span className={`text-xs font-medium uppercase tracking-wider ${u.isBlocked ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {u.isBlocked ? 'Blocked' : 'Active'}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2 text-slate-500">
                    <Calendar size={12} />
                    <span className="text-xs font-medium uppercase tracking-wider">
                      {new Date(u.joined).toLocaleDateString()}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button 
                      onClick={() => onUpdateUser(u.id, { ...u, isBlocked: !u.isBlocked })}
                      disabled={u.role === 'Super Admin'}
                      className={`p-2 rounded-lg transition-all ${u.role === 'Super Admin' ? 'opacity-30 cursor-not-allowed' : u.isBlocked ? 'text-emerald-600 hover:bg-emerald-50' : 'text-rose-600 hover:bg-rose-50'}`}
                      title={u.role === 'Super Admin' ? 'Super Admin cannot be blocked' : u.isBlocked ? 'Unblock User' : 'Block User'}
                    >
                      {u.isBlocked ? <UserCheck size={14} /> : <Ban size={14} />}
                    </button>
                    <button 
                      onClick={() => setShowDeleteConfirm(u.id)}
                      disabled={u.role === 'Super Admin'}
                      className={`p-2 rounded-lg transition-all ${u.role === 'Super Admin' ? 'opacity-30 cursor-not-allowed text-slate-400' : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'}`}
                      title={u.role === 'Super Admin' ? 'Super Admin cannot be deleted' : 'Delete User'}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={5} className="py-12 text-center">
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No users found</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      {/* Add User Modal */}
      <AnimatePresence>
        {isAddingUser && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-slate-900 text-white rounded-2xl shadow-lg">
                    <UserPlus size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-slate-950 uppercase italic tracking-tighter">Add New User</h2>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Create a staff or customer account</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsAddingUser(false)}
                  className="p-3 hover:bg-slate-200 rounded-2xl transition-colors text-slate-400 hover:text-slate-900"
                >
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleAddUserSubmit} className="p-8 space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Full Name *</label>
                    <div className="relative">
                      <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input
                        type="text"
                        required
                        value={newUser.name}
                        onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border-2 border-transparent focus:border-slate-900 focus:bg-white rounded-xl text-sm font-bold transition-all outline-none"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Email Address *</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input
                        type="email"
                        required
                        value={newUser.email}
                        onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border-2 border-transparent focus:border-slate-900 focus:bg-white rounded-xl text-sm font-bold transition-all outline-none"
                        placeholder="john@example.com"
                      />
                    </div>
                    {newUser.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newUser.email) && (
                      <p className="text-xs text-rose-500 font-bold uppercase tracking-widest mt-1 ml-1">Invalid email format</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Password *</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input
                        type="password"
                        required
                        value={newUser.password}
                        onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border-2 border-transparent focus:border-slate-900 focus:bg-white rounded-xl text-sm font-bold transition-all outline-none"
                        placeholder="••••••••"
                      />
                    </div>
                    {newUser.password && newUser.password.length < 6 && (
                      <p className="text-xs text-amber-500 font-bold uppercase tracking-widest mt-1 ml-1 italic">Security: 6+ characters recommended</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Access Role *</label>
                    <div className="relative">
                      <Shield className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <select
                        required
                        value={newUser.role}
                        onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                        className="w-full pl-11 pr-4 py-3 bg-slate-50 border-2 border-transparent focus:border-slate-900 focus:bg-white rounded-xl text-sm font-bold transition-all outline-none appearance-none cursor-pointer uppercase tracking-widest"
                      >
                        <option value="Admin">Administrator</option>
                        <option value="Affiliate">Affiliate Partner</option>
                        <option value="Customer Support">Customer Support</option>
                      </select>
                    </div>
                    <p className="text-xs text-slate-400 font-medium italic mt-1 ml-1 leading-relaxed">
                      {newUser.role === 'Admin' ? 'Full access to all permitted modules and configurations.' :
                       newUser.role === 'Affiliate' ? 'Access to affiliate tools, payouts, and assigned products.' :
                       'Help centre management, tickets, and order tracking.'}
                    </p>
                  </div>
                </div>

                <div className="pt-6 flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setIsAddingUser(false)}
                    className="flex-1 px-6 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-6 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20"
                  >
                    Create User
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Confirm Delete</h3>
                <button onClick={() => setShowDeleteConfirm(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex items-start gap-4">
                  <div className="p-2 bg-rose-500 text-white rounded-lg">
                    <Trash2 size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Irreversible Action</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      Are you sure you want to remove this user? This action cannot be undone and the user will lose all access to the system.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setShowDeleteConfirm(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={() => {
                    onDeleteUser(showDeleteConfirm);
                    setShowDeleteConfirm(null);
                  }}
                  className="px-8 py-3 bg-rose-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-950/20"
                >
                  Remove User
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default AdminUsers;
