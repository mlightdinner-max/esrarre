import React, { useState } from 'react';
import { 
  Globe, Mail, MessageSquare, Shield, Save, RefreshCw, 
  ExternalLink, Key, Server, Lock, Send, LifeBuoy
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';

interface AdminIntegrationsProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
  isValidating?: boolean;
}

export const AdminIntegrations = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, isValidating }: AdminIntegrationsProps) => {
  const [activeTab, setActiveTab] = useState<'email' | 'whatsapp' | 'webhook'>('email');

  const updateEmailSetting = (key: string, value: any, type: 'orders' | 'support') => {
    const section = type === 'orders' ? 'orderEmail' : 'supportEmail';
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        [section]: {
          ...(config.integrations?.[section] || {}),
          [key]: value
        }
      }
    });
  };

  const updateWhatsappSetting = (key: string, value: any) => {
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        whatsapp: {
          ...(config.integrations?.whatsapp || {}),
          [key]: value
        }
      }
    });
  };

  const updateWebhookSetting = (key: string, value: any) => {
    onUpdateConfig({
      ...config,
      integrations: {
        ...(config.integrations || {}),
        webhook: {
          ...(config.integrations?.webhook || {}),
          [key]: value
        }
      }
    });
  };

  const integrations = config.integrations || {};

  return (
    <AdminPageWrapper
      title="Integrations"
      description="Configure SMTP relays, messaging APIs, and custom webhooks for automated workflows."
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="bg-white border border-slate-200 p-1 rounded-2xl flex items-center gap-1 shadow-sm overflow-x-auto no-scrollbar">
          {[
            { id: 'email', label: 'Email (SMTP)', mobileLabel: 'Email', icon: Mail },
            { id: 'whatsapp', label: 'WhatsApp', mobileLabel: 'WhatsApp', icon: MessageSquare },
            { id: 'webhook', label: 'Webhooks', mobileLabel: 'Webhooks', icon: Globe }
          ].map((tab) => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeTab === tab.id ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <tab.icon size={12} />
              <span className="hidden xs:inline sm:inline">{tab.label}</span>
              <span className="xs:hidden sm:hidden">{tab.mobileLabel}</span>
            </button>
          ))}
        </div>
        
        {hasUnsavedChanges && (
          <button 
            onClick={onSave}
            disabled={isValidating}
            className="btn-primary flex items-center gap-2"
          >
            {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
            <span>Save Integrations</span>
          </button>
        )}
      </div>

      {activeTab === 'email' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          {/* Orders & Marketing SMTP */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Orders & Marketing</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Status Updates & Newsletters</p>
                </div>
              </div>
              <button 
                onClick={() => updateEmailSetting('enabled', !integrations.orderEmail?.enabled, 'orders')}
                className={`w-12 h-6 rounded-full transition-all relative ${integrations.orderEmail?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.orderEmail?.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">SMTP Host</label>
                <div className="relative">
                  <Server className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="smtp.example.com"
                    value={integrations.orderEmail?.host || ''}
                    onChange={(e) => updateEmailSetting('host', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Port</label>
                <input 
                  placeholder="587"
                  type="number"
                  value={integrations.orderEmail?.port || ''}
                  onChange={(e) => updateEmailSetting('port', parseInt(e.target.value), 'orders')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Username / Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="orders@store.com"
                    value={integrations.orderEmail?.user || ''}
                    onChange={(e) => updateEmailSetting('user', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="••••••••"
                    type="password"
                    value={integrations.orderEmail?.pass || ''}
                    onChange={(e) => updateEmailSetting('pass', e.target.value, 'orders')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="md:col-span-2 space-y-2 pt-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Default Sender Address</label>
                <input 
                  placeholder="Orders & Billing <orders@yourdomain.com>"
                  value={integrations.orderEmail?.from || ''}
                  onChange={(e) => updateEmailSetting('from', e.target.value, 'orders')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            
            <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100 flex items-start gap-4">
              <div className="p-2 bg-blue-100 text-blue-600 rounded-xl">
                <Shield size={16} />
              </div>
              <p className="text-xs text-blue-800 font-medium leading-relaxed">
                This identity will be used for all automated order status changes, shipping alerts, and newsletter campaigns.
              </p>
            </div>
          </div>

          {/* Support SMTP */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
                  <LifeBuoy size={24} className="animate-spin-slow" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Support Desk</h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Ticket Responses & Inquiries</p>
                </div>
              </div>
              <button 
                onClick={() => updateEmailSetting('enabled', !integrations.supportEmail?.enabled, 'support')}
                className={`w-12 h-6 rounded-full transition-all relative ${integrations.supportEmail?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.supportEmail?.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">SMTP Host</label>
                <div className="relative">
                  <Server className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="smtp.support-host.com"
                    value={integrations.supportEmail?.host || ''}
                    onChange={(e) => updateEmailSetting('host', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Port</label>
                <input 
                  placeholder="465 (SSL)"
                  type="number"
                  value={integrations.supportEmail?.port || ''}
                  onChange={(e) => updateEmailSetting('port', parseInt(e.target.value), 'support')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Username / Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="support@helpdesk.com"
                    value={integrations.supportEmail?.user || ''}
                    onChange={(e) => updateEmailSetting('user', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                  <input 
                    placeholder="••••••••"
                    type="password"
                    value={integrations.supportEmail?.pass || ''}
                    onChange={(e) => updateEmailSetting('pass', e.target.value, 'support')}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                </div>
              </div>
              <div className="md:col-span-2 space-y-2 pt-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Support From Address</label>
                <input 
                  placeholder="Customer Concierge <help@yourdomain.com>"
                  value={integrations.supportEmail?.from || ''}
                  onChange={(e) => updateEmailSetting('from', e.target.value, 'support')}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>

            <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100 flex items-start gap-4">
              <div className="p-2 bg-amber-100 text-amber-600 rounded-xl">
                <ExternalLink size={16} />
              </div>
              <p className="text-xs text-amber-800 font-medium leading-relaxed">
                Replies sent from the Ticketing System will use this specific identity, keeping support threads separate from marketing.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'whatsapp' && (
        <div className="max-w-3xl bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                <MessageSquare size={24} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">WhatsApp (Twilio)</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Official Messaging API</p>
              </div>
            </div>
            <button 
              onClick={() => updateWhatsappSetting('enabled', !integrations.whatsapp?.enabled)}
              className={`w-12 h-6 rounded-full transition-all relative ${integrations.whatsapp?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.whatsapp?.enabled ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-50">
            <div className="md:col-span-2 space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Account SID</label>
              <div className="relative">
                <ExternalLink className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="AC00000000000000000000000000000000"
                  value={integrations.whatsapp?.accountSid || ''}
                  onChange={(e) => updateWhatsappSetting('accountSid', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Auth Token</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="••••••••••••••••••••••••••••••••"
                  type="password"
                  value={integrations.whatsapp?.apiKey || ''}
                  onChange={(e) => updateWhatsappSetting('apiKey', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Sender Mobile Number</label>
              <div className="relative">
                <Send className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="+14150000000"
                  value={integrations.whatsapp?.fromNumber || ''}
                  onChange={(e) => updateWhatsappSetting('fromNumber', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'webhook' && (
        <div className="max-w-3xl bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center">
                <Globe size={24} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Outgoing Webhooks</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Real-time Event Streams</p>
              </div>
            </div>
            <button 
              onClick={() => updateWebhookSetting('enabled', !integrations.webhook?.enabled)}
              className={`w-12 h-6 rounded-full transition-all relative ${integrations.webhook?.enabled ? 'bg-slate-900' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-all ${integrations.webhook?.enabled ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          <div className="space-y-6 pt-4 border-t border-slate-50">
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Payload URL</label>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="https://api.yourbackend.com/webhooks/orders"
                  value={integrations.webhook?.url || ''}
                  onChange={(e) => updateWebhookSetting('url', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Secret Signature</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                <input 
                  placeholder="shsec_12345..."
                  type="password"
                  value={integrations.webhook?.secret || ''}
                  onChange={(e) => updateWebhookSetting('secret', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                />
              </div>
            </div>
            <div className="p-5 bg-purple-50/50 rounded-2xl border border-purple-100">
              <h4 className="text-xs font-medium text-purple-900 uppercase tracking-wider mb-2">Events Subscribed</h4>
              <div className="flex flex-wrap gap-2">
                {['order.created', 'order.updated', 'customer.registered', 'inventory.low'].map(event => (
                  <span key={event} className="px-3 py-1 bg-white border border-purple-100 rounded-lg text-xs font-bold text-purple-600 tracking-tight">
                    {event}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminPageWrapper>
  );
};
