import React from 'react';

interface TableProps {
  children: React.ReactNode;
  className?: string;
}

export const Table = ({ children, className = "" }: TableProps) => (
  <div className={`w-full overflow-x-auto ${className}`}>
    <table className="w-full text-left border-collapse">
      {children}
    </table>
  </div>
);

export const TableHeader = ({ children }: { children: React.ReactNode }) => (
  <thead>
    <tr className="bg-slate-50 border-b border-slate-200">
      {children}
    </tr>
  </thead>
);

export const TableHead = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <th scope="col" className={`px-4 py-3 section-label ${className}`}>
    {children}
  </th>
);

export const TableBody = ({ children }: { children: React.ReactNode }) => (
  <tbody className="divide-y divide-slate-100">
    {children}
  </tbody>
);

export const TableRow = ({ children, className = "", onClick }: { children: React.ReactNode, className?: string, onClick?: (e: React.MouseEvent<HTMLTableRowElement>) => void }) => (
  <tr className={`hover:bg-slate-50/50 transition-colors ${className}`} onClick={onClick}>
    {children}
  </tr>
);

export const TableCell = ({ children, className = "", colSpan }: { children: React.ReactNode, className?: string, colSpan?: number }) => (
  <td colSpan={colSpan} className={`px-4 py-4 ${className}`}>
    {children}
  </td>
);
