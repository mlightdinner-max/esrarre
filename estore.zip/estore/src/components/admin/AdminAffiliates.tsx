import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Edit2, Trash2, 
  X, Users 
} from 'lucide-react';
import { LOCALIZATION } from '../../constants';
import { Affiliate, Order } from '../../types';
import { 
  Table, 
  TableHeader, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell 
} from './AdminTable';

interface AdminAffiliatesProps {
  affiliates: Affiliate[];
  orders: Order[];
  onUpdateAffiliate: (id: string, a: any) => void;
  onDeleteAffiliate: (id: string) => void;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

const AdminAffiliates = ({ 
  affiliates, 
  orders, 
  onUpdateAffiliate, 
  onDeleteAffiliate, 
  onShowNotification 
}: AdminAffiliatesProps) => {
  const { id: routeAffiliateId } = useParams();
  const navigate = useNavigate();
  const basePath = window.location.pathname.startsWith('/home') ? '/home' : window.location.pathname.includes('/affiliate') ? '/affiliate' : '/home';

  const [searchQuery, setSearchQuery] = useState('');
  
  // Derive selected affiliate directly from URL — no setState in effect needed
  const editingAffiliate = routeAffiliateId
    ? (affiliates.find(a => a.id === routeAffiliateId) ?? null)
    : null;

  const handleCloseEditor = () => {
    navigate(`${basePath}/affiliates`);
  };

  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const affiliateStats = useMemo(() => {
    const stats: Record<string, { totalSales: number; totalOrders: number; totalCommission: number }> = {};
    affiliates.forEach(a => {
      const affiliateOrders = orders.filter(o => o.affiliateId === a.id);
      stats[a.id] = {
        totalSales: affiliateOrders.reduce((sum, o) => sum + o.total, 0),
        totalOrders: affiliateOrders.length,
        totalCommission: affiliateOrders.reduce((sum, o) => sum + (o.affiliatePayout || o.commissionAmount || 0), 0)
      };
    });
    return stats;
  }, [affiliates, orders]);

  const filteredAffiliates = useMemo(() => {
    return affiliates.filter(a => 
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      a.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.code.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [affiliates, searchQuery]);

  const handleSaveAffiliate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const affiliateData = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      code: formData.get('code') as string,
      status: 'Active',
      joinedAt: new Date().toISOString()
    };

    if (editingAffiliate) {
      onUpdateAffiliate(editingAffiliate.id, affiliateData);
      onShowNotification('Affiliate updated successfully', 'success');
      handleCloseEditor();
    }
  };

  return (
    <AdminPageWrapper
      title="Affiliate Partners"
      description="Manage affiliate partners, track their referrals, and monitor commission rates."
      icon={Users}
      options={[
        { label: 'Add Affiliate', description: 'Register a new affiliate partner with a custom commission rate.' },
        { label: 'Manage Status', description: 'Suspend or activate affiliate accounts.' }
      ]}
      isEmpty={filteredAffiliates.length === 0}
      emptyState={
        <div className="space-y-4">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300">
            <Users size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">No affiliates found</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your search terms or clearing filters.</p>
          </div>
          <button 
            onClick={() => setSearchQuery('')}
            className="text-xs font-medium text-slate-900 uppercase tracking-wider hover:underline pt-4"
          >
            Clear Search
          </button>
        </div>
      }
      toolbar={
        <AdminToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search by name, email or code..."
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
        <Table>
          <TableHeader>
            <TableHead>Affiliate</TableHead>
            <TableHead>Code</TableHead>
            <TableHead>Performance</TableHead>
            <TableHead>Earnings</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableHeader>
          <TableBody>
            {filteredAffiliates.length > 0 ? filteredAffiliates.map((affiliate) => {
              const stats = affiliateStats[affiliate.id] || { totalSales: 0, totalOrders: 0, totalCommission: 0 };
              return (
                <TableRow key={affiliate.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center border border-slate-200 text-slate-400">
                        <Users size={20} />
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{affiliate.name}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{affiliate.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="px-2 py-1 bg-slate-100 text-slate-900 rounded-md text-xs font-medium uppercase tracking-wider border border-slate-200">
                      {affiliate.code}
                    </code>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <p className="text-xs font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{stats.totalSales.toLocaleString()}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{stats.totalOrders} orders</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <p className="text-xs font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{stats.totalCommission.toLocaleString()}</p>
                  </TableCell>
                  <TableCell>
                    <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium uppercase tracking-wider ${
                      affiliate.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                    }`}>
                      <div className={`w-1 h-1 rounded-full ${affiliate.status === 'Active' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {affiliate.status}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => navigate(`${basePath}/affiliates/${affiliate.id}`)}
                        className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button 
                        onClick={() => setShowDeleteConfirm(affiliate.id)}
                        className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            }) : (
              <TableRow>
                <TableCell colSpan={6} className="py-20 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300 mb-4">
                    <Users size={32} />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">No affiliates found</h3>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your search terms</p>
                  </div>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="text-xs font-medium text-slate-900 uppercase tracking-wider hover:underline pt-4"
                  >
                    Clear Search
                  </button>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Affiliate Modal */}
      <AnimatePresence>
        {editingAffiliate && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-slate-900 text-white rounded-2xl shadow-lg">
                    <Users size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-slate-950 uppercase italic tracking-tighter">
                      Edit Affiliate
                    </h2>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                      Editing: {editingAffiliate.name}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={handleCloseEditor}
                  className="p-3 hover:bg-slate-200 rounded-2xl transition-colors text-slate-400 hover:text-slate-900"
                >
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleSaveAffiliate} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Full Name</label>
                    <input 
                      name="name"
                      required
                      defaultValue={editingAffiliate?.name}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all"
                      placeholder="e.g. John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Email Address</label>
                    <input 
                      name="email"
                      type="email"
                      required
                      defaultValue={editingAffiliate?.email}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all"
                      placeholder="e.g. john@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Affiliate Code</label>
                    <input 
                      name="code"
                      required
                      defaultValue={editingAffiliate?.code}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-slate-900 transition-all"
                      placeholder="e.g. SAVE20"
                    />
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-4">
                  <button 
                    type="button"
                    onClick={handleCloseEditor}
                    className="text-xs font-medium text-slate-500 uppercase tracking-wider"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="btn-primary"
                  >
                    Update Affiliate
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Confirm Delete</h3>
                <button onClick={() => setShowDeleteConfirm(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex items-start gap-4">
                  <div className="p-2 bg-rose-500 text-white rounded-lg">
                    <Trash2 size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Irreversible Action</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      Are you sure you want to remove this affiliate? This will disable their tracking code and stop all commission calculations.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setShowDeleteConfirm(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={() => {
                    onDeleteAffiliate(showDeleteConfirm);
                    onShowNotification('Affiliate removed successfully', 'success');
                    setShowDeleteConfirm(null);
                  }}
                  className="px-8 py-3 bg-rose-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-950/20"
                >
                  Remove Partner
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default AdminAffiliates;
