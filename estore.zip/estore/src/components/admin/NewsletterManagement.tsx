import React, { useState } from 'react';
import { Megaphone, Trash2, Users, Send, Mail, Calendar } from 'lucide-react';
import Modal from '../common/Modal';
import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

const NewsletterManagement = ({ config, onUpdateConfig, token }: { config: any; onUpdateConfig: (c: any) => void; token: string | null }) => {
  const subscribers = config.subscribers || [];
  const campaigns = config.campaigns || [];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCampaign, setNewCampaign] = useState({ subject: '', content: '', status: 'Draft' });
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'campaigns' | 'subscribers'>('campaigns');

  const handleSendCampaign = React.useCallback(async () => {
    try {
      const response = await fetch('/api/v1/newsletter/send-campaign', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newCampaign)
      });
      
      const data = await response.json();
      if (data.success) {
        const campaign = data.campaign;
        const newCampaigns = [campaign, ...(config.campaigns || [])];
        onUpdateConfig({ ...config, campaigns: newCampaigns });
        setIsModalOpen(false);
        setNewCampaign({ subject: '', content: '', status: 'Draft' });
      } else {
        alert(data.error || 'Failed to send campaign');
      }
    } catch (error) {
      console.error('Error sending campaign:', error);
      alert('Error sending campaign');
    }
  }, [newCampaign, config, onUpdateConfig, setIsModalOpen, setNewCampaign, token]);

  const handleDeleteSubscriber = React.useCallback((email: string) => {
    const subscribers = config.subscribers || [];
    const newSubscribers = subscribers.filter((s: any) => s.email !== email);
    onUpdateConfig({ ...config, subscribers: newSubscribers });
  }, [config, onUpdateConfig]);

  const filteredSubscribers = subscribers.filter((s: any) => 
    s.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredCampaigns = campaigns.filter((c: any) => 
    c.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminPageWrapper
      title="Newsletter"
      description="Design, send, and track email campaigns for your subscribers."
      icon={Mail}
      options={[{"label":"New Campaign","description":"Create and send a new newsletter campaign."},{"label":"Subscriber Audit","description":"Review and management your audience list."}]}
      actions={
        <button 
          onClick={() => setIsModalOpen(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Megaphone size={14} />
          <span>New Campaign</span>
        </button>
      }
      toolbar={
        <AdminToolbar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder={activeTab === 'campaigns' ? "Search campaigns by subject..." : "Search subscribers by email..."}
          leftActions={
            <div className="flex bg-slate-100 rounded-2xl p-1 w-fit">
              <button
                onClick={() => { setActiveTab('campaigns'); setSearchQuery(''); }}
                className={`px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${
                  activeTab === 'campaigns' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Send size={12} />
                Campaigns
              </button>
              <button
                onClick={() => { setActiveTab('subscribers'); setSearchQuery(''); }}
                className={`px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${
                  activeTab === 'subscribers' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Users size={12} />
                Subscribers
              </button>
            </div>
          }
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
        <Table>
          <TableHeader>
            {activeTab === 'campaigns' ? (
              <>
                <TableHead>Subject</TableHead>
                <TableHead>Audience</TableHead>
                <TableHead>Sent Date</TableHead>
                <TableHead>Status</TableHead>
              </>
            ) : (
              <>
                <TableHead>Email Address</TableHead>
                <TableHead>Joined Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </>
            )}
          </TableHeader>
          <TableBody>
            {activeTab === 'campaigns' ? (
              filteredCampaigns.length > 0 ? filteredCampaigns.map((campaign: any) => (
                <TableRow key={campaign.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-slate-400">
                        <Mail size={14} />
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{campaign.subject}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest line-clamp-1 max-w-xs">{campaign.content}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-slate-500">
                      <Users size={12} />
                      <span className="text-xs font-medium uppercase tracking-wider">{subscribers.length} Recipients</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar size={12} />
                      <span className="text-xs font-medium uppercase tracking-wider">{new Date(campaign.sentAt).toLocaleDateString()}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-medium uppercase tracking-wider">
                      {campaign.status}
                    </span>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={4} className="py-20 text-center">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No campaigns found</p>
                  </TableCell>
                </TableRow>
              )
            ) : (
              filteredSubscribers.length > 0 ? filteredSubscribers.map((sub: any, idx: number) => (
                <TableRow key={idx}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-50 rounded-lg border border-blue-100 text-blue-600">
                        <Users size={14} />
                      </div>
                      <span className="text-xs font-black text-slate-950 uppercase tracking-tight">{sub.email}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar size={12} />
                      <span className="text-xs font-medium uppercase tracking-wider">{new Date(sub.joinedAt).toLocaleDateString()}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <button 
                      onClick={() => handleDeleteSubscriber(sub.email)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                      title="Remove Subscriber"
                    >
                      <Trash2 size={14} />
                    </button>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={3} className="py-20 text-center">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No subscribers found</p>
                  </TableCell>
                </TableRow>
              )
            )}
          </TableBody>
        </Table>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Campaign">
        <div className="space-y-6">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Subject Line</label>
            <input 
              value={newCampaign.subject}
              onChange={e => setNewCampaign({ ...newCampaign, subject: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all" 
              placeholder="e.g., NEW COLLECTION LAUNCH!"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Campaign Content</label>
            <textarea 
              value={newCampaign.content}
              onChange={e => setNewCampaign({ ...newCampaign, content: e.target.value })}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all min-h-[200px] resize-none" 
              placeholder="Write your message here..."
            />
          </div>
          <div className="pt-4 flex gap-3">
            <button 
              onClick={() => setIsModalOpen(false)}
              className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button 
              onClick={handleSendCampaign}
              disabled={!newCampaign.subject || !newCampaign.content}
              className="flex-2 py-3 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-slate-950/20 disabled:opacity-50"
            >
              Send Campaign Now
            </button>
          </div>
        </div>
      </Modal>
    </AdminPageWrapper>
  );
};

export default NewsletterManagement;
