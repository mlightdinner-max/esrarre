import React, { useState } from 'react';
import { Database, Download, Upload, RotateCcw, AlertTriangle, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { AdminPageWrapper } from './AdminPageWrapper';

export const AdminBackupRestore = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const response = await fetch('/api/v1/dashboard/metrics/export', {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` }
      });
      const data = await response.json();
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setMessage({ type: 'success', text: 'Backup generated and downloaded successfully!' });
    } catch {
      setMessage({ type: 'error', text: 'Critical failure: Could not generate system backup.' });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const text = await file.text();
      let data;
      try {
        data = JSON.parse(text === "undefined" || !text.trim() ? "{}" : text);
      } catch (e) {
        throw new Error('Invalid JSON format in backup file.', { cause: e });
      }

      // Basic validation
      if (!data.products || !data.orders || !data.config) {
        throw new Error('Invalid backup file format. Missing core data structures.');
      }

      const base64Data = btoa(unescape(encodeURIComponent(JSON.stringify(data))));
      const response = await fetch('/api/v1/dashboard/metrics/load', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({ payload: base64Data })
      });

      if (response.ok) {
        setMessage({ type: 'success', text: 'System restored successfully. Refreshing environment...' });
        setTimeout(() => window.location.reload(), 3000);
      } else {
        throw new Error('Server rejected the backup data.');
      }
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || 'Restoration failed. Please check file integrity.' });
    } finally {
      setIsImporting(false);
      e.target.value = '';
    }
  };

  return (
    <AdminPageWrapper
      title="Backup & Restore"
      description="Safeguard your store data by creating backups and restoring from previous states."
      options={[{"label":"Create Backup","description":"Download a JSON file containing all store data."},{"label":"Restore","description":"Upload a backup file to restore your store state."}]}
    >
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-primary/5 text-primary rounded-xl flex items-center justify-center border border-primary/10 shadow-sm">
              <Database size={24} />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-slate-900">System Resilience</h2>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Manage infrastructure snapshots and data integrity.</p>
            </div>
          </div>
          
          {message && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`px-4 py-2 rounded-xl border flex items-center gap-2 shadow-sm ${
                message.type === 'success' 
                ? 'bg-primary/5 border-primary/10 text-primary-dark' 
                : 'bg-red-50 border-red-100 text-red-700'
              }`}
            >
              {message.type === 'success' ? <CheckCircle2 size={14} /> : <AlertCircle size={14} />}
              <span className="font-bold text-xs uppercase tracking-widest">{message.text}</span>
            </motion.div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Export */}
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6 group hover:bg-white hover:shadow-lg transition-all duration-300">
            <div className="space-y-2">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-slate-400 group-hover:text-slate-900 transition-colors shadow-sm border border-slate-200">
                <Download size={20} />
              </div>
              <h3 className="text-base font-bold tracking-tight text-slate-900">Snapshot Export</h3>
              <p className="text-xs text-slate-500 font-medium leading-relaxed">Generate a complete encrypted archive of your products, orders, customers, and system configurations.</p>
            </div>
            <button 
              onClick={handleExport}
              disabled={isExporting}
              className="w-full py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-slate-900/10 disabled:opacity-50 uppercase tracking-widest"
            >
              {isExporting ? <RotateCcw className="animate-spin" size={14} /> : <Download size={14} />}
              <span>Generate Backup</span>
            </button>
          </div>

          {/* Import */}
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6 group hover:bg-white hover:shadow-lg transition-all duration-300">
            <div className="space-y-2">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-slate-400 group-hover:text-primary transition-colors shadow-sm border border-slate-200">
                <Upload size={20} />
              </div>
              <h3 className="text-base font-bold tracking-tight text-slate-900">System Restoration</h3>
              <p className="text-xs text-slate-500 font-medium leading-relaxed">Restore your entire environment to a previous state using a verified system snapshot file.</p>
            </div>
            <div className="relative">
              <input 
                type="file" 
                accept=".json"
                onChange={handleImport}
                disabled={isImporting}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed z-10"
              />
              <button 
                className="w-full py-2.5 bg-white border border-dashed border-slate-300 text-slate-500 font-bold text-xs rounded-xl group-hover:border-primary/80 group-hover:text-primary transition-all flex items-center justify-center gap-2 disabled:opacity-50 uppercase tracking-widest"
              >
                {isImporting ? <RotateCcw className="animate-spin" size={14} /> : <Upload size={14} />}
                <span>Upload Snapshot</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 flex items-start gap-4">
          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-amber-600 shadow-sm border border-amber-100 shrink-0">
            <AlertTriangle size={20} />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-bold text-amber-900 tracking-tight">Destructive Action Warning</p>
            <p className="text-xs text-amber-700 font-medium leading-relaxed">
              Restoring from a snapshot will permanently overwrite all current data. This process is irreversible. Ensure you have a current backup before proceeding with any restoration.
            </p>
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};
