import React, { useState } from 'react';
import { Bell, Trash2, Mail, MessageSquare, Globe, Search, Phone, Clock, Save, RefreshCw } from 'lucide-react';
import { Config } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';

interface AdminNotificationsProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
  logs: any[];
  onNavigateToTaxonomy: () => void;
  onNavigateToIntegrations: () => void;
  onClearNotificationLogs: () => void;
  isValidating?: boolean;
}

export const AdminNotifications = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, logs, onNavigateToTaxonomy, onNavigateToIntegrations, onClearNotificationLogs, isValidating }: AdminNotificationsProps) => {
  const [activeTab, setActiveTab] = useState<'announcements' | 'settings' | 'history'>('announcements');
  const [activeStatus, setActiveStatus] = useState('Pending');
  const [searchQuery, setSearchQuery] = useState('');

  const statuses = (config.orderStatuses || []).map((s: any) => s.label);
  const displayStatuses = statuses.length > 0 ? statuses : ['Pending', 'Shipped', 'Delivered', 'Cancelled'];

  const filteredLogs = logs.filter(log => 
    log.orderId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.recipient?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.message?.toLowerCase().includes(searchQuery.toLowerCase())
  ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <AdminPageWrapper
      title="Notification Settings"
      description="Monitor outgoing alerts, order notifications, and delivery updates across all active channels."
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-white border border-slate-200 p-1 rounded-2xl flex items-center gap-1 shadow-sm overflow-x-auto no-scrollbar">
            <button 
              onClick={() => setActiveTab('announcements')}
              className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'announcements' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Announcements
            </button>
            <button 
              onClick={() => setActiveTab('settings')}
              className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'settings' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Dispatch Rules
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`px-3 sm:px-6 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeTab === 'history' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Transmission History
            </button>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {activeTab === 'history' && logs.length > 0 && (
            <button 
              onClick={onClearNotificationLogs}
              className="px-6 py-2.5 bg-rose-50 text-rose-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-rose-100 transition-all flex items-center gap-2 border border-rose-100"
            >
              <Trash2 size={14} />
              <span>Clear History</span>
            </button>
          )}

          {hasUnsavedChanges && activeTab !== 'history' && (
            <button 
              onClick={onSave}
              disabled={isValidating}
              className="btn-primary flex items-center gap-2"
            >
              {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
              <span>Save Dispatch Config</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'announcements' && (
        <div className="max-w-2xl bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 mb-1">
              <div className="p-1.5 bg-primary/5 text-primary rounded-lg">
                <Bell size={16} />
              </div>
              <h3 className="font-bold text-sm text-slate-900">Site-wide Announcements</h3>
            </div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">These messages appear at the top of your website for all visitors.</p>
            <div className="space-y-3">
              {(config.notifications || []).map((notif: any, idx: number) => (
                <div key={idx} className="flex items-center space-x-2 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                  <input 
                    placeholder="Announcement Message"
                    value={notif.message || ''}
                    onChange={(e) => {
                      const newNotifs = [...(config.notifications || [])];
                      newNotifs[idx].message = e.target.value;
                      onUpdateConfig({ ...config, notifications: newNotifs });
                    }}
                    className="flex-1 p-2 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10"
                  />
                  <button 
                    onClick={() => {
                      const newNotifs = config.notifications.filter((_: any, i: number) => i !== idx);
                      onUpdateConfig({ ...config, notifications: newNotifs });
                    }}
                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
              <button 
                onClick={() => onUpdateConfig({ 
                  ...config, 
                  notifications: [...(config.notifications || []), { id: crypto.randomUUID(), message: 'New announcement!' }] 
                })}
                className="w-full py-4 border-2 border-dashed border-slate-100 rounded-2xl text-slate-400 text-xs font-medium uppercase tracking-wider hover:border-slate-300 hover:text-slate-600 transition-all"
              >
                + Add Announcement
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'settings' ? (
        <div className="space-y-8">
          <div className="p-8 bg-amber-50 rounded-2xl border border-amber-100 flex items-start gap-6">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-amber-500 shadow-sm">
              <Mail size={24} />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-black text-amber-900 uppercase tracking-tight mb-2">Configure Transmission Channels</h3>
              <p className="text-xs text-amber-700/60 font-medium leading-relaxed max-w-2xl mb-4">
                SMTP credentials, WhatsApp API keys, and Webhook endpoints have been moved to the centralized <strong>External Integrations</strong> panel for improved security and dual-identity management.
              </p>
              <button 
                onClick={() => onNavigateToIntegrations()}
                className="px-6 py-2 bg-amber-500 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-amber-600 transition-all shadow-lg shadow-amber-500/20"
              >
                Go to Integrations
              </button>
            </div>
          </div>

          {/* Template Management */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight">Notification Templates</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Define messages for each order status across all enabled channels.</p>
              </div>
              <div className="flex items-center gap-1 p-1 bg-slate-50 rounded-xl border border-slate-100 overflow-x-auto">
                {displayStatuses.map((status, sIdx) => (
                  <button
                    key={`${status}-${sIdx}`}
                    onClick={() => setActiveStatus(status)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${activeStatus === status ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    {status}
                  </button>
                ))}
                <button 
                  onClick={onNavigateToTaxonomy}
                  className="px-2 py-1 text-xs font-medium uppercase tracking-wider text-slate-600 hover:bg-slate-100 rounded-lg transition-all"
                >
                  Edit Statuses
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div>
                <h4 className="text-xs font-bold text-slate-900">Enable Notifications for "{activeStatus}"</h4>
                <p className="text-xs text-slate-500 uppercase tracking-widest mt-0.5">Send notifications when an order changes to this status.</p>
              </div>
              <button 
                onClick={() => {
                  const currentDisabled = config.notificationSettings?.disabledStatuses || [];
                  const newDisabled = currentDisabled.includes(activeStatus)
                    ? currentDisabled.filter((s: string) => s !== activeStatus)
                    : [...currentDisabled, activeStatus];
                  onUpdateConfig({ ...config, notificationSettings: { ...config.notificationSettings, disabledStatuses: newDisabled } });
                }}
                className={`w-10 h-5 rounded-full transition-all relative ${!config.notificationSettings?.disabledStatuses?.includes(activeStatus) ? 'bg-slate-900' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${!config.notificationSettings?.disabledStatuses?.includes(activeStatus) ? 'left-5.5' : 'left-0.5'}`} />
              </button>
            </div>

            <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 transition-opacity ${config.notificationSettings?.disabledStatuses?.includes(activeStatus) ? 'opacity-50 pointer-events-none' : ''}`}>
              {/* Email Template */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-blue-600">
                  <Mail size={14} />
                  <span className="text-xs font-medium uppercase tracking-wider">Email Template</span>
                </div>
                <textarea 
                  rows={4}
                  value={config.notificationSettings?.email?.templates?.[activeStatus] || ''}
                  onChange={(e) => {
                    const newTemplates = { ...(config.notificationSettings?.email?.templates || {}), [activeStatus]: e.target.value };
                    onUpdateConfig({ ...config, notificationSettings: { ...config.notificationSettings, email: { ...config.notificationSettings?.email, templates: newTemplates } } });
                  }}
                  className="w-full p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10 leading-relaxed"
                  placeholder={`Hi {customerName}, your order {orderId} is now ${activeStatus.toLowerCase()}!`}
                />
              </div>

              {/* WhatsApp Template */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <MessageSquare size={14} />
                  <span className="text-xs font-medium uppercase tracking-wider">WhatsApp Template</span>
                </div>
                <textarea 
                  rows={4}
                  value={config.notificationSettings?.whatsapp?.templates?.[activeStatus] || ''}
                  onChange={(e) => {
                    const newTemplates = { ...(config.notificationSettings?.whatsapp?.templates || {}), [activeStatus]: e.target.value };
                    onUpdateConfig({ ...config, notificationSettings: { ...config.notificationSettings, whatsapp: { ...config.notificationSettings?.whatsapp, templates: newTemplates } } });
                  }}
                  className="w-full p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10 leading-relaxed"
                  placeholder={`Hi {customerName}, your order {orderId} is now ${activeStatus.toLowerCase()}!`}
                />
              </div>

              {/* Webhook Template */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-purple-600">
                  <Globe size={14} />
                  <span className="text-xs font-medium uppercase tracking-wider">Webhook Payload</span>
                </div>
                <textarea 
                  rows={4}
                  value={config.notificationSettings?.webhook?.templates?.[activeStatus] || ''}
                  onChange={(e) => {
                    const newTemplates = { ...(config.notificationSettings?.webhook?.templates || {}), [activeStatus]: e.target.value };
                    onUpdateConfig({ ...config, notificationSettings: { ...config.notificationSettings, webhook: { ...config.notificationSettings?.webhook, templates: newTemplates } } });
                  }}
                  className="w-full p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-500/10 leading-relaxed"
                  placeholder={`Order {orderId} status changed to ${activeStatus}.`}
                />
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <h4 className="text-xs font-medium uppercase tracking-wider text-slate-400 mb-3">Available Placeholders</h4>
              <div className="flex flex-wrap gap-2">
                {['{customerName}', '{orderId}', '{status}', '{total}', '{items}'].map(tag => (
                  <span key={tag} className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-600 tracking-wider">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={16} />
              <input 
                type="text"
                placeholder="Search history..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-slate-500/10 text-xs font-medium text-slate-900 placeholder:text-slate-400 transition-all"
              />
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100">
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Order ID</th>
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Recipient</th>
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider">Message</th>
                    <th className="px-6 py-3 text-xs font-medium text-slate-400 uppercase tracking-wider text-right">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredLogs.map((log, idx) => (
                    <tr key={`${log.id}-${idx}`} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-6 py-3">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${log.type === 'email' ? 'bg-blue-50 text-blue-600' : 'bg-primary/5 text-primary'}`}>
                          {log.type === 'email' ? <Mail size={14} /> : <Phone size={14} />}
                        </div>
                      </td>
                      <td className="px-6 py-3">
                        <span className="text-xs font-bold text-slate-900">#{log.orderId}</span>
                      </td>
                      <td className="px-6 py-3">
                        <span className="text-xs font-medium text-slate-600">{log.recipient}</span>
                      </td>
                      <td className="px-6 py-3">
                        <span className={`px-2 py-0.5 rounded-md text-xs font-medium uppercase tracking-wider ${
                          log.status === 'sent' ? 'bg-primary/5 text-primary' : 
                          log.status === 'failed' ? 'bg-red-50 text-red-600' : 
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {log.status}
                        </span>
                        {log.error && (
                          <p className="text-xs text-red-400 mt-0.5 max-w-[120px] truncate" title={log.error}>{log.error}</p>
                        )}
                      </td>
                      <td className="px-6 py-3">
                        <p className="text-xs text-slate-500 line-clamp-1 max-w-xs">{log.message}</p>
                      </td>
                      <td className="px-6 py-3 text-right">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-tighter">
                          {new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredLogs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center">
                        <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Clock size={20} className="text-slate-300" />
                        </div>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No notification history found.</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </AdminPageWrapper>
  );
};
