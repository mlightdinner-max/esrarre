import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, Plus, Edit2, Trash2, User, X, Sparkles, RefreshCw
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';
import { ImageInput } from './ImageInput';

interface BlogManagementProps {
  config: any;
  onUpdateConfig: (c: any) => void;
  user: any;
  token: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
  aiStatus?: any;
}

const BlogManagement = ({ config, onUpdateConfig, user, token, onShowNotification, aiStatus }: BlogManagementProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingPost, setEditingPost] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: '',
    category: 'News',
    content: '',
    image: '',
    author: user?.name || 'Admin',
    date: new Date().toISOString()
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const [isGenerating, setIsGenerating] = useState(false);

  const posts = config.blogPosts || [];

  const resetForm = () => {
    setIsAdding(false);
    setEditingPost(null);
    setFormData({
      title: '',
      category: 'News',
      content: '',
      image: '',
      author: user?.name || 'Admin',
      date: new Date().toISOString()
    });
  };

  const handleGenerateAI = async () => {
    if (!formData.title) {
        onShowNotification('Please enter a title first', 'error');
        return;
    }

    if (!aiStatus?.settings?.enabled || !aiStatus?.settings?.useBlogGeneration) {
        onShowNotification('AI Blog Generation is disabled in System Settings.', 'error');
        return;
    }

    if (!aiStatus?.isAvailable) {
        onShowNotification('AI is currently unavailable (Quota or Key issue).', 'error');
        return;
    }
    
    setIsGenerating(true);
    try {
        const response = await fetch('/api/v1/ai/generate-blog', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ 
                title: formData.title,
                category: formData.category,
                apiKey: aiStatus?.isUnsavedKey ? config.geminiApiKey : undefined
            })
        });
        
        const data = await response.json();
        if (data.content) {
            setFormData(prev => ({ ...prev, content: data.content }));
            onShowNotification('Content generated successfully', 'success');
        } else {
            throw new Error('Failed to generate content');
        }
    } catch (error: any) {
        onShowNotification(error.message || 'AI generation failed', 'error');
    } finally {
        setIsGenerating(false);
    }
  };

  const handleSave = () => {
    if (!formData.title || !formData.content) return;
    
    let newPosts;
    if (editingPost) {
      newPosts = posts.map((p: any) => p.id === editingPost.id ? { ...formData, id: p.id } : p);
    } else {
      newPosts = [{ ...formData, id: crypto.randomUUID() }, ...posts];
    }
    
    onUpdateConfig({ ...config, blogPosts: newPosts });
    resetForm();
  };

  const handleEdit = (post: any) => {
    setEditingPost(post);
    setFormData(post);
    setIsAdding(true);
  };

  const handleDelete = (id: string) => {
    const newPosts = posts.filter((p: any) => p.id !== id);
    onUpdateConfig({ ...config, blogPosts: newPosts });
  };

  const filteredPosts = posts.filter((p: any) => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminPageWrapper
      title="Blog Posts"
      description="Create, edit, and manage your store's blog posts."
      icon={BookOpen}
      options={[{"label":"New Post","description":"Create a new blog post."},{"label":"AI Generate Content","description":"Automatically generate blog content using AI."}]}
      actions={
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center space-x-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10"
        >
          <Plus size={16} />
          <span>New Post</span>
        </button>
      }
      toolbar={
        <AdminToolbar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search posts by title or category..."
        />
      }
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPosts.map((post: any) => (
          <motion.div 
            key={post.id}
            layout
            className="bg-white rounded-2xl border border-slate-200 overflow-hidden group hover:shadow-xl hover:shadow-slate-900/5 transition-all"
          >
            <div className="aspect-video bg-slate-100 relative overflow-hidden">
              {post.image ? (
                <img src={post.image} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-300">
                  <BookOpen size={32} />
                </div>
              )}
              <div className="absolute top-3 left-3">
                <span className="px-2 py-1 bg-white/90 backdrop-blur-md text-slate-900 rounded-lg text-xs font-medium uppercase tracking-wider shadow-sm">
                  {post.category}
                </span>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div className="space-y-1">
                <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{new Date(post.date).toLocaleDateString()}</p>
                <h3 className="text-sm font-bold text-slate-900 line-clamp-2 leading-tight">{post.title}</h3>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                    <User size={12} />
                  </div>
                  <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">{post.author}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleEdit(post)}
                    className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-all"
                    title="Edit Post"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button 
                    onClick={() => setShowDeleteConfirm(post.id)}
                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                    title="Delete Post"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  {editingPost ? 'Edit Blog Post' : 'Create New Post'}
                </h2>
                <button onClick={resetForm} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Title</label>
                    <input 
                      type="text"
                      value={formData.title}
                      onChange={e => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                      placeholder="Post title..."
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Category</label>
                    <select 
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                    >
                      <option value="News">News</option>
                      <option value="Guides">Guides</option>
                      <option value="Updates">Updates</option>
                      <option value="Stories">Stories</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <ImageInput 
                    label="Cover Image URL"
                    value={formData.image}
                    onChange={(url) => setFormData({ ...formData, image: url })}
                    token={token}
                    onShowNotification={onShowNotification}
                  />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Content</label>
                    <button 
                      onClick={handleGenerateAI}
                      disabled={isGenerating || !formData.title}
                      className="flex items-center space-x-2 px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-medium uppercase tracking-wider hover:bg-slate-800 transition-all disabled:opacity-50"
                    >
                      {isGenerating ? <RefreshCw size={10} className="animate-spin" /> : <Sparkles size={10} />}
                      <span>Generate with AI</span>
                    </button>
                  </div>
                  <textarea 
                    value={formData.content}
                    onChange={e => setFormData({ ...formData, content: e.target.value })}
                    rows={8}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none"
                    placeholder="Write your post content..."
                  />
                </div>
              </div>
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end space-x-3">
                <button 
                  onClick={resetForm}
                  className="px-6 py-2.5 text-xs font-medium uppercase tracking-wider text-slate-500 hover:text-slate-900 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  className="btn-primary"
                >
                  {editingPost ? 'Update Post' : 'Publish Post'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">Confirm Delete</h3>
                <button onClick={() => setShowDeleteConfirm(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 space-y-6">
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 flex items-start gap-4">
                  <div className="p-2 bg-rose-500 text-white rounded-lg">
                    <Trash2 size={16} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-900 uppercase tracking-tight">Irreversible Action</p>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed mt-1">
                      Are you sure you want to remove this blog post? This will permanently delete the content from your store's blog section.
                    </p>
                  </div>
                </div>
              </div>
              <div className="p-5 sm:p-8 flex items-center justify-end gap-4 bg-slate-50/50">
                <button onClick={() => setShowDeleteConfirm(null)} className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cancel</button>
                <button 
                  onClick={() => {
                    handleDelete(showDeleteConfirm);
                    setShowDeleteConfirm(null);
                  }}
                  className="px-8 py-3 bg-rose-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-lg shadow-rose-950/20"
                >
                  Remove Post
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default BlogManagement;
