import React from 'react';
import { Target, Eye, Image as ImageIcon, Users, Plus, Trash2 } from 'lucide-react';
import { Config } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';
import { ImageInput } from './ImageInput';

interface AdminAboutPageProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  token?: string | null;
  onShowNotification: (m: string, t?: 'success' | 'error' | 'info') => void;
}

const AdminAboutPage = ({ config, onUpdateConfig, token, onShowNotification }: AdminAboutPageProps) => {
  return (
    <AdminPageWrapper
      title="About Us Content"
      description="Edit the story, mission, and team information displayed on your About Us page."
      options={[{"label":"Update Story","description":"Modify the main text and imagery for your brand story."},{"label":"Manage Team","description":"Add or remove team member profiles."}]}
    >
      <div className="max-w-5xl space-y-6">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Page Title</label>
                <input 
                  value={config.aboutTitle || ''} 
                  onChange={(e) => onUpdateConfig({ ...config, aboutTitle: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 font-bold text-xs" 
                />
              </div>
              <div className="space-y-1">
                <ImageInput 
                  label="Hero Image URL"
                  value={config.aboutHeroImage || ''}
                  onChange={(url) => onUpdateConfig({...config, aboutHeroImage: url})}
                  token={token}
                  onShowNotification={onShowNotification}
                />
              </div>
            </div>

            <div className="hidden lg:block relative aspect-video lg:aspect-auto lg:h-full rounded-xl overflow-hidden border border-slate-200 shadow-sm bg-slate-50">
              {config.aboutHeroImage ? (
                <img 
                  src={config.aboutHeroImage || undefined} 
                  alt="About Hero" 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer" 
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-300">
                  <ImageIcon size={24} />
                </div>
              )}
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Main Story Content (Markdown)</label>
            <textarea 
              value={config.aboutContent || ''} 
              onChange={(e) => onUpdateConfig({ ...config, aboutContent: e.target.value })}
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 font-mono text-xs h-[250px] leading-relaxed" 
              placeholder="# Our Story..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-900">
                <Target size={14} />
                <h4 className="font-bold text-xs uppercase tracking-widest">Our Mission</h4>
              </div>
              <textarea 
                value={config.aboutMission || ''} 
                onChange={(e) => onUpdateConfig({ ...config, aboutMission: e.target.value })}
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 h-20 text-xs font-medium leading-relaxed" 
              />
            </div>
            <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center space-x-2 text-slate-900">
                <Eye size={14} />
                <h4 className="font-bold text-xs uppercase tracking-widest">Our Vision</h4>
              </div>
              <textarea 
                value={config.aboutVision || ''} 
                onChange={(e) => onUpdateConfig({ ...config, aboutVision: e.target.value })}
                className="w-full p-2.5 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/5 h-20 text-xs font-medium leading-relaxed" 
              />
            </div>
          </div>
        </div>

        {/* Team Management */}
        <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
                <Users size={20} />
              </div>
              <div className="space-y-0.5">
                <h3 className="text-sm font-black text-slate-950 uppercase italic tracking-tighter">Team Leadership</h3>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Showcase the people behind the brand.</p>
              </div>
            </div>
            <button 
              onClick={() => {
                const newTeam = [...(config.team || []), { name: '', role: '', image: '' }];
                onUpdateConfig({ ...config, team: newTeam });
              }}
              className="btn-primary flex items-center gap-2"
            >
              <Plus size={14} />
              <span>Add Member</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(config.team || []).map((member: any, idx: number) => (
              <div key={idx} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4 group relative shadow-sm">
                <button 
                  onClick={() => {
                    const newTeam = config.team.filter((_: any, i: number) => i !== idx);
                    onUpdateConfig({ ...config, team: newTeam });
                  }}
                  className="absolute top-4 right-4 p-2 text-slate-400 hover:text-rose-600 hover:bg-white rounded-xl transition-all border border-transparent hover:border-rose-100"
                >
                  <Trash2 size={14} />
                </button>

                <div className="space-y-4 pt-2">
                  <ImageInput 
                    label="Profile Photo"
                    value={member.image || ''}
                    onChange={(url) => {
                      const newTeam = [...config.team];
                      newTeam[idx].image = url;
                      onUpdateConfig({ ...config, team: newTeam });
                    }}
                    token={token}
                    onShowNotification={onShowNotification}
                  />

                  <div className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Full Name</label>
                      <input 
                        value={member.name || ''}
                        onChange={(e) => {
                          const newTeam = [...config.team];
                          newTeam[idx].name = e.target.value;
                          onUpdateConfig({ ...config, team: newTeam });
                        }}
                        className="w-full p-2.5 bg-white border border-slate-100 rounded-lg text-xs font-bold text-slate-900 focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Position / Role</label>
                      <input 
                        value={member.role || ''}
                        onChange={(e) => {
                          const newTeam = [...config.team];
                          newTeam[idx].role = e.target.value;
                          onUpdateConfig({ ...config, team: newTeam });
                        }}
                        className="w-full p-2.5 bg-white border border-slate-100 rounded-lg text-xs font-medium text-slate-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AdminAboutPage;
