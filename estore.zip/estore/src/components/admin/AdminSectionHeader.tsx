import React from 'react';
import { LucideIcon } from 'lucide-react';

interface AdminSectionHeaderProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  options?: { label: string; description: string }[];
}

export const AdminSectionHeader: React.FC<AdminSectionHeaderProps> = ({ title, description, icon: Icon, options: _options }) => {
  return (
    <div className="mb-6 md:mb-8 p-5 md:p-8 bg-white border border-slate-200 rounded-2xl shadow-sm relative overflow-hidden group">
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-slate-50 rounded-full transition-transform duration-1000 group-hover:scale-110 hidden sm:block" />
      
      <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          {Icon && (
            <div className="p-4 bg-slate-900 text-white rounded-[1.5rem] shadow-xl shadow-slate-900/10 shrink-0">
              <Icon size={24} />
            </div>
          )}
          <div>
            <h2 className="premium-heading text-2xl sm:text-3xl md:text-4xl text-slate-950 mb-1 leading-none">{title}</h2>
            <p className="section-label leading-none mt-1">{description}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
