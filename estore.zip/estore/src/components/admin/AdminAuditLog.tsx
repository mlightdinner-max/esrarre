import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface AdminAuditLogProps {
  logs: any[];
  setActiveTab: (t: string) => void;
  setStatusFilter: (s: string | null) => void;
}

export const AdminAuditLog = ({ logs, setActiveTab, setStatusFilter }: AdminAuditLogProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      (log.userName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.action || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      JSON.stringify(log.details || {}).toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    return matchesSearch && matchesAction;
  }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage);
  const paginatedLogs = filteredLogs.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const actions = Array.from(new Set(logs.map(l => l.action)));

  return (
    <AdminPageWrapper
      title="Activity Logs"
      description="Track administrative actions and changes made within the admin panel for security and compliance."
      options={[{"label":"Search Logs","description":"Find specific actions by user or event type."},{"label":"Filter by Action","description":"View logs for specific administrative tasks."}]}
    >
      <div className="flex justify-end mb-6">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative group min-w-[240px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={16} />
            <input 
              type="text"
              placeholder="Search logs..."
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all shadow-sm"
            />
          </div>
          <select 
            value={actionFilter}
            onChange={e => {
              setActionFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-6 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
          >
            <option value="all">All Actions</option>
            {actions.map(action => (
              <option key={action} value={action}>{action}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm mt-10">

        <div className="p-6">
          <Table>
            <TableHeader>
              <TableHead>Timestamp</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Details</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableHeader>
            <TableBody>
              {paginatedLogs.length > 0 ? paginatedLogs.map((log, idx) => (
                <TableRow key={`${log.id}-${idx}`}>
                  <TableCell>
                    <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="text-xs font-black text-slate-950 uppercase tracking-tight">{log.userName}</span>
                      <span className="text-xs font-medium uppercase tracking-wider text-slate-400">{log.userRole}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="px-2 py-0.5 bg-slate-100 rounded-full text-xs font-medium uppercase tracking-wider text-slate-600">
                      {log.action?.split('_').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ')}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="max-w-md overflow-x-auto">
                      {log.details && typeof log.details === 'object' ? (
                        <div className="space-y-1.5">
                          {Object.entries(log.details).map(([key, value]) => (
                            <div key={key} className="flex flex-col space-y-0.5">
                              <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{key}</span>
                              <div className="text-xs font-bold text-slate-600 bg-slate-100/50 px-2 py-1 rounded border border-slate-200/50 break-words">
                                {typeof value === 'object' ? (
                                  <pre className="whitespace-pre-wrap font-mono text-xs leading-tight">
                                    {JSON.stringify(value, null, 2)}
                                  </pre>
                                ) : String(value)}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-xs text-slate-500 italic">No details available</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {log.action?.includes('ORDER') && log.details?.orderId && (
                        <button 
                          onClick={() => {
                            setStatusFilter(null);
                            setActiveTab('orders');
                          }}
                          className="btn-primary"
                        >
                          View Order
                        </button>
                      )}
                      {log.action?.includes('PRODUCT') && log.details?.productId && (
                        <button 
                          onClick={() => setActiveTab('products')}
                          className="btn-primary"
                        >
                          View Product
                        </button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={5} className="py-12 text-center">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No logs found</p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {totalPages > 1 && (
          <div className="px-6 py-4 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black text-slate-600 disabled:opacity-50 hover:bg-slate-50 transition-all uppercase tracking-widest shadow-sm"
              >
                Prev
              </button>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black text-slate-600 disabled:opacity-50 hover:bg-slate-50 transition-all uppercase tracking-widest shadow-sm"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </AdminPageWrapper>
  );
};
