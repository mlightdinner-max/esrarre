import React, { useState, useMemo } from 'react';
import { Truck, RotateCcw, Search, Package, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';
import { Order } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';
import { LOCALIZATION } from '../../constants';
import { 
  Table, 
  TableHeader, 
  TableHead, 
  TableBody, 
  TableRow, 
  TableCell 
} from './AdminTable';

interface AdminShippingReturnsProps {
  orders: Order[];
  onUpdateStatus: (id: string, status: string) => void;
  onUpdateItemStatus: (orderId: string, itemId: string, status: 'Active' | 'Cancelled' | 'Returned' | 'Processing' | 'Return Rejected', reason?: string) => void;
  config: any;
  onNavigateToOrder?: (orderId: string) => void;
}

export const AdminShippingReturns = ({ orders, onUpdateStatus: _onUpdateStatus, onUpdateItemStatus, config: _config, onNavigateToOrder }: AdminShippingReturnsProps) => {
  const [activeTab, setActiveTab] = useState<'shipping' | 'returns' | 'requests'>('shipping');
  const [searchQuery, setSearchQuery] = useState('');

  const shippingOrders = useMemo(() => {
    return orders.filter(o => 
      ['Pending', 'Processing', 'Shipped', 'Delivered'].includes(o.status) &&
      !o.items.some(i => ['Return Requested', 'Cancellation Requested'].includes(i.status || '')) &&
      (o.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
       o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
       o.email.toLowerCase().includes(searchQuery.toLowerCase()))
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [orders, searchQuery]);

  const returnOrders = useMemo(() => {
    return orders.filter(o => 
      ['Returned', 'Cancelled'].includes(o.status) &&
      (o.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
       o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
       o.email.toLowerCase().includes(searchQuery.toLowerCase()))
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [orders, searchQuery]);

  const requestOrders = useMemo(() => {
    return orders.filter(o => 
      o.items.some(i => ['Return Requested', 'Cancellation Requested'].includes(i.status || '')) &&
      (o.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
       o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
       o.email.toLowerCase().includes(searchQuery.toLowerCase()))
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [orders, searchQuery]);

  const displayedOrders = activeTab === 'shipping' ? shippingOrders : activeTab === 'returns' ? returnOrders : requestOrders;

  const stats = useMemo(() => {
    const requestsCount = orders.filter(o => o.items.some(i => ['Return Requested', 'Cancellation Requested'].includes(i.status || ''))).length;
    return {
      pending: orders.filter(o => o.status === 'Pending').length,
      processing: orders.filter(o => o.status === 'Processing').length,
      shipped: orders.filter(o => o.status === 'Shipped').length,
      returns: orders.filter(o => o.status === 'Returned').length,
      requests: requestsCount
    };
  }, [orders]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pending':
      case 'Processing':
        return <Package className="text-amber-500" size={16} />;
      case 'Shipped':
        return <Truck className="text-blue-500" size={16} />;
      case 'Delivered':
        return <CheckCircle2 className="text-emerald-500" size={16} />;
      case 'Returned':
        return <RotateCcw className="text-purple-500" size={16} />;
      case 'Cancelled':
        return <AlertTriangle className="text-rose-500" size={16} />;
      default:
        return <Package className="text-slate-400" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending':
      case 'Processing':
        return 'bg-amber-100 text-amber-800';
      case 'Shipped':
        return 'bg-blue-100 text-blue-800';
      case 'Delivered':
        return 'bg-emerald-100 text-emerald-800';
      case 'Returned':
      case 'Return':
        return 'bg-purple-100 text-purple-800';
      case 'Cancelled':
        return 'bg-rose-100 text-rose-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <AdminPageWrapper
      title="Delivery & Returns"
      description="Manage shipping statuses and process returns or cancellations."
      icon={Truck}
      options={[{"label":"Shipping Tracking","description":"View and update orders that are pending, processing, shipped, or delivered."},{"label":"Returns & Adjustments","description":"Process returned items and manage order cancellations."}]}
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Pending Shipments', value: stats.pending, color: 'text-amber-600', bg: 'bg-amber-50', icon: Package },
          { label: 'In Processing', value: stats.processing, color: 'text-blue-600', bg: 'bg-blue-50', icon: RefreshCw },
          { label: 'Shipped Today', value: stats.shipped, color: 'text-emerald-600', bg: 'bg-emerald-50', icon: Truck },
          { label: 'Awaiting Approval', value: stats.requests, color: 'text-rose-600', bg: 'bg-rose-50', icon: AlertTriangle },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{stat.label}</p>
              <p className={`text-2xl font-black ${stat.color} tracking-tighter`}>{stat.value}</p>
            </div>
            <div className={`p-3 ${stat.bg} ${stat.color} rounded-2xl`}>
              <stat.icon size={20} />
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="relative group flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={18} />
          <input 
            type="text"
            placeholder="SEARCH ORDERS..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-6 py-2.5 bg-white border border-slate-200 focus:border-slate-900 rounded-xl text-xs font-medium uppercase tracking-wider transition-all outline-none"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 overflow-x-auto no-scrollbar">
            <button 
              onClick={() => setActiveTab('shipping')}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${activeTab === 'shipping' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <Truck size={12} />
              Shipping
            </button>
            <button 
              onClick={() => setActiveTab('returns')}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${activeTab === 'returns' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <RotateCcw size={12} />
              Returns
            </button>
            <button 
              onClick={() => setActiveTab('requests')}
              className={`px-4 py-1.5 rounded-lg text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${activeTab === 'requests' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <AlertTriangle size={12} />
              Awaiting Approval
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/60 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Total</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableHeader>
            <TableBody>
              {displayedOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-black text-slate-950 uppercase tracking-tight">{order.id}</TableCell>
                  <TableCell>
                    <div className="font-black text-slate-950 uppercase tracking-tight">{order.customerName}</div>
                    <div className="text-xs text-slate-400 font-bold uppercase tracking-widest">{order.email}</div>
                  </TableCell>
                  <TableCell className="text-slate-500 font-medium">{new Date(order.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider ${getStatusColor(order.status)}`}>
                      {getStatusIcon(order.status)}
                      {order.status}
                    </span>
                  </TableCell>
                  <TableCell className="font-black text-slate-950 tracking-tighter text-lg">{LOCALIZATION.CURRENCY}{order.total.toLocaleString()}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {activeTab === 'requests' ? (
                        <div className="flex items-center gap-2">
                           {order.items.filter(i => ['Return Requested', 'Cancellation Requested'].includes(i.status || '')).map(item => (
                             <div key={item.id} className="flex flex-col items-end gap-1 p-2 bg-slate-50 border border-slate-100 rounded-xl">
                               <span className="text-xs font-black uppercase text-slate-900">{item.name}</span>
                               <span className="text-xs font-bold text-slate-500 uppercase">{item.status}</span>
                               <div className="flex items-center gap-1 mt-1">
                                 <button 
                                   onClick={() => onUpdateItemStatus(order.id, item.id, item.status === 'Cancellation Requested' ? 'Cancelled' : 'Returned')}
                                   className="px-2 py-1 bg-emerald-500 text-white rounded text-xs font-black uppercase hover:bg-emerald-600 transition-colors"
                                 >
                                   Approve
                                 </button>
                                 <button 
                                   onClick={() => onUpdateItemStatus(order.id, item.id, item.status === 'Cancellation Requested' ? 'Processing' : 'Return Rejected')}
                                   className="px-2 py-1 bg-rose-500 text-white rounded text-xs font-black uppercase hover:bg-rose-600 transition-colors"
                                 >
                                   Reject
                                 </button>
                               </div>
                             </div>
                           ))}
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-1 mr-2 px-2 py-1">
                            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider italic">Update in Details</span>
                          </div>
                          <button 
                            onClick={() => onNavigateToOrder && onNavigateToOrder(order.id)}
                            className="btn-primary"
                          >
                            View Details
                          </button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {displayedOrders.length === 0 && (
          <div className="py-20 text-center space-y-3">
            <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto text-slate-300">
              <Package size={24} />
            </div>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
              No {activeTab} orders found matching your search.
            </p>
          </div>
        )}
      </div>
    </AdminPageWrapper>
  );
};

export default AdminShippingReturns;
