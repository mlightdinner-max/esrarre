import { 
  LayoutDashboard, Activity, DollarSign, TrendingUp, Package, ImageIcon, 
  Layers, ShoppingBag, Truck, Tag, Users, Settings, Mail, BookOpen, 
  Bell, LifeBuoy, Info, Palette, Layout, Home, FileText, Eye, UserPlus, 
  ShieldCheck, History, Database, Brain, ShieldAlert, Globe
} from 'lucide-react';

export const ADMIN_MENU_GROUPS = [
  {
    id: 'analytics-group',
    label: 'Analytics & Insights',
    affiliateLabel: 'Affiliate Hub',
    items: [
      { id: '', label: 'Home', affiliateLabel: 'Affiliate Home', icon: Home },
      { id: 'dashboard', label: 'Overview', affiliateLabel: 'Affiliate Dashboard', icon: LayoutDashboard },
      { id: 'live', label: 'Live Traffic', icon: Activity },
      { id: 'revenue', label: 'Revenue & Sales', icon: DollarSign },
      { id: 'profit', label: 'Profit Margins', icon: TrendingUp, superAdminOnly: true },
    ]
  },
  {
    id: 'inventory-group',
    label: 'Inventory & Media',
    affiliateLabel: 'Promotions',
    items: [
      { id: 'products', label: 'Products', affiliateLabel: 'Promote', icon: Package },
      { id: 'media', label: 'Media Library', icon: ImageIcon },
      { id: 'categories-tags', label: 'Categories & Tags', icon: Layers },
    ]
  },
  {
    id: 'operations',
    label: 'Operations',
    affiliateLabel: 'My Referrals',
    items: [
      { id: 'orders', label: 'Orders', affiliateLabel: 'Referral History', icon: ShoppingBag },
      { id: 'delivery-returns', label: 'Delivery & Returns', icon: Truck },
      { id: 'coupons', label: 'Coupons & Offers', icon: Tag },
    ]
  },
  {
    id: 'growth',
    label: 'Growth & Marketing',
    items: [
      { id: 'customers', label: 'Customers', icon: Users },
      { id: 'affiliates', label: 'Affiliate Partners', icon: Users },
      { id: 'affiliate-programme', label: 'Affiliate Programme', icon: Settings },
      { id: 'affiliate-payouts', label: 'Affiliate Payouts', icon: DollarSign },
      { id: 'newsletter', label: 'Newsletter', icon: Mail },
      { id: 'blog-posts', label: 'Blog Posts', icon: BookOpen },
    ]
  },
  {
    id: 'support-group',
    label: 'Customer Support',
    items: [
      { id: 'notifications', label: 'Notification Settings', icon: Bell },
      { id: 'support', label: 'Support Tickets', icon: LifeBuoy },
      { id: 'help-center', label: 'Help Centre Content', icon: Info },
    ]
  },
  {
    id: 'experience',
    label: 'Storefront Settings',
    items: [
      { id: 'store-branding', label: 'Store Branding', icon: Palette },
      { id: 'navigation', label: 'Navigation & Layout', icon: Layout },
      { id: 'home-page', label: 'Home Page Settings', icon: Home },
      { id: 'about-us', label: 'About Us Content', icon: Info, superAdminOnly: true },
      { id: 'legal-pages', label: 'Legal Pages', icon: FileText, superAdminOnly: true },
      { id: 'seo-visibility', label: 'SEO & Visibility', icon: Eye },
    ]
  },
  {
    id: 'system-group',
    label: 'System & Security',
    items: [
      { id: 'general-settings', label: 'General Settings', icon: Settings },
      { id: 'users', label: 'Admin Users', icon: UserPlus },
      { id: 'permissions', label: 'Permissions & Roles', icon: ShieldCheck, superAdminOnly: true },
      { id: 'integrations', label: 'Integrations', icon: Globe, superAdminOnly: true },
      { id: 'activity-logs', label: 'Activity Logs', icon: History, superAdminOnly: true },
      { id: 'backups', label: 'Backup & Restore', icon: Database, superAdminOnly: true },
      { id: 'system-monitor', label: 'System Monitor', icon: Activity },
      { id: 'ai-settings', label: 'AI Settings', icon: Brain },
      { id: 'system-configuration', label: 'System Configuration', icon: ShieldAlert, superAdminOnly: true },
    ]
  }
];
