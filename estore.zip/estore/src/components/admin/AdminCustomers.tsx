import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Mail, Phone, MapPin, Copy, Eye, Users, History, ShieldAlert, CheckCircle, ArrowLeft } from 'lucide-react';
import { AnimatePresence } from 'motion/react';
import { Order, Customer } from '../../types';
import { LOCALIZATION } from '../../constants';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from './AdminTable';

interface AdminCustomersProps {
  customers: Customer[];
  orders: Order[];
  onUpdateStatus: (id: string, status: string) => void;
  onUpdateItemStatus: (orderId: string, itemId: string, status: 'Active' | 'Cancelled', reason?: string) => void;
  onUpdateCustomerStatus?: (id: string, status: 'Active' | 'Blocked') => void;
  config: any;
  externalSelectedCustomerId?: string | null;
  onClearExternalSelection?: () => void;
  onNavigateToOrder?: (orderId: string) => void;
}

import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

export const AdminCustomers = ({ 
  customers,
  orders,
  onUpdateItemStatus: _onUpdateItemStatus,
  onNavigateToOrder,
  onUpdateCustomerStatus,
  externalSelectedCustomerId,
  onClearExternalSelection
}: AdminCustomersProps) => {
  const { id: routeCustomerId } = useParams();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const selectedCustomer = useMemo(() => {
    if (externalSelectedCustomerId) {
      return customers.find(c => c.id === externalSelectedCustomerId) || null;
    }
    if (routeCustomerId) {
      return customers.find(c => c.id === routeCustomerId) || null;
    }
    return null;
  }, [routeCustomerId, externalSelectedCustomerId, customers]);

  // Handle clearing external selection if needed
  React.useEffect(() => {
    if (externalSelectedCustomerId && selectedCustomer && onClearExternalSelection) {
      onClearExternalSelection();
    }
  }, [externalSelectedCustomerId, selectedCustomer, onClearExternalSelection]);

  const [sortBy, setSortBy] = useState<'name' | 'spent' | 'orders' | 'recent'>('recent');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Blocked'>('All');

  const filteredCustomers = useMemo(() => {
    const filtered = customers.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.phone.includes(searchQuery);
      
      const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name': return a.name.localeCompare(b.name);
        case 'spent': return b.totalSpent - a.totalSpent;
        case 'orders': return b.totalOrders - a.totalOrders;
        case 'recent': return new Date(b.lastOrderDate).getTime() - new Date(a.lastOrderDate).getTime();
        default: return 0;
      }
    });
  }, [customers, searchQuery, sortBy, statusFilter]);

  const customerOrders = useMemo(() => {
    if (!selectedCustomer) return [];
    return orders.filter(o => o.customerId === selectedCustomer.id || o.email === selectedCustomer.email || o.phone === selectedCustomer.phone)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [selectedCustomer, orders]);

  const basePath = window.location.pathname.startsWith('/home') ? '/home' : window.location.pathname.includes('/affiliate') ? '/affiliate' : '/home';

  if (routeCustomerId && selectedCustomer) {
    return (
      <AdminPageWrapper
        title="Customers"
        description={`Viewing detailed history and records for ${selectedCustomer.name}`}
        icon={Users}
        actions={
          <button 
            onClick={() => navigate(`${basePath}/customers`)}
            className="flex items-center space-x-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg active:scale-95 group"
          >
            <ArrowLeft size={16} />
            <span>Back to Customers</span>
          </button>
        }
      >
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200">
          <div className="p-5 sm:p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-xl font-black italic shadow-lg">
                {selectedCustomer.name.charAt(0)}
              </div>
              <div>
                <h2 className="text-2xl font-black text-slate-950 uppercase italic tracking-tighter">{selectedCustomer.name}</h2>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">#{selectedCustomer.id}</p>
              </div>
            </div>
            <div className="flex gap-2">
              {onUpdateCustomerStatus && (
                <button 
                  onClick={() => onUpdateCustomerStatus(selectedCustomer.id, selectedCustomer.status === 'Blocked' ? 'Active' : 'Blocked')}
                  className={`px-4 py-2 rounded-xl text-xs font-medium uppercase tracking-wider transition-all flex items-center gap-2 ${
                    selectedCustomer.status === 'Blocked' 
                      ? 'bg-emerald-50 text-emerald-600 border border-emerald-100 hover:bg-emerald-100' 
                      : 'bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-100'
                  }`}
                >
                  {selectedCustomer.status === 'Blocked' ? <CheckCircle size={14} /> : <ShieldAlert size={14} />}
                  <span>{selectedCustomer.status === 'Blocked' ? 'Unblock' : 'Block'}</span>
                </button>
              )}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-10 custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                      <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400">Contact Information</h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 text-slate-600">
                          <Mail size={12} />
                          <span className="text-sm font-semibold">{selectedCustomer.email}</span>
                        </div>
                        <div className="flex items-center gap-3 text-slate-600">
                          <Phone size={12} />
                          <span className="text-sm font-semibold">{selectedCustomer.phone}</span>
                        </div>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-2 px-1">Joined {new Date(selectedCustomer.joinedDate).toLocaleDateString()}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
                        <p className="text-xs font-medium text-emerald-600 uppercase tracking-wider">Total Spend (LTV)</p>
                        <p className="text-2xl font-black text-emerald-950 mt-1">{LOCALIZATION.CURRENCY}{selectedCustomer.totalSpent.toLocaleString()}</p>
                      </div>
                      <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
                        <p className="text-xs font-medium text-blue-600 uppercase tracking-wider">Total Orders</p>
                        <p className="text-2xl font-black text-blue-950 mt-1">{selectedCustomer.totalOrders}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {selectedCustomer.address && (
                      <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4 h-full flex flex-col justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-4">
                            <MapPin size={12} className="text-slate-400" />
                            <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400">Delivery Address</h3>
                          </div>
                          <p className="text-xs font-black text-slate-950 uppercase tracking-tight leading-relaxed">
                            {selectedCustomer.address}<br />
                            {selectedCustomer.city && `${selectedCustomer.city}, `}
                            {selectedCustomer.state && `${selectedCustomer.state} `}
                            {selectedCustomer.zip}
                          </p>
                        </div>
                        <button 
                          onClick={() => {
                            const addr = `${selectedCustomer.address}${selectedCustomer.city ? ', ' + selectedCustomer.city : ''}${selectedCustomer.state ? ', ' + selectedCustomer.state : ''}${selectedCustomer.zip ? ', ' + selectedCustomer.zip : ''}`;
                            navigator.clipboard.writeText(addr);
                          }}
                          className="w-full mt-4 flex items-center justify-center gap-2 py-3 border border-slate-200 border-dashed rounded-xl text-xs font-medium uppercase tracking-wider text-slate-400 hover:text-slate-900 transition-colors"
                        >
                          <Copy size={12} />
                          Copy Records
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-6 pt-6 border-t border-slate-100">
                  <h3 className="text-sm font-black text-slate-950 uppercase tracking-widest flex items-center gap-2">
                    <History size={16} className="text-slate-400" />
                    Order History
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {customerOrders.length > 0 ? customerOrders.map((order) => (
                      <div 
                        key={order.id}
                        onClick={() => {
                          if (onNavigateToOrder) onNavigateToOrder(order.id);
                        }}
                        className="p-5 bg-white border border-slate-100 rounded-3xl hover:border-slate-900 transition-all cursor-pointer group shadow-sm flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs font-black text-slate-950 uppercase tracking-tight">#{order.id.slice(0, 8)}</p>
                          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{new Date(order.createdAt).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{order.total.toLocaleString()}</p>
                          <span className={`text-xs font-medium uppercase tracking-wider ${
                            order.status === 'Completed' || order.status === 'Delivered' ? 'text-emerald-600' :
                            order.status === 'Pending' ? 'text-amber-600' :
                            order.status === 'Cancelled' ? 'text-rose-600' :
                            'text-slate-500'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                    )) : (
                      <div className="col-span-2 py-12 text-center text-slate-300">
                        <p className="text-xs font-medium uppercase tracking-wider">No order statistics found</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
        </div>
      </AdminPageWrapper>
    );
  }

  return (
    <AdminPageWrapper
      title="Customers"
      description="View and manage customer profiles, order history, and lifetime value."
      icon={Users}
      options={[
        {"label":"Search Customers","description":"Find customers by name, email, or phone number."},
        {"label":"View History","description":"See all past orders and total lifetime value for each customer."}
      ]}
      isEmpty={filteredCustomers.length === 0}
      emptyState={
        <div className="space-y-4">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300">
            <Users size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">No customers found</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your search criteria.</p>
          </div>
        </div>
      }
      toolbar={
        <AdminToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search customers by name, email, or ID..."
          filters={
            <div className="flex flex-wrap items-center gap-3">
              <select 
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="All">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Blocked">Blocked</option>
              </select>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="shrink-0 px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium uppercase tracking-wider text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all cursor-pointer shadow-sm"
              >
                <option value="recent">Most Recent</option>
                <option value="spent">Highest Spenders</option>
                <option value="orders">Most Orders</option>
                <option value="name">Alphabetical</option>
              </select>
            </div>
          }
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden p-6">
        <Table>
          <TableHeader>
            <TableHead>Customer</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead className="text-center">Orders</TableHead>
            <TableHead className="text-right">Total Spent</TableHead>
            <TableHead className="text-right">Last Order</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableHeader>
          <TableBody>
            {filteredCustomers.length > 0 ? filteredCustomers.map((customer) => (
              <TableRow 
                key={customer.id} 
                className="group hover:bg-slate-50 transition-all cursor-pointer"
                onClick={(e) => {
                  if ((e.target as HTMLElement).closest('button')) return;
                  navigate(`${basePath}/customers/${customer.id}`);
                }}
              >
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs border border-slate-200 group-hover:bg-white transition-colors">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-950 uppercase tracking-tight">{customer.name}</p>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">ID: {customer.id.slice(0, 8)}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <p className="text-xs font-bold text-slate-600">{customer.email}</p>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{customer.phone}</p>
                </TableCell>
                <TableCell className="text-center">
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-full text-xs font-medium uppercase tracking-wider">
                    {customer.totalOrders}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <p className="text-xs font-black text-slate-950 tracking-tight">{LOCALIZATION.CURRENCY}{customer.totalSpent.toLocaleString()}</p>
                </TableCell>
                <TableCell className="text-right">
                  <p className="text-xs font-bold text-slate-600">{new Date(customer.lastOrderDate).toLocaleDateString()}</p>
                  {customer.status === 'Blocked' && (
                    <span className="text-xs font-medium text-rose-500 uppercase tracking-wider mt-1 block">Blocked</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <button 
                      onClick={() => navigate(`${basePath}/customers/${customer.id}`)}
                      className="p-2 rounded-lg text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-all"
                      title="View Profile"
                    >
                      <Eye size={14} />
                    </button>
                    {onUpdateCustomerStatus && (
                      <button 
                        onClick={() => onUpdateCustomerStatus(customer.id, customer.status === 'Blocked' ? 'Active' : 'Blocked')}
                        className={`p-2 rounded-lg transition-all ${customer.status === 'Blocked' ? 'text-emerald-500 hover:bg-emerald-50' : 'text-rose-400 hover:text-rose-600 hover:bg-rose-50'}`}
                        title={customer.status === 'Blocked' ? 'Unblock Customer' : 'Block Customer'}
                      >
                        {customer.status === 'Blocked' ? <CheckCircle size={14} /> : <ShieldAlert size={14} />}
                      </button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={6} className="py-12 text-center text-slate-400 text-xs font-medium uppercase tracking-wider">
                  No customers found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <AnimatePresence>
        {!routeCustomerId && (
          <div className="hidden" />
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default AdminCustomers;
