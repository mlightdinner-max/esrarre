import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, Plus, Edit2, Trash2, X
} from 'lucide-react';
import { AdminPageWrapper } from './AdminPageWrapper';
import { AdminToolbar } from './AdminToolbar';

interface PagesManagementProps {
  config: any;
  onUpdateConfig: (c: any) => void;
}

const PagesManagement = ({ config, onUpdateConfig }: PagesManagementProps) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingPage, setEditingPage] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    content: '',
    status: 'published' as 'published' | 'draft',
    lastUpdated: new Date().toISOString()
  });
  const [searchQuery, setSearchQuery] = useState('');

  const pages = config.customPages || [];

  const handleSave = () => {
    if (!formData.title || !formData.slug) return;
    
    let newPages;
    if (editingPage) {
      newPages = pages.map((p: any) => p.id === editingPage.id ? { ...formData, id: p.id } : p);
    } else {
      newPages = [{ ...formData, id: crypto.randomUUID() }, ...pages];
    }
    
    onUpdateConfig({ ...config, customPages: newPages });
    resetForm();
  };

  const resetForm = () => {
    setIsAdding(false);
    setEditingPage(null);
    setFormData({
      title: '',
      slug: '',
      content: '',
      status: 'published',
      lastUpdated: new Date().toISOString()
    });
  };

  const handleEdit = (page: any) => {
    setEditingPage(page);
    setFormData(page);
    setIsAdding(true);
  };

  const handleDelete = (id: string) => {
    const newPages = pages.filter((p: any) => p.id !== id);
    onUpdateConfig({ ...config, customPages: newPages });
  };

  const filteredPages = pages.filter((p: any) => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.slug.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminPageWrapper
      title="Legal Pages"
      description="Create and manage custom pages for your store."
      icon={FileText}
      options={[{"label":"New Page","description":"Create a new custom page."}]}
      actions={
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center space-x-2 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10"
        >
          <Plus size={16} />
          <span>New Page</span>
        </button>
      }
      toolbar={
        <AdminToolbar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchPlaceholder="Search pages by title or slug..."
        />
      }
    >
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm mb-8">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50">
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">Legal Pages</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Manage standard legal documents.</p>
        </div>
        <div className="p-6 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Privacy Policy</label>
            <textarea 
              value={config.privacyPolicy || ''}
              onChange={e => onUpdateConfig({ ...config, privacyPolicy: e.target.value })}
              rows={6}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none font-mono"
              placeholder="Enter your privacy policy content..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Terms of Service</label>
            <textarea 
              value={config.termsOfService || ''}
              onChange={e => onUpdateConfig({ ...config, termsOfService: e.target.value })}
              rows={6}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none font-mono"
              placeholder="Enter your terms of service content..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Returns and Refund Policy</label>
            <textarea 
              value={config.returnsPolicy || ''}
              onChange={e => onUpdateConfig({ ...config, returnsPolicy: e.target.value })}
              rows={6}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none font-mono"
              placeholder="Enter your returns and refund policy content..."
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-6 py-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Page Title</th>
                <th className="px-6 py-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Slug</th>
                <th className="px-6 py-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Last Updated</th>
                <th className="px-6 py-4 text-xs font-medium text-slate-400 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredPages.length > 0 ? filteredPages.map((page: any, idx: number) => (
                <tr key={`${page.id}-${idx}`} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-slate-100 text-slate-400 rounded-lg group-hover:bg-white transition-colors">
                        <FileText size={14} />
                      </div>
                      <span className="text-xs font-bold text-slate-900">{page.title}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-medium text-slate-500 font-mono">/{page.slug}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium uppercase tracking-wider ${
                      page.status === 'published' ? 'bg-primary/10 text-primary' : 'bg-amber-100 text-amber-600'
                    }`}>
                      {page.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-bold text-slate-400">{new Date(page.lastUpdated).toLocaleDateString()}</span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => handleEdit(page)}
                        className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-all"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button 
                        onClick={() => handleDelete(page.id)}
                        className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">No custom pages found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-slate-200"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  {editingPage ? 'Edit Custom Page' : 'Create New Page'}
                </h2>
                <button onClick={resetForm} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Page Title</label>
                    <input 
                      type="text"
                      value={formData.title}
                      onChange={e => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all"
                      placeholder="e.g. Privacy Policy"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Slug</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs">/</span>
                      <input 
                        type="text"
                        value={formData.slug}
                        onChange={e => setFormData({ ...formData, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                        className="w-full pl-7 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all font-mono"
                        placeholder="privacy-policy"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Status</label>
                  <div className="flex bg-slate-50 p-1 rounded-xl w-fit">
                    {['published', 'draft'].map((status) => (
                      <button
                        key={status}
                        onClick={() => setFormData({ ...formData, status: status as any })}
                        className={`px-6 py-2 rounded-lg text-xs font-medium uppercase tracking-wider transition-all ${
                          formData.status === status ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                        }`}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Page Content (HTML/Markdown)</label>
                  <textarea 
                    value={formData.content}
                    onChange={e => setFormData({ ...formData, content: e.target.value })}
                    rows={12}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none font-mono"
                    placeholder="Write your page content here..."
                  />
                </div>
              </div>
              <div className="p-6 border-t border-slate-100 bg-slate-50/50 flex justify-end space-x-3">
                <button 
                  onClick={resetForm}
                  className="px-6 py-2.5 text-xs font-medium uppercase tracking-wider text-slate-500 hover:text-slate-900 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  className="btn-primary"
                >
                  {editingPage ? 'Update Page' : 'Create Page'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AdminPageWrapper>
  );
};

export default PagesManagement;
