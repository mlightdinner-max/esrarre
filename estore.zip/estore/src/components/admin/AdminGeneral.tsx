import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Settings
} from 'lucide-react';
import { Config } from '../../types';
import { AdminPageWrapper } from './AdminPageWrapper';

interface AdminGeneralProps {
  config: Config;
  onUpdateConfig: (c: any) => void;
  onSave?: () => void;
  hasUnsavedChanges?: boolean;
  isValidating?: boolean;
}

const AdminGeneral = ({ config, onUpdateConfig, onSave: _onSave, hasUnsavedChanges: _hasUnsavedChanges, isValidating: _isValidating }: AdminGeneralProps) => {
  const [activeSection, setActiveSection] = useState<'contact' | 'welcome'>('contact');

  return (
    <AdminPageWrapper
      title="General Settings"
      description="Manage your store's primary contact information and dashboard welcome messages."
      icon={Settings}
      options={[]}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-3 space-y-2">
        {[
          { id: 'contact', label: 'Contact Info', icon: Mail },
          { id: 'welcome', label: 'Dashboard Welcome', icon: Settings },
        ].map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id as any)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${
              activeSection === section.id 
                ? 'bg-slate-900 text-white shadow-xl shadow-slate-900/10' 
                : 'text-slate-500 hover:bg-slate-100'
            }`}
          >
            <section.icon size={18} />
            <span className="text-xs font-medium uppercase tracking-wider">{section.label}</span>
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="lg:col-span-9 bg-white rounded-2xl border border-slate-200 p-8 shadow-sm space-y-8">
        <AnimatePresence mode="wait">
          {activeSection === 'contact' && (
            <motion.div 
              key="contact"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">General Contact Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      type="email"
                      value={config.contactEmail || ''}
                      onChange={e => onUpdateConfig({ ...config, contactEmail: e.target.value })}
                      placeholder="contact@yourstore.com"
                      className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black tracking-tight focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-950"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Support Mobile</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      type="text"
                      value={config.contactPhone || ''}
                      onChange={e => onUpdateConfig({ ...config, contactPhone: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black tracking-tight focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-950"
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Store Address</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-4 text-slate-400" size={16} />
                  <textarea 
                    value={config.contactAddress || ''}
                    onChange={e => onUpdateConfig({ ...config, contactAddress: e.target.value })}
                    rows={3}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium leading-relaxed focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none text-slate-600"
                  />
                </div>
              </div>
            </motion.div>
          )}
          {activeSection === 'welcome' && (
            <motion.div 
              key="welcome"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Welcome Message</label>
                  <input 
                    type="text"
                    value={config.homeWelcomeMessage || ''}
                    onChange={e => onUpdateConfig({ ...config, homeWelcomeMessage: e.target.value })}
                    placeholder="Welcome to your Dashboard"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black tracking-tight focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all text-slate-950"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Summary Message</label>
                  <textarea 
                    value={config.homeSummaryMessage || ''}
                    onChange={e => onUpdateConfig({ ...config, homeSummaryMessage: e.target.value })}
                    rows={3}
                    placeholder="Here is an overview of your store performance..."
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium leading-relaxed focus:outline-none focus:ring-2 focus:ring-slate-900/5 transition-all resize-none text-slate-600"
                  />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </div>
    </AdminPageWrapper>
  );
};

export default AdminGeneral;
