import React from 'react';
import { Activity, ShieldCheck, Lock, Save, RefreshCw, Search, Globe } from 'lucide-react';
import { Config } from '../../types';
import { AdminSectionHeader } from './AdminSectionHeader';

const AdminVisibility = ({ config, onUpdateConfig, onSave, hasUnsavedChanges, isValidating }: { config: Config; onUpdateConfig: (c: any) => void; onSave: () => void; hasUnsavedChanges: boolean; onToggleLive?: () => void; isValidating?: boolean }) => {
  return (
    <div className="space-y-6 pb-12">
      <AdminSectionHeader 
        title="SEO & Visibility" 
        description="Control your store's public presence, search engine optimisation, and maintenance state." 
        options={[
          { label: "Go Live", description: "Make your store accessible to customers." },
          { label: "SEO Meta", description: "Optimise how your store appears in search results." }
        ]}
      />
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="ml-auto">
          {hasUnsavedChanges && (
            <button 
              onClick={onSave}
              disabled={isValidating}
              className="btn-primary flex items-center gap-2 disabled:opacity-50"
            >
              {isValidating ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
              <span>Save Visibility Settings</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-8">
          {/* Site Status - Display Only */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className={`p-6 rounded-2xl border flex flex-col md:flex-row items-center justify-between gap-6 transition-all duration-500 ${config.isLive ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-50 border-slate-100'}`}>
              <div className="flex items-center gap-6">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-transform duration-700 hover:rotate-6 ${config.isLive ? 'bg-white text-emerald-600' : 'bg-white text-slate-400'}`}>
                  <Activity size={20} className={config.isLive ? 'animate-pulse' : ''} />
                </div>
                <div className="space-y-1">
                  <h3 className={`font-black text-sm uppercase tracking-tight ${config.isLive ? 'text-emerald-900' : 'text-slate-900'}`}>
                    Current Status: {config.isLive ? 'Systems Live' : 'Maintenance Mode'}
                  </h3>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
                    Managed via System Settings Master Control
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  const event = new CustomEvent('admin-tab-change', { detail: 'system' });
                  window.dispatchEvent(event);
                }}
                className="btn-primary"
              >
                Go to System Settings
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                <div className="flex items-center space-x-2 text-slate-900">
                  <ShieldCheck size={14} className="text-emerald-500" />
                  <h4 className="section-label">Indexing Active</h4>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed font-medium font-sans">
                  Search engines can crawl and index your storefront pages when live.
                </p>
              </div>
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                <div className="flex items-center space-x-2 text-slate-900">
                  <Lock size={14} className="text-amber-500" />
                  <h4 className="section-label">Admin Bypass</h4>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed font-medium font-sans">
                  Authorized administrators retain full storefront access even while offline.
                </p>
              </div>
            </div>
          </div>

          {/* SEO Meta Section */}
          <div className="bg-white p-5 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-slate-50 text-slate-900 rounded-xl border border-slate-100">
                <Search size={20} />
              </div>
              <h3 className="premium-heading text-sm text-slate-950">Search engine optimisation</h3>
            </div>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <label className="section-label">Meta Title</label>
                  <span className={`section-label ${(config.seoTitle || '').length > 60 ? 'text-rose-500' : 'text-slate-300'}`}>
                    {(config.seoTitle || '').length} of 60
                  </span>
                </div>
                <input 
                  type="text"
                  value={config.seoTitle || ''}
                  onChange={e => onUpdateConfig({ ...config, seoTitle: e.target.value })}
                  placeholder="The Ultimate Fashion Experience - YourStore"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black tracking-tight focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all text-slate-950"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <label className="section-label">Meta Description</label>
                  <span className={`section-label ${(config.seoDescription || '').length > 160 ? 'text-rose-500' : 'text-slate-300'}`}>
                    {(config.seoDescription || '').length} of 160
                  </span>
                </div>
                <textarea 
                  value={config.seoDescription || ''}
                  onChange={e => onUpdateConfig({ ...config, seoDescription: e.target.value })}
                  rows={4}
                  placeholder="Discover premium collections and unmatched quality at YourStore..."
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium leading-relaxed focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all resize-none text-slate-600"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wider ml-1">Meta Keywords</label>
                <input 
                  type="text"
                  value={config.seoKeywords || ''}
                  onChange={e => onUpdateConfig({ ...config, seoKeywords: e.target.value })}
                  placeholder="fashion, ecommerce, premium, apparel"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all text-slate-500"
                />
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest ml-2 italic">Separate keywords with commas.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Help */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900 rounded-2xl p-5 sm:p-8 text-white space-y-6 shadow-2xl shadow-slate-950">
            <div className="w-12 h-12 bg-slate-800 rounded-xl flex items-center justify-center border border-slate-700">
              <Globe size={24} className="text-slate-400" />
            </div>
            <div className="space-y-2">
              <h4 className="text-xs font-medium uppercase tracking-wider bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">Search Presence</h4>
              <p className="text-xs text-slate-400 leading-relaxed font-bold uppercase">
                Your SEO configuration determines how your store is perceived by search engines like Google and Bing.
              </p>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="h-1 w-1 rounded-full bg-emerald-500 mt-1.5" />
                <p className="text-sm font-semibold text-slate-300">Keep titles under 60 characters for optimal display.</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="h-1 w-1 rounded-full bg-emerald-500 mt-1.5" />
                <p className="text-sm font-semibold text-slate-300">Descriptions should be punchy and around 155-160 characters.</p>
              </li>
              <li className="flex items-start gap-3">
                <div className="h-1 w-1 rounded-full bg-emerald-500 mt-1.5" />
                <p className="text-sm font-semibold text-slate-300">Exclude unnecessary keywords to focus on your core niche.</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminVisibility;
