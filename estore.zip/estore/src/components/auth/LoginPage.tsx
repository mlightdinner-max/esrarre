import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ShieldCheck, Activity, Lock, Mail } from 'lucide-react';
import Captcha, { type CaptchaResult } from '../common/Captcha';

interface LoginPageProps {
  onLogin: (credentials: any) => Promise<boolean>;
}

const LoginPage = ({ onLogin }: LoginPageProps) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [captcha, setCaptcha] = useState<CaptchaResult>({ verified: false, token: '', answer: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // No auto-redirect — user must log in explicitly

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!captcha.verified) return;
    
    setIsLoading(true);
    setError('');

    const success = await onLogin({ email, password, captchaToken: captcha.token, captchaAnswer: captcha.answer });
    
    if (success) {
      // Small delay to ensure state updates if needed, though navigate is fine
      const savedSession = localStorage.getItem('user_session');
      if (savedSession) {
        const user = JSON.parse(savedSession);
        if (user.role === 'Affiliate') {
          navigate('/home');
        } else {
          navigate('/home');
        }
      } else {
        navigate('/home');
      }
    } else {
      setError('Invalid email or password');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md my-auto"
      >
        <div className="bg-white rounded-2xl sm:rounded-[2.5rem] p-6 sm:p-8 md:p-12 shadow-2xl shadow-slate-900/5 border border-slate-200/60 space-y-8">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center mx-auto border border-primary/10 shadow-sm">
              <ShieldCheck size={32} />
            </div>
            <div className="space-y-1">
              <h1 className="text-2xl font-black text-slate-900 uppercase italic tracking-tighter">Secure Access</h1>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest leading-relaxed">Enter your credentials to access the dashboard</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                    placeholder="name@company.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label className="text-xs font-medium text-slate-900 uppercase tracking-wider">Password</label>
                  <button 
                    type="button" 
                    onClick={() => setError('Please contact your administrator to reset your password.')}
                    className="text-xs font-black text-primary uppercase tracking-widest hover:text-primary/80 transition-colors"
                  >
                    Forgot?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-100 overflow-hidden">
              <div className="flex items-center space-x-3 text-amber-600 px-4 pt-4 pb-2 bg-slate-50">
                <Activity size={16} />
                <p className="text-xs font-medium uppercase tracking-wider">Security Verification</p>
              </div>
              <Captcha onVerify={setCaptcha} />
            </div>

            <AnimatePresence mode="wait">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-4 bg-rose-50 border border-rose-100 rounded-xl"
                >
                  <p className="text-xs text-rose-600 font-bold uppercase tracking-widest text-center">{error}</p>
                </motion.div>
              )}
            </AnimatePresence>

            <button
              type="submit"
              disabled={!captcha.verified || isLoading}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-3 shadow-xl shadow-slate-900/10"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Verifying...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ChevronRight size={14} />
                </>
              )}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
