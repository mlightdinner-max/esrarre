import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ArrowRight, ArrowLeft, Activity, Ticket, X, Copy, ShoppingBag } from 'lucide-react';
import { motion } from 'motion/react';
import { CartItem } from '../../types';
import { LOCALIZATION } from '../../constants';
import { aiService } from '../../services/aiService';
import Captcha, { type CaptchaResult } from '../common/Captcha';
import AIValidationModal from '../common/AIValidationModal';
import Button from '../common/Button';

interface CheckoutPageProps {
  cart: CartItem[];
  onPlaceOrder: (details: any) => Promise<any>;
  config: any;
  onClearCart: () => void;
  aiStatus: any;
}

const CheckoutPage = ({ cart, onPlaceOrder, config, onClearCart, aiStatus }: CheckoutPageProps) => {
  const [step, setStep] = useState(1);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [captcha, setCaptcha] = useState<CaptchaResult>({ verified: false, token: '', answer: '' });
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [couponError, setCouponError] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiValidation, setAiValidation] = useState<{ isOpen: boolean; issues: string[] }>({ isOpen: false, issues: [] });
  const [orderSuccessId, setOrderSuccessId] = useState<string | null>(null);
  const [orderError, setOrderError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    paymentMethod: 'cod'
  });

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = 0;
  
  const discount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.type === 'percentage') {
      return (subtotal * appliedCoupon.value) / 100;
    }
    return appliedCoupon.value;
  }, [subtotal, appliedCoupon]);

  const total = subtotal + shipping - discount;

  const handleApplyCoupon = () => {
    setCouponError('');
    const coupon = (config.coupons || []).find((c: any) => c.code.toUpperCase() === couponCode.toUpperCase());
    
    if (!coupon) {
      setCouponError('Invalid coupon code');
      return;
    }

    if (coupon.status?.toLowerCase() !== 'active') {
      setCouponError('This coupon is no longer active');
      return;
    }

    if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
      setCouponError('This coupon has expired');
      return;
    }

    if (coupon.usageLimit > 0 && coupon.usageCount >= coupon.usageLimit) {
      setCouponError('Usage limit reached for this coupon');
      return;
    }

    if (subtotal < (coupon.minOrder || 0)) {
      setCouponError(`Minimum order of ${LOCALIZATION.CURRENCY}${coupon.minOrder} required for this coupon`);
      return;
    }

    setAppliedCoupon(coupon);
    setCouponCode('');
  };

  const validateField = async (name: string, value: string) => {
    let error = '';
    
    switch (name) {
      case 'fullName':
        if (!/^[A-Za-z\s]+$/.test(value)) {
          error = 'Name should contain only letters.';
        }
        break;
      case 'email':
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          error = 'Please enter a valid email format (e.g., example@domain.com).';
        }
        break;
      case 'phone': {
        const digits = value.replace(/^(?:\+91|91|0)/, '').replace(/\D/g, '');
        if (!/^[6-9]\d{9}$/.test(digits)) {
          error = 'Enter a valid 10-digit Indian mobile number.';
        }
        break;
      }
      case 'address':
        if (value.trim().length < 10) {
          error = 'Please enter a complete address.';
        }
        break;
      case 'city':
      case 'state':
        if (!/^[A-Za-z\s]+$/.test(value)) {
          error = `${name.charAt(0).toUpperCase() + name.slice(1)} should contain only text.`;
        }
        break;
      case 'pincode':
        if (!/^\d{6}$/.test(value)) {
          error = 'Pincode should contain exactly 6 digits.';
        }
        break;
      default:
        break;
    }
    
    return error;
  };

  const validateWithAI = async () => {
    if (!aiStatus?.settings?.enabled || !aiStatus?.settings?.useCheckoutValidation) return { isValid: true };
    
    // Fetch a fresh AI status right before validating to avoid using stale state
    let freshStatus = aiStatus;
    try {
      const statusRes = await aiService.getStatus(aiStatus?.isUnsavedKey ? config.geminiApiKey : undefined);
      if (statusRes) freshStatus = { ...aiStatus, ...statusRes };
    } catch {
      // If status check fails, fall through to use cached aiStatus
    }

    if (!freshStatus?.isAvailable) {
      const reason = freshStatus?.status === 'quota' ? 'AI quota exceeded' : 'AI unavailable';
      return { isValid: true, aiFallbackTag: reason };
    }

    setIsAnalyzing(true);
    try {
      const response = await aiService.validateCheckout(
        formData,
        freshStatus?.isUnsavedKey ? config.geminiApiKey : undefined
      );
      
      if (response && response.unavailable) {
        return { isValid: true, aiFallbackTag: 'fallback mode enabled' };
      }

      const foundIssues = response.issues || [];

      if (Array.isArray(foundIssues) && foundIssues.length > 0) {
        setAiValidation({ isOpen: true, issues: foundIssues });
        return { isValid: false };
      }
      return { isValid: true };
    } catch (error) {
      console.error("AI Validation failed:", error);
      return { isValid: true, aiFallbackTag: 'fallback mode enabled' }; // Proceed if AI fails
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
      const errors: Record<string, string> = {};
      
      // Basic empty checks
      const requiredFields = ['fullName', 'email', 'phone', 'address', 'city', 'state', 'pincode'];
      for (const field of requiredFields) {
        if (!formData[field as keyof typeof formData]) {
          errors[field] = 'This field is required.';
        }
      }

      // Detailed validations
      if (Object.keys(errors).length === 0) {
        for (const field of requiredFields) {
          const error = await validateField(field, formData[field as keyof typeof formData]);
          if (error) errors[field] = error;
        }
      }

      if (Object.keys(errors).length > 0) {
        setFormErrors(errors);
        const firstErrorField = Object.keys(errors)[0];
        const element = document.getElementsByName(firstErrorField)[0];
        if (element) element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      }

      setFormErrors({});
      setStep(2);
      return;
    }
    
    if (!captcha.verified) return;

    let aiFallbackTag = undefined;

    if (aiStatus?.settings?.enabled && aiStatus?.settings?.useCheckoutValidation) {
      const result = await validateWithAI();
      if (!result.isValid) return;
      aiFallbackTag = result.aiFallbackTag;
    }

    processOrder(aiFallbackTag);
  };

  const processOrder = async (aiFallbackTag?: string, isOverridingAiFlag?: boolean) => {
    setIsPlacingOrder(true);
    setOrderError(null);
    try {
      const order = await onPlaceOrder({
        ...formData,
        customerName: formData.fullName,
        zip: formData.pincode,
        items: cart,
        subtotal,
        shipping,
        discount,
        total,
        couponUsed: appliedCoupon?.code,
        captchaToken: captcha.token,
        captchaAnswer: captcha.answer,
        isAiValidated: !isOverridingAiFlag && aiStatus?.settings?.enabled && aiStatus?.settings?.useCheckoutValidation && !aiFallbackTag,
        isAiFlagged: isOverridingAiFlag === true,
        systemTags: aiFallbackTag ? [aiFallbackTag] : undefined
      });
      
      if (order && order.id) {
        setOrderSuccessId(order.id);
        onClearCart();
      } else {
        setOrderError('Your order could not be placed. Please check your details and try again.');
      }
    } catch (error) {
      console.error("Failed to place order:", error);
      setOrderError('Something went wrong. Please try again in a moment.');
    } finally {
      setIsPlacingOrder(false);
    }
  };

  const handleOrderAction = async (action: string, note: string) => {
    if (!orderSuccessId) return;
    try {
      const response = await fetch(`/api/v1/orders/action/${orderSuccessId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, note })
      });
      if (response.ok) {
        // Feedback sent
      }
    } catch (error) {
      console.error("Action error:", error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  if (orderSuccessId) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6 bg-slate-50/50">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-xl w-full bg-white rounded-3xl p-6 sm:p-12 shadow-2xl shadow-slate-900/5 border border-slate-200/60 text-center space-y-10"
        >
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 12, stiffness: 200, delay: 0.1 }}
            className="w-24 h-24 bg-primary/5 text-primary rounded-2xl flex items-center justify-center mx-auto border border-primary/10"
          >
            <CheckCircle2 size={48} />
          </motion.div>
          
          <div className="space-y-4">
            <h2 className="text-4xl font-black text-slate-900 uppercase italic tracking-tighter leading-none">{LOCALIZATION.ORDER_PLACED}</h2>
            <p className="text-slate-500 font-medium text-sm">Thank you! We've received your order and will get it ready for delivery.</p>
          </div>

          <div className="p-8 bg-slate-50 rounded-2xl border border-slate-200/60 space-y-4">
            <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">{LOCALIZATION.ORDER_ID}</p>
            <div className="flex items-center justify-center space-x-3">
              <span className="text-xl font-black text-slate-900 font-mono tracking-widest">{orderSuccessId}</span>
              <button 
                onClick={() => copyToClipboard(orderSuccessId)}
                className={`p-3 rounded-xl transition-all ${isCopied ? 'bg-emerald-50 text-emerald-500' : 'bg-white text-slate-400 hover:text-primary shadow-sm'}`}
              >
                {isCopied ? <CheckCircle2 size={18} /> : <Copy size={18} />}
              </button>
            </div>
            {isCopied && <p className="text-xs font-medium text-emerald-500 uppercase tracking-wider">Order ID Copied!</p>}
            
            <div className="flex gap-2 pt-4">
              <button 
                onClick={() => handleOrderAction('Edit Details', 'User wants to correct info')}
                className="flex-1 py-3 border border-slate-200 rounded-xl text-xs font-medium text-slate-500 uppercase tracking-wider hover:bg-white transition-all shadow-sm"
              >
                Need Changes? Contact Us
              </button>
              <button 
                onClick={() => handleOrderAction('Confirm Order', 'User verified double-check')}
                className="flex-1 py-3 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-emerald-100 transition-all border border-emerald-100"
              >
                Confirm Order ✓
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link 
              to={`/tracking?id=${orderSuccessId}`}
              className="px-8 py-5 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-slate-900/10 flex items-center justify-center space-x-2"
            >
              <Activity size={14} />
              <span>{LOCALIZATION.TRACK_ORDER}</span>
            </Link>
            <Link 
              to="/products"
              className="px-8 py-5 bg-white text-slate-900 border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center space-x-2"
            >
              <ShoppingBag size={14} />
              <span>Continue Shopping</span>
            </Link>
          </div>

          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest pt-4 border-t border-slate-100 italic">
            A confirmation has been sent to {formData.email}
          </p>
        </motion.div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="text-center space-y-6 max-w-md">
          <div className="w-20 h-20 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300 border border-slate-100">
            <Activity size={40} />
          </div>
          <h2 className="text-2xl font-black text-slate-900 uppercase italic tracking-tighter">Your cart is empty</h2>
          <p className="text-slate-500 font-medium text-sm">Add some premium items to your cart before checking out.</p>
          <Link 
            to="/products"
            className="inline-block px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-slate-900/10"
          >
            Start Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 py-12 md:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col-reverse lg:flex-row gap-12">
          {/* Main Content */}
          <div className="flex-1 space-y-8">
            {/* Steps */}
            <div className="flex items-center space-x-4 mb-8">
              <div className={`flex items-center space-x-2 ${step >= 1 ? 'text-primary' : 'text-slate-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border-2 ${step >= 1 ? 'border-primary bg-primary/5' : 'border-slate-200'}`}>1</div>
                <span className="text-xs font-medium uppercase tracking-wider">{LOCALIZATION.DELIVERY}</span>
              </div>
              <div className="h-px flex-1 bg-slate-200" />
              <div className={`flex items-center space-x-2 ${step >= 2 ? 'text-primary' : 'text-slate-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border-2 ${step >= 2 ? 'border-primary bg-primary/5' : 'border-slate-200'}`}>2</div>
                <span className="text-xs font-medium uppercase tracking-wider">{LOCALIZATION.PAYMENT_METHOD}</span>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-200/60">
              <form onSubmit={handleSubmit} className="space-y-8">
                {step === 1 ? (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label htmlFor="fullName" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Full Name</label>
                        <input
                          required
                          id="fullName" name="fullName"
                          type="text"
                          value={formData.fullName}
                          onChange={(e) => {
                            setFormData({ ...formData, fullName: e.target.value });
                            if (formErrors.fullName) setFormErrors({ ...formErrors, fullName: '' });
                          }}
                          className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.fullName ? 'ring-2 ring-rose-500/50' : ''}`}
                          placeholder="Enter your full name"
                        />
                        {formErrors.fullName && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.fullName}</p>}
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">Email Address</label>
                        <input
                          required
                          id="email" name="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => {
                            setFormData({ ...formData, email: e.target.value });
                            if (formErrors.email) setFormErrors({ ...formErrors, email: '' });
                          }}
                          className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.email ? 'ring-2 ring-rose-500/50' : ''}`}
                          placeholder="Enter your email"
                        />
                        {formErrors.email && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.email}</p>}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="address" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.ADDRESS}</label>
                      <textarea
                        required
                        id="address" name="address"
                        value={formData.address}
                        onChange={(e) => {
                          setFormData({ ...formData, address: e.target.value });
                          if (formErrors.address) setFormErrors({ ...formErrors, address: '' });
                        }}
                        rows={3}
                        className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium resize-none transition-all ${formErrors.address ? 'ring-2 ring-rose-500/50' : ''}`}
                        placeholder="Enter your full delivery address"
                      />
                      {formErrors.address && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.address}</p>}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                      <div className="sm:col-span-2 space-y-2">
                        <label htmlFor="city" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.CITY}</label>
                        <input
                          required
                          id="city" name="city"
                          type="text"
                          value={formData.city}
                          onChange={(e) => {
                            setFormData({ ...formData, city: e.target.value });
                            if (formErrors.city) setFormErrors({ ...formErrors, city: '' });
                          }}
                          className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.city ? 'ring-2 ring-rose-500/50' : ''}`}
                        />
                        {formErrors.city && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.city}</p>}
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="state" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.STATE}</label>
                        <input
                          required
                          id="state" name="state"
                          type="text"
                          value={formData.state}
                          onChange={(e) => {
                            setFormData({ ...formData, state: e.target.value });
                            if (formErrors.state) setFormErrors({ ...formErrors, state: '' });
                          }}
                          className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.state ? 'ring-2 ring-rose-500/50' : ''}`}
                        />
                        {formErrors.state && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.state}</p>}
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="pincode" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.PINCODE}</label>
                        <input
                          required
                          id="pincode" name="pincode"
                          type="text"
                          value={formData.pincode}
                          onChange={(e) => {
                            setFormData({ ...formData, pincode: e.target.value });
                            if (formErrors.pincode) setFormErrors({ ...formErrors, pincode: '' });
                          }}
                          className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.pincode ? 'ring-2 ring-rose-500/50' : ''}`}
                        />
                        {formErrors.pincode && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.pincode}</p>}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.PHONE}</label>
                      <input
                        required
                        id="phone" name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => {
                          setFormData({ ...formData, phone: e.target.value });
                          if (formErrors.phone) setFormErrors({ ...formErrors, phone: '' });
                        }}
                        className={`w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm font-medium transition-all ${formErrors.phone ? 'ring-2 ring-rose-500/50' : ''}`}
                        placeholder="Enter your phone number"
                      />
                      {formErrors.phone && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{formErrors.phone}</p>}
                    </div>

                    <Button
                      type="submit"
                      className="w-full"
                      size="xl"
                      variant="dark"
                      rightIcon={<ArrowRight size={14} />}
                    >
                      Continue to Payment
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-8">
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 space-y-4">
                      <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Order Overview</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                        <div className="space-y-1">
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Customer Details</p>
                          <p className="font-medium text-slate-900">{formData.fullName}</p>
                          <p className="font-medium text-slate-600">{formData.email}</p>
                          <p className="font-medium text-slate-600">{formData.phone}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Delivery Address</p>
                          <p className="font-medium text-slate-900">{formData.address}</p>
                          <p className="font-medium text-slate-600">{formData.city}, {formData.state} - {formData.pincode}</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-xs font-medium text-slate-900 uppercase tracking-wider ml-1">{LOCALIZATION.PAYMENT_METHOD}</label>
                      <div className="grid grid-cols-1 gap-4">
                        <label className={`relative flex items-center p-6 rounded-2xl border-2 cursor-pointer transition-all border-primary/80 bg-primary/5`}>
                          <input
                            type="radio"
                            name="payment"
                            value="cod"
                            checked={true}
                            readOnly
                            className="hidden"
                          />
                          <div className="flex-1">
                            <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{LOCALIZATION.COD}</p>
                            <p className="text-xs text-slate-500 font-medium mt-1">Pay with cash when your items are delivered. This is currently our only accepted payment method.</p>
                          </div>
                          <div className="text-primary">
                            <CheckCircle2 size={20} />
                          </div>
                        </label>
                      </div>
                    </div>

                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                      <div className="flex items-center space-x-3 text-amber-600">
                        <Activity size={18} />
                        <p className="text-xs font-medium uppercase tracking-wider">Security Verification</p>
                      </div>
                      <Captcha onVerify={setCaptcha} />
                    </div>

                    {orderError && (
                      <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl">
                        <p className="text-xs text-rose-600 font-bold">{orderError}</p>
                      </div>
                    )}

                    <div className="flex gap-4">
                      <Button
                        type="button"
                        onClick={() => setStep(1)}
                        variant="secondary"
                        size="xl"
                        className="flex-1"
                        leftIcon={<ArrowLeft size={14} />}
                      >
                        Edit Details
                      </Button>
                      <Button
                        type="submit"
                        disabled={!captcha.verified}
                        isLoading={isAnalyzing || isPlacingOrder}
                        size="xl"
                        className="flex-[2]"
                        rightIcon={(isAnalyzing || isPlacingOrder) ? undefined : <ArrowRight size={14} />}
                      >
                        {isAnalyzing ? 'Verifying...' : isPlacingOrder ? 'Placing Order...' : 'Place Order'}
                      </Button>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:w-[400px] space-y-8">
            {/* Order Summary */}
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200/60 lg:sticky lg:top-16">
              <h3 className="text-xl font-black text-slate-900 uppercase italic tracking-tighter mb-8">Order Summary</h3>
              
              <div className="space-y-6 mb-8 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {cart.map((item, idx) => (
                  <div key={`checkout-item-${item.id}-${idx}`} className="flex items-center space-x-4">
                    <div className="w-16 h-16 rounded-xl bg-slate-50 overflow-hidden flex-shrink-0 border border-slate-100">
                      <img 
                        src={item.image || LOCALIZATION.FALLBACK_IMAGE} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-black text-slate-900 uppercase tracking-tight truncate">{item.name}</p>
                      <p className="text-xs text-slate-500 font-bold mt-0.5 uppercase tracking-widest">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-xs font-black text-slate-900">{LOCALIZATION.CURRENCY}{(item.price * item.quantity).toLocaleString()}</p>
                  </div>
                ))}
              </div>

              {/* Coupon Section */}
              <div className="mb-8 p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
                <div className="flex items-center space-x-2 text-slate-900">
                  <Ticket size={14} />
                  <span className="text-xs font-medium uppercase tracking-wider">Apply Coupon</span>
                </div>
                
                {appliedCoupon ? (
                  <div className="flex items-center justify-between p-3 bg-primary/5 border border-primary/10 rounded-xl">
                    <div className="flex items-center space-x-2">
                      <CheckCircle2 size={14} className="text-primary" />
                      <span className="text-xs font-black text-primary-dark uppercase tracking-widest">{appliedCoupon.code}</span>
                    </div>
                    <button 
                      onClick={() => setAppliedCoupon(null)}
                      className="p-1 hover:bg-primary/10 rounded-lg text-primary transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Enter code"
                      className="flex-1 px-4 py-2.5 bg-white border-none rounded-xl text-xs font-medium uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                    <button
                      onClick={handleApplyCoupon}
                      disabled={!couponCode}
                      className="px-4 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-black disabled:opacity-50 transition-all"
                    >
                      Apply
                    </button>
                  </div>
                )}
                {couponError && <p className="text-xs text-rose-500 font-bold uppercase tracking-widest ml-1">{couponError}</p>}
              </div>

              <div className="space-y-4 pt-6 border-t border-slate-100">
                <div className="flex justify-between text-slate-500">
                  <span className="text-xs font-medium uppercase tracking-wider">{LOCALIZATION.SUBTOTAL}</span>
                  <span className="text-xs font-black">{LOCALIZATION.CURRENCY}{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span className="text-xs font-medium uppercase tracking-wider">{LOCALIZATION.SHIPPING}</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-black text-slate-400 line-through">{LOCALIZATION.CURRENCY}50</span>
                    <span className="text-xs font-black text-emerald-600 font-black">FREE</span>
                  </div>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-primary">
                    <span className="text-xs font-medium uppercase tracking-wider">{LOCALIZATION.DISCOUNT}</span>
                    <span className="text-xs font-black">-{LOCALIZATION.CURRENCY}{discount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between pt-4 border-t border-slate-100">
                  <span className="text-sm font-black text-slate-900 uppercase tracking-widest">{LOCALIZATION.TOTAL}</span>
                  <span className="text-xl font-black text-slate-900 tracking-tighter">{LOCALIZATION.CURRENCY}{total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <AIValidationModal 
        isOpen={aiValidation.isOpen}
        onClose={() => setAiValidation({ ...aiValidation, isOpen: false })}
        issues={aiValidation.issues}
        onConfirm={() => {
          setAiValidation({ ...aiValidation, isOpen: false });
          processOrder(undefined, true);
        }}
        onSecondaryAction={() => {
          setAiValidation({ ...aiValidation, isOpen: false });
          setStep(1);
        }}
      />
    </div>
  );
};

export default CheckoutPage;
