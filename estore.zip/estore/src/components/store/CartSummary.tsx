import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, ArrowRight } from 'lucide-react';
import { CartItem } from '../../types';
import { LOCALIZATION } from '../../constants';

interface CartSummaryProps {
  cart: CartItem[];
  onOpenCart: () => void;
  isVisible: boolean;
}

const CartSummary = ({ cart, onOpenCart, isVisible }: CartSummaryProps) => {
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {totalItems > 0 && isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-50 p-3 md:p-6 pointer-events-none"
        >
          <div className="max-w-2xl mx-auto bg-slate-900/95 text-white rounded-2xl shadow-2xl flex items-center justify-between p-2 md:p-3 md:px-6 border border-white/10 backdrop-blur-md pointer-events-auto">
            <div className="flex items-center space-x-3 md:space-x-4">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center relative shadow-lg shadow-primary/20">
                <ShoppingCart size={18} />
                <span className="absolute -top-1.5 -right-1.5 bg-white text-slate-900 text-xs font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-slate-900 shadow-sm">
                  {totalItems}
                </span>
              </div>
              <div>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Total</p>
                <p className="text-sm md:text-base font-bold tracking-tight">{LOCALIZATION.CURRENCY}{totalPrice.toLocaleString()}</p>
              </div>
            </div>
            <button
              onClick={onOpenCart}
              className="px-4 md:px-6 py-2 bg-white text-slate-900 hover:bg-primary/80 hover:text-white text-xs font-bold rounded-xl transition-all flex items-center space-x-2 group uppercase tracking-widest shadow-lg shadow-white/5"
            >
              <span>Checkout</span>
              <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CartSummary;
