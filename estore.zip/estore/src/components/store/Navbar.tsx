import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Search, 
  ShoppingBag, 
  User as UserIcon, 
  ChevronDown, 
  ArrowRight, 
  LayoutDashboard, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  config: any;
  currentUser: any;
  onLogout: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const Navbar = ({ 
  cartCount, 
  onOpenCart, 
  config, 
  currentUser, 
  onLogout,
  searchQuery,
  setSearchQuery
}: NavbarProps) => {
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const storeName = config.storeName || '';
  const navigate = useNavigate();
  const location = useLocation();

  const categories = config.categories || [];

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Shop', path: '/products', show: !config.disabledPages?.includes('products') },
    { label: 'Tracking', path: '/tracking' },
    { label: 'Blog', path: '/blog', show: !config.disabledPages?.includes('blog') },
  ].filter(link => link.show !== false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center h-14 md:h-16">
          <div className="flex items-center space-x-4 md:space-x-12">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              aria-expanded={isMobileMenuOpen}
              className="md:hidden p-2 -ml-2 text-slate-500 hover:text-slate-900 transition-colors"
            >
              <Menu size={20} />
            </button>
            <Link to="/" className="flex items-center space-x-2 group">
              {config.logoUrl && (
                <img src={config.logoUrl} alt="Logo" className="h-5 md:h-6 w-auto object-contain transition-transform duration-300 group-hover:scale-105" referrerPolicy="no-referrer" />
              )}
              <span className="premium-heading text-sm md:text-base text-slate-900 truncate max-w-[140px] sm:max-w-[200px] md:max-w-none">{storeName}</span>
            </Link>

            <div className="hidden md:flex items-center space-x-6">
              {navLinks.map((link) => (
                <Link 
                  key={link.path}
                  to={link.path} 
                  className={`text-xs font-black uppercase tracking-[0.15em] transition-all ${location.pathname === link.path ? 'text-slate-900' : 'text-slate-400 hover:text-slate-900'}`}
                >
                  {link.label}
                </Link>
              ))}
              
              <div className="relative group">
                <button 
                  onMouseEnter={() => setIsCategoryOpen(true)}
                  onMouseLeave={() => setIsCategoryOpen(false)}
                  aria-expanded={isCategoryOpen}
                  aria-label="Browse categories"
                  className="flex items-center space-x-1 text-xs font-black uppercase tracking-[0.15em] text-slate-400 hover:text-slate-900 transition-all"
                >
                  <span>Categories</span>
                  <ChevronDown size={10} className={`transition-transform duration-300 ${isCategoryOpen ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {isCategoryOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 5, scale: 0.98 }}
                      onMouseEnter={() => setIsCategoryOpen(true)}
                      onMouseLeave={() => setIsCategoryOpen(false)}
                      className="absolute top-full left-0 w-48 bg-white border border-slate-200 shadow-xl rounded-xl p-1.5 mt-0.5 z-50"
                    >
                      <div className="space-y-0.5">
                        {categories.map((cat: any) => (
                          <Link 
                            key={cat.name}
                            to={`/products?category=${cat.name}`}
                            className="flex items-center justify-between px-3 py-2 text-xs font-medium uppercase tracking-wider text-slate-500 hover:bg-slate-50 hover:text-slate-900 rounded-lg transition-all group/item"
                          >
                            <span>{cat.name}</span>
                            <ArrowRight size={10} className="opacity-0 -translate-x-1 group-hover/item:opacity-100 group-hover/item:translate-x-0 transition-all" />
                          </Link>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3 md:space-x-4">
            <div className="hidden sm:flex items-center relative group">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors">
                <Search size={14} strokeWidth={2} />
              </div>
              <input 
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (window.location.pathname !== '/products' && e.target.value) {
                    navigate('/products');
                  }
                }}
                className="w-32 md:w-48 pl-9 pr-3 py-1.5 bg-slate-100/50 border border-transparent rounded-lg text-xs font-medium focus:bg-white focus:border-slate-200 focus:ring-4 focus:ring-slate-900/5 transition-all outline-none"
              />
            </div>

            <div className="flex items-center space-x-2 md:space-x-4">
              <button 
                onClick={onOpenCart}
                className="relative p-2 md:p-2.5 bg-slate-900 text-white rounded-xl hover:bg-black active:scale-95 transition-all shadow-sm"
              >
                <ShoppingBag size={16} strokeWidth={2.5} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-primary/80 text-white text-xs font-black px-1.5 py-0.5 rounded-full border border-white shadow-sm">
                    {cartCount}
                  </span>
                )}
              </button>

              {currentUser ? (
                <div className="relative group">
                  <button className="w-8 h-8 md:w-10 md:h-10 rounded-xl overflow-hidden border border-slate-200 group-hover:border-slate-900 transition-all p-0.5">
                    <div className="w-full h-full bg-slate-50 rounded-[10px] flex items-center justify-center text-slate-400 group-hover:text-slate-900 transition-all">
                      <UserIcon size={16} />
                    </div>
                  </button>
                  <div className="absolute top-full right-0 mt-1.5 w-48 bg-white rounded-2xl shadow-2xl border border-slate-200 p-1.5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all translate-y-1 group-hover:translate-y-0 z-50">
                    <div className="px-3 py-2 border-b border-slate-50 mb-1">
                      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Signed in as</p>
                      <p className="text-xs font-bold text-slate-900 truncate">{currentUser.email}</p>
                    </div>
                    {(currentUser.role === 'Admin' || currentUser.role === 'Super Admin' || currentUser.role === 'Affiliate') && (
                      <Link to="/home/dashboard" className="flex items-center space-x-2 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-slate-900 rounded-xl transition-all">
                        <LayoutDashboard size={14} />
                        <span>Admin Panel</span>
                      </Link>
                    )}
                    <button 
                      onClick={onLogout}
                      className="w-full flex items-center space-x-2 px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50 rounded-xl transition-all"
                    >
                      <LogOut size={14} />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] md:hidden"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 h-full w-full max-w-[280px] bg-white shadow-2xl z-[110] flex flex-col md:hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <Link to="/" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center space-x-2">
                  <span className="premium-heading text-base text-slate-900 leading-none">{storeName}</span>
                </Link>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-label="Close navigation menu"
                  className="p-2 -mr-2 text-slate-400 hover:text-slate-900 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 py-6 space-y-8">
                {/* Mobile Search */}
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                    <Search size={14} strokeWidth={2} />
                  </div>
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      if (e.target.value) {
                        navigate('/products');
                        setIsMobileMenuOpen(false);
                      }
                    }}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div className="space-y-1">
                  <h3 className="px-3 text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Navigation</h3>
                  {navLinks.map((link) => (
                    <Link 
                      key={link.path}
                      to={link.path} 
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`block px-3 py-3 rounded-xl text-xs font-bold transition-all ${location.pathname === link.path ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`}
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>

                <div className="space-y-1">
                  <h3 className="px-3 text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">Categories</h3>
                  <div className="grid grid-cols-1 gap-1">
                    {categories.map((cat: any) => (
                      <Link 
                        key={cat.name}
                        to={`/products?category=${cat.name}`}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="flex items-center justify-between px-3 py-3 text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-slate-900 rounded-xl transition-all"
                      >
                        <span>{cat.name}</span>
                        <ArrowRight size={14} className="text-slate-300" />
                      </Link>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-slate-100">
                {currentUser ? (
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 px-3">
                      <div className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center font-bold">
                        {currentUser.email.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 truncate">{currentUser.email}</p>
                        <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">{currentUser.role}</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {(currentUser.role === 'Admin' || currentUser.role === 'Super Admin' || currentUser.role === 'Affiliate') && (
                        <Link 
                          to="/home/dashboard" 
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="flex items-center space-x-3 w-full px-3 py-3 text-xs font-medium uppercase tracking-wider text-slate-600 hover:bg-slate-50 hover:text-slate-900 rounded-xl transition-all"
                        >
                          <LayoutDashboard size={14} />
                          <span>Admin Panel</span>
                        </Link>
                      )}
                      <button 
                        onClick={() => {
                          onLogout();
                          setIsMobileMenuOpen(false);
                        }}
                        className="flex items-center space-x-3 w-full px-3 py-3 text-xs font-medium uppercase tracking-wider text-red-600 hover:bg-red-50 rounded-xl transition-all"
                      >
                        <LogOut size={14} />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
