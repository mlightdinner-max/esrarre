import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Truck, CheckCircle2, ChevronRight, Sparkles } from 'lucide-react';
import { Product, Order, CartItem } from '../../types';
import ProductCard from './ProductCard';
import RecommendedProducts from './RecommendedProducts';

interface HomePageProps {
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  products: Product[];
  config: any;
  orders: Order[];
  cart: CartItem[];
  token: string | null;
}

const HomePage = ({ 
  onAddToCart, 
  onUpdateQuantity,
  onRemoveItem,
  products, 
  config, 
  orders, 
  cart,
  token
}: HomePageProps) => {
  const getCartQuantity = (id: string) => cart.find(item => item.id === id)?.quantity || 0;
  const [currentBanner, setCurrentBanner] = useState(0);

  const approvedProducts = useMemo(() => products.filter(p => p.isApproved !== false), [products]);

  // Logic for New Launches (8 newest products)
  const newLaunches = useMemo(() => {
    return [...approvedProducts]
      .sort((a, b) => Number(b.id) - Number(a.id))
      .slice(0, 8);
  }, [approvedProducts]);

  const banners = useMemo(() => {
    const baseBanners = config.banners && config.banners.length > 0 
      ? config.banners 
      : [];
    
    // If banners link to /products, try to assign them to specific products from newLaunches
    return baseBanners.map((banner: any, idx: number) => {
      if (banner.link === '/products' && newLaunches[idx]) {
        return { ...banner, link: `/product/${newLaunches[idx].id}` };
      }
      return banner;
    });
  }, [config.banners, newLaunches]);

  // Logic for Top Reorder
  const topReorder = useMemo(() => {
    const productStats: Record<string, number> = {};
    orders.forEach(order => {
      const uniqueItemsInOrder = new Set(order.items.map(item => item.id));
      uniqueItemsInOrder.forEach(id => {
        productStats[id] = (productStats[id] || 0) + 1;
      });
    });

    const calculated = [...approvedProducts]
      .filter(p => (productStats[p.id] || 0) > 0)
      .sort((a, b) => (productStats[b.id] || 0) - (productStats[a.id] || 0));

    const customIds = config.customTopReorderedIds || [];
    const customProducts = customIds
      .map(id => approvedProducts.find(p => p.id === id))
      .filter((p): p is Product => !!p);

    const remainingCalculated = calculated.filter(p => !customIds.includes(p.id));
    const result = [...customProducts, ...remainingCalculated];

    return result.slice(0, 5);
  }, [approvedProducts, orders, config.customTopReorderedIds]);

  useEffect(() => {
    if (banners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentBanner(prev => (prev + 1) % banners.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [banners.length]);

  return (
    <div className="space-y-0">
      {/* Hero Slider */}
      {banners.length > 0 ? (
        <section className="relative h-[60vh] md:h-[80vh] overflow-hidden bg-slate-900">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentBanner}
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-0"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-950/40 to-transparent z-10" />
              {banners[currentBanner].image ? (
                <img 
                  src={banners[currentBanner].image} 
                  alt={banners[currentBanner].title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : null}
              <div className="absolute inset-0 z-20 flex items-center pt-8 md:pt-10">
                <div className="max-w-7xl mx-auto px-6 md:px-8 w-full">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.6 }}
                    className="max-w-2xl"
                  >
                    {config.heroTag && (
                      <span className="inline-block px-3 py-1 bg-primary text-white section-label rounded-full mb-4">
                        {config.heroTag}
                      </span>
                    )}
                    <h1 className="text-3xl sm:text-5xl md:text-6xl mb-6">
                      {banners[currentBanner].title || ''}
                    </h1>
                    <p className="text-sm md:text-base text-slate-300 font-medium mb-8 max-w-md leading-relaxed">
                      {banners[currentBanner].subtitle || ''}
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <Link 
                        to={banners[currentBanner].link || '/products'}
                        onClick={() => window.scrollTo(0, 0)}
                        className="px-8 py-3.5 bg-white text-slate-950 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-primary/80 hover:text-white transition-all transform hover:scale-105 shadow-xl shadow-black/10"
                      >
                        Shop Now
                      </Link>
                      <Link 
                        to="/products"
                        onClick={() => window.scrollTo(0, 0)}
                        className="px-8 py-3.5 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-white/20 transition-all"
                      >
                        View All
                      </Link>
                    </div>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
          
          {/* Slider Controls */}
          {banners.length > 1 && (
            <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex items-center space-x-3">
              {banners.map((_: any, idx: number) => (
                <button
                  key={`banner-dot-${idx}`}
                  onClick={() => setCurrentBanner(idx)}
                  className={`h-1 transition-all duration-500 rounded-full ${currentBanner === idx ? 'w-10 bg-primary/80' : 'w-4 bg-white/30 hover:bg-white/50'}`}
                />
              ))}
            </div>
          )}
        </section>
      ) : (
        <section className="h-[40vh] bg-slate-900 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-black text-white tracking-tighter uppercase italic">{config.storeName || ''}</h1>
            <p className="text-slate-400 mt-3 text-sm">{config.storeDescription || ''}</p>
          </div>
        </section>
      )}

      {/* Promotional Highlights */}
      <section className="bg-slate-50 py-3 border-b border-slate-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
            <div className="flex items-center space-x-2">
              <div className="p-1 bg-primary/10 text-primary rounded-lg">
                <Truck size={12} />
              </div>
              <span className="text-xs md:text-xs font-medium uppercase tracking-wider text-slate-900">Free Shipping</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="p-1 bg-primary/10 text-primary rounded-lg">
                <CheckCircle2 size={12} />
              </div>
              <span className="text-xs md:text-xs font-medium uppercase tracking-wider text-slate-900">COD Available</span>
            </div>
          </div>
        </div>
      </section>

      {/* Shop by Category */}
      {config.categories && config.categories.length > 0 && (
        <section className="py-20 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
              <div>
                <h2 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tighter uppercase italic mb-3 leading-none">Shop by Category</h2>
                <p className="text-slate-500 font-medium text-base">Explore our diverse range of premium selections.</p>
              </div>
              <Link 
                to="/products" 
                onClick={() => window.scrollTo(0, 0)}
                className="group flex items-center space-x-3 text-slate-950 font-black text-xs uppercase tracking-[0.2em] hover:text-primary transition-colors"
              >
                <span>View All</span>
                <div className="w-8 h-8 rounded-full border border-slate-200 flex items-center justify-center group-hover:bg-primary group-hover:border-primary group-hover:text-white transition-all">
                  <ChevronRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
                </div>
              </Link>
            </div>
            
            <div className="flex md:grid md:grid-cols-4 gap-5 overflow-x-auto no-scrollbar snap-x snap-mandatory -mx-4 px-4 sm:-mx-6 sm:px-6 md:mx-0 md:px-0 pb-6 md:pb-0">
              {config.categories.slice(0, 4).map((cat: any, idx: number) => (
                <Link 
                  key={`category-${cat.name || idx}-${idx}`} 
                  to={`/products?category=${cat.name}`}
                  onClick={() => window.scrollTo(0, 0)}
                  className="group relative aspect-[4/5] min-w-[240px] md:min-w-0 snap-start overflow-hidden rounded-3xl bg-slate-100 shadow-lg shadow-slate-950/5"
                >
                  {cat.image ? (
                    <img 
                      src={cat.image} 
                      alt={cat.name || 'Category'}
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-100 text-slate-300">
                      <Sparkles size={48} />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
                  <div className="absolute bottom-8 left-8 right-8">
                    <p className="section-label text-primary/60 mb-1.5">Collection</p>
                    <h3 className="text-white premium-heading text-2xl mb-3">{cat.name}</h3>
                    <div className="w-10 h-0.5 bg-primary/80 transition-all duration-500 group-hover:w-full" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* New Arrivals */}
      {newLaunches.length > 0 && (
        <section className="py-20 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
              <div>
                <h2 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tighter uppercase italic mb-3 leading-none">New Arrivals</h2>
                <p className="text-slate-500 font-medium text-base">Fresh additions to our curated collection.</p>
              </div>
              <Link 
                to="/products" 
                onClick={() => window.scrollTo(0, 0)}
                className="group flex items-center space-x-3 text-slate-950 font-black text-xs uppercase tracking-[0.2em] hover:text-primary transition-colors"
              >
                <span>Shop Collection</span>
                <div className="w-8 h-8 rounded-full border border-slate-200 flex items-center justify-center group-hover:bg-primary group-hover:border-primary group-hover:text-white transition-all">
                  <ChevronRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
                </div>
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              <div className="col-span-2 md:col-span-2 md:row-span-2">
                <ProductCard 
                  product={newLaunches[0]} 
                  onAddToCart={onAddToCart} 
                  onUpdateQuantity={onUpdateQuantity} 
                  onRemoveItem={onRemoveItem} 
                  cartQuantity={getCartQuantity(newLaunches[0].id)} 
                />
              </div>
              {newLaunches.slice(1, 5).map((product, idx) => (
                <div key={`new-arrival-${product.id}-${idx}`}>
                  <ProductCard 
                    product={product} 
                    onAddToCart={onAddToCart} 
                    onUpdateQuantity={onUpdateQuantity} 
                    onRemoveItem={onRemoveItem} 
                    cartQuantity={getCartQuantity(product.id)} 
                  />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* AI Recommendations */}
      {approvedProducts.length > 0 && (
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex items-center space-x-3 mb-10">
              <div className="p-2.5 bg-primary/5 text-primary rounded-xl">
                <Sparkles size={20} />
              </div>
              <div>
                <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase italic mb-0.5">Recommended for You</h2>
                <p className="text-slate-500 font-medium text-sm">Personalized suggestions based on your style.</p>
              </div>
            </div>
            <RecommendedProducts products={approvedProducts} config={config} onAddToCart={onAddToCart} onUpdateQuantity={onUpdateQuantity} onRemoveItem={onRemoveItem} cart={cart} token={token} />
          </div>
        </section>
      )}

      {/* Featured Section */}
      {config.qualityTitle && (
        <section className="py-10 md:py-20 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="relative rounded-[2.5rem] bg-slate-900 overflow-hidden min-h-[350px] md:min-h-[450px] flex items-center justify-center md:justify-start">
              <div className="absolute inset-0 opacity-40">
                {config.qualityImage ? (
                  <img 
                    src={config.qualityImage} 
                    alt="Featured"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : null}
              </div>
              <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-slate-950/80 via-slate-950/40 to-transparent z-0" />
              <div className="relative z-10 p-8 md:p-20 max-w-2xl text-center md:text-left">
                <h2 className="text-3xl md:text-6xl font-black text-white tracking-tighter leading-[0.95] uppercase italic mb-6">
                  {config.qualityTitle.split(' ').map((word: string, i: number) => (
                    <span key={`quality-word-${i}`} className={i === 1 ? "text-primary/80" : ""}>
                      {word} {i === 0 && <br className="hidden md:block" />}
                    </span>
                  ))}
                </h2>
                <p className="text-slate-300 text-sm md:text-lg font-medium mb-8 leading-relaxed max-w-lg mx-auto md:mx-0">
                  {config.qualityDescription || ""}
                </p>
                <Link 
                  to="/products"
                  onClick={() => window.scrollTo(0, 0)}
                  className="inline-block px-10 py-4 bg-primary text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-primary/80 transition-all transform hover:scale-105"
                >
                  Explore More
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Top Reordered Products */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-10">
            <div>
              <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase italic mb-1.5">Top Reordered Products</h2>
              <p className="text-slate-500 font-medium text-sm">The essentials our customers keep coming back for.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-5">
            {topReorder.length > 0 ? (
              topReorder.slice(0, 5).map((product, idx) => (
                <ProductCard key={`top-reorder-${product.id}-${idx}`} product={product} onAddToCart={onAddToCart} onUpdateQuantity={onUpdateQuantity} onRemoveItem={onRemoveItem} cartQuantity={getCartQuantity(product.id)} />
              ))
            ) : (
              <div className="col-span-full py-20 text-center bg-white rounded-[2.5rem] border-2 border-dashed border-slate-200">
                <p className="text-slate-400 font-medium uppercase tracking-wider text-xs">No reorders yet. Be the first!</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
