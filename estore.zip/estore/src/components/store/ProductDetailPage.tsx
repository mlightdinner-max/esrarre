import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShoppingCart, ArrowLeft, Truck, ShieldCheck, CheckCircle2, Minus, Plus, Trash2, Sparkles, Image, ChevronDown } from 'lucide-react';
import { Product, CartItem } from '../../types';
import RecommendedProducts from './RecommendedProducts';
import { LOCALIZATION } from '../../constants';
import Button from '../common/Button';

interface ProductDetailPageProps {
  products: Product[];
  onAddToCart: (p: Product, selectedVariants?: Record<string, string>) => void;
  onUpdateQuantity: (id: string, delta: number, variants?: Record<string, string>) => void;
  onRemoveItem: (id: string, variants?: Record<string, string>) => void;
  cart: CartItem[];
  config: any;
  token: string | null;
}

const ProductDetailPage = ({ 
  products, 
  onAddToCart, 
  onUpdateQuantity, 
  onRemoveItem, 
  cart, 
  config,
  token
}: ProductDetailPageProps) => {
  const { id } = useParams();
  const product = products.find(p => p.id === id);
  
  const getInitialVariants = (prod: typeof product): Record<string, string> => {
    if (!prod?.variants?.length) return {};
    const initial: Record<string, string> = {};
    prod.variants.forEach(v => {
      if (v.options && v.options.length > 0) initial[v.name] = v.options[0];
    });
    return initial;
  };

  const [currentId, setCurrentId] = useState(id);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>(
    () => getInitialVariants(product)
  );

  // When the product id changes (user navigates to a different product), reset variant selection
  if (id !== currentId) {
    setCurrentId(id);
    setSelectedVariants(getInitialVariants(product));
  }

  const variantString = JSON.stringify(selectedVariants);
  const cartItem = cart.find(item => 
    item.id === id && 
    (item.selectedVariants ? JSON.stringify(item.selectedVariants) : '{}') === (variantString === '{}' ? '{}' : variantString)
  );

  const [selectedImage, setSelectedImage] = useState(0);
  const isOutOfStock = product?.isOutOfStock || product?.stock === 0;
  const [isAdding, setIsAdding] = useState(false);

  const handleAddToCart = () => {
    if (!product) return;
    setIsAdding(true);
    onAddToCart(product, selectedVariants);
    setTimeout(() => setIsAdding(false), 600);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    // Track browsing history
    if (product) {
      const history = JSON.parse(localStorage.getItem('browsing_history') || '[]');
      const updatedHistory = [product.id, ...history.filter((h: string) => h !== product.id)].slice(0, 10);
      localStorage.setItem('browsing_history', JSON.stringify(updatedHistory));
    }
  }, [id, product]);

  if (!product) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="text-center space-y-6">
          <h2 className="text-2xl font-black text-slate-900 uppercase italic tracking-tighter">Product not found</h2>
          <Link to="/products" className="inline-block px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all">
            Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  const images = [product.image, ...(product.images || [])].filter(Boolean);
  if (images.length === 0) images.push(LOCALIZATION.FALLBACK_IMAGE);

  return (
    <div className="min-h-screen bg-white py-12 md:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <Link 
          to="/products"
          className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors mb-12 group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-xs font-medium uppercase tracking-wider">Back to Collection</span>
        </Link>

        <div className="flex flex-col lg:flex-row gap-8 lg:gap-24 mb-16 lg:mb-32">
          {/* Image Gallery */}
          <div className="flex-1 space-y-6">
            <div className="aspect-square rounded-2xl sm:rounded-[3rem] overflow-hidden bg-slate-50 border border-slate-100 shadow-2xl shadow-slate-950/5 relative group">
              <motion.img 
                key={selectedImage}
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                src={images[selectedImage]} 
                alt={product.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = LOCALIZATION.FALLBACK_IMAGE;
                }}
              />
              {product.isApproved === false && (
                <div className="absolute top-8 left-8">
                  <span className="px-4 py-1.5 bg-rose-500 text-white text-xs font-medium uppercase tracking-wider rounded-full shadow-lg">Pending Approval</span>
                </div>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                {images.map((img, idx) => (
                  <button
                    key={`thumb-${idx}`}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-24 h-24 rounded-2xl overflow-hidden border-2 transition-all flex-shrink-0 ${selectedImage === idx ? 'border-primary/80 scale-95' : 'border-slate-100 hover:border-slate-200'}`}
                  >
                  {img ? (
                    <img 
                      src={img} 
                      alt="" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer" 
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = LOCALIZATION.FALLBACK_IMAGE;
                      }}
                    />
                  ) : (
                    <div className="w-full h-full bg-slate-100 flex items-center justify-center text-slate-300">
                      <Image size={24} />
                    </div>
                  )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex-1 space-y-10">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <span className="px-3 py-1 bg-primary/5 text-primary text-xs font-medium uppercase tracking-wider rounded-full border border-primary/10">
                  {product.category}
                </span>
                {product.isApproved !== false && (
                  <div className={`flex items-center space-x-1 ${isOutOfStock ? 'text-slate-400' : 'text-primary'}`}>
                    <CheckCircle2 size={12} />
                    <span className="text-xs font-medium uppercase tracking-wider">{isOutOfStock ? 'Sold Out' : 'In Stock'}</span>
                  </div>
                )}
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tighter leading-[0.95] uppercase italic">
                {product.name}
              </h1>
              <div className="flex flex-col space-y-1">
                {(product.mrp ?? 0) > 0 && (product.mrp ?? 0) > product.price && (
                  <p className="text-sm text-slate-400 font-bold uppercase tracking-widest line-through">{LOCALIZATION.CURRENCY}{(product.mrp ?? 0).toLocaleString()}</p>
                )}
                <p className="text-3xl md:text-5xl font-black text-slate-900 tracking-tighter">{LOCALIZATION.CURRENCY}{product.price.toLocaleString()}</p>
              </div>
            </div>

            <div className="prose prose-slate max-w-none">
              <p className="text-slate-600 font-medium text-lg leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Variants Selection */}
            {product.variants && product.variants.length > 0 && (
              <div className="space-y-6 pt-6 border-t border-slate-100">
                <h4 className="text-xs font-medium text-slate-400 uppercase tracking-wider">Select Options</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {product.variants.map((variant) => (
                    <div key={variant.id} className="space-y-2">
                      <label className="text-xs font-medium text-slate-900 uppercase tracking-wider block">{variant.name}</label>
                      <div className="relative">
                        <select 
                          value={selectedVariants[variant.name] || ''}
                          onChange={(e) => setSelectedVariants(prev => ({ ...prev, [variant.name]: e.target.value }))}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold appearance-none cursor-pointer focus:border-primary/50 transition-colors uppercase outline-none"
                        >
                          {variant.options.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                          <ChevronDown size={14} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-6 pt-6 border-t border-slate-100">
              {cartItem ? (
                <div className="flex items-center space-x-6">
                  <div className="flex items-center bg-slate-100 rounded-2xl p-1 border border-slate-200">
                    <button 
                      onClick={() => onUpdateQuantity(product.id, -1, selectedVariants)}
                      aria-label={cartItem.quantity === 1 ? `Remove ${product.name} from cart` : `Decrease quantity of ${product.name}`}
                      className="w-12 h-12 flex items-center justify-center text-slate-500 hover:text-slate-900 transition-colors"
                    >
                      {cartItem.quantity === 1 ? <Trash2 size={18} className="text-rose-500" /> : <Minus size={18} />}
                    </button>
                    <span className="w-12 text-center font-black text-slate-900 text-lg">{cartItem.quantity}</span>
                    <button 
                      onClick={() => onUpdateQuantity(product.id, 1, selectedVariants)}
                      aria-label={`Increase quantity of ${product.name}`}
                      className="w-12 h-12 flex items-center justify-center text-slate-500 hover:text-slate-900 transition-colors"
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                  <div className="flex-1 p-4 bg-primary/5 rounded-2xl border border-primary/10 flex items-center justify-between">
                    <span className="text-xs font-black text-primary-dark uppercase tracking-widest">Added to Cart</span>
                    <CheckCircle2 size={18} className="text-primary" />
                  </div>
                </div>
              ) : (
                <Button
                  onClick={handleAddToCart}
                  isLoading={isAdding}
                  size="xl"
                  variant="dark"
                  className="w-full"
                  disabled={isOutOfStock}
                  leftIcon={isAdding ? undefined : <ShoppingCart size={18} />}
                >
                  {isOutOfStock ? 'Temporarily Unavailable' : 'Add to Collection'}
                </Button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-3">
                <Truck size={20} className="text-primary" />
                <div>
                  <p className="text-xs font-medium text-slate-900 uppercase tracking-wider">Free Delivery</p>
                  <p className="text-xs text-emerald-600 font-medium uppercase tracking-wider">On All Orders</p>
                </div>
              </div>
              <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-3">
                <ShieldCheck size={20} className="text-primary" />
                <div>
                  <p className="text-xs font-medium text-slate-900 uppercase tracking-wider">Secure Payment</p>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">100% Protected</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recommended Products */}
        <section className="space-y-12">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-primary/5 text-primary rounded-xl">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-slate-950 tracking-tighter uppercase italic mb-0.5">You May Also Like</h2>
              <p className="text-slate-500 font-medium text-sm">Curated selections matching your taste.</p>
            </div>
          </div>
          <RecommendedProducts 
            products={products.filter(p => p.id !== id && p.isApproved !== false)} 
            config={config} 
            onAddToCart={onAddToCart} 
            onUpdateQuantity={onUpdateQuantity} 
            onRemoveItem={onRemoveItem} 
            cart={cart} 
            token={token}
          />
        </section>
      </div>
    </div>
  );
};

export default ProductDetailPage;
