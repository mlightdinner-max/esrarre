import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { Package, CheckCircle2, Globe, Heart, ShieldCheck } from 'lucide-react';

interface AboutPageProps {
  config: any;
  ordersCount: number;
}

const AboutPage = ({ config, ordersCount }: AboutPageProps) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const storyContent = config.aboutContent || (config.storeName ? `${config.storeName} was founded in 2026 with a simple mission: to provide high-quality, minimalist essentials that enhance your daily life.` : '');
  const mission = config.aboutMission || "To elevate the standard of everyday essentials through uncompromising quality and intentional design.";
  const vision = config.aboutVision || "To become the global destination for curated minimalist excellence.";

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[70vh] min-h-[500px] flex items-center justify-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0">
          {config.aboutHeroImage ? (
            <img 
              src={config.aboutHeroImage} 
              alt="About Us" 
              className="w-full h-full object-cover opacity-60"
              referrerPolicy="no-referrer"
            />
          ) : (
             <div className="w-full h-full bg-slate-950" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-4"
          >
            <span className="px-4 py-1.5 bg-primary/20 text-primary text-xs font-black uppercase tracking-[0.3em] rounded-full backdrop-blur-md border border-primary/20 inline-block">
              Our Journey
            </span>
            <h1 className="text-5xl md:text-8xl font-black text-white tracking-tighter leading-[0.95] uppercase italic">
              Legacy of <br/> <span className="text-primary italic">Excellence</span>
            </h1>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 md:py-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-10">
              <div className="space-y-4">
                <h2 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tighter uppercase italic leading-none">Our Genesis</h2>
                <p className="text-slate-500 font-bold text-xs uppercase tracking-[0.4em]">Chronological Evolution</p>
              </div>
              <p className="text-slate-600 text-lg md:text-xl font-medium leading-relaxed whitespace-pre-wrap">
                {storyContent}
              </p>
              <div className="flex flex-wrap gap-8 pt-6">
                <div className="space-y-1">
                  <p className="text-3xl font-black text-slate-900 tracking-tighter">{ordersCount}+</p>
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Global Referrals</p>
                </div>
                <div className="w-px h-12 bg-slate-100 hidden md:block" />
                <div className="space-y-1">
                  <p className="text-3xl font-black text-slate-900 tracking-tighter">100%</p>
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Quality Invariant</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] rounded-[3rem] bg-slate-100 overflow-hidden shadow-2xl relative z-10">
                <img 
                  src={config.aboutStoryImage || "https://picsum.photos/seed/legacy/800/1000"} 
                  alt="Our Story" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -top-10 -right-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl z-0" />
              <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl z-0" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 md:py-40 bg-slate-50 border-y border-slate-200/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-6 sm:p-12 md:p-16 rounded-[2.5rem] shadow-sm border border-slate-200/60 space-y-8 group hover:-translate-y-2 transition-all duration-500">
              <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center border border-primary/10 group-hover:bg-primary group-hover:text-white transition-all duration-500 shadow-sm">
                <Globe size={32} />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl md:text-4xl font-black text-slate-950 tracking-tighter uppercase italic leading-tight">Objective Mission</h3>
                <p className="text-slate-600 font-medium text-lg italic leading-relaxed">
                  "{mission}"
                </p>
              </div>
            </div>

            <div className="bg-white p-6 sm:p-12 md:p-16 rounded-[2.5rem] shadow-sm border border-slate-200/60 space-y-8 group hover:-translate-y-2 transition-all duration-500">
              <div className="w-16 h-16 bg-primary/5 text-primary rounded-[1.5rem] flex items-center justify-center border border-primary/10 group-hover:bg-primary group-hover:text-white transition-all duration-500 shadow-sm">
                <CheckCircle2 size={32} />
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl md:text-4xl font-black text-slate-950 tracking-tighter uppercase italic leading-tight">Strategic Vision</h3>
                <p className="text-slate-600 font-medium text-lg leading-relaxed">
                  {vision}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 md:py-40 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center space-y-6 mb-20">
            <h2 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tighter uppercase italic leading-none">Core Principles</h2>
            <p className="text-slate-500 font-bold text-xs uppercase tracking-[0.4em]">Our Structural Foundations</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Information Density', desc: 'Precision-engineered products with high functional utility.', icon: Package },
              { title: 'Quality Invariant', desc: 'Zero compromise on material integrity and build standards.', icon: ShieldCheck },
              { title: 'User Centricity', desc: 'Designed for the lifestyle patterns of the modern era.', icon: Heart }
            ].map((value, idx) => (
              <div key={idx} className="p-10 bg-slate-50 rounded-[2rem] border border-slate-100 space-y-6 text-center group hover:bg-slate-900 transition-all duration-500">
                <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center mx-auto text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500 shadow-sm">
                  <value.icon size={24} />
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest group-hover:text-white transition-colors">{value.title}</h4>
                  <p className="text-slate-500 text-xs font-medium leading-relaxed group-hover:text-slate-400 transition-colors">{value.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
