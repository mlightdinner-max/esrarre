import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence } from 'motion/react';
import { Truck, CheckCircle2, Package } from 'lucide-react';
import { LOCALIZATION } from '../../constants';
import { Product, CartItem } from '../../types';
import ProductCard from './ProductCard';

interface ProductsPageProps {
  onAddToCart: (p: Product) => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  products: Product[];
  config: any;
  cart: CartItem[];
  searchQuery: string;
}

const ProductsPage = ({ 
  onAddToCart, 
  onUpdateQuantity, 
  onRemoveItem, 
  products, 
  config, 
  cart, 
  searchQuery 
}: ProductsPageProps) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCategory = searchParams.get('category') || 'All';
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const [sortBy, setSortBy] = useState<'newest' | 'price-low' | 'price-high'>('newest');
  
  const [pageState, setPageState] = React.useState<{ page: number; filterKey: string }>({ page: 1, filterKey: '' });
  const filterKey = `${searchQuery}|${sortBy}|${priceRange[0]}|${priceRange[1]}|${selectedCategory}`;
  const currentPage = pageState.filterKey === filterKey ? pageState.page : 1;
  const setCurrentPage = (p: number | ((prev: number) => number)) => {
    setPageState(prev => {
      const next = typeof p === 'function' ? p(prev.filterKey === filterKey ? prev.page : 1) : p;
      return { page: next, filterKey };
    });
  };

  const handleCategoryChange = (cat: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (cat === 'All') {
      newParams.delete('category');
    } else {
      newParams.set('category', cat);
    }
    setSearchParams(newParams);
    setCurrentPage(1);
  };

  const filteredProducts = useMemo(() => {
    let filtered = products.filter(p => p.isApproved !== false);
    
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    filtered = filtered.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else {
      filtered.sort((a, b) => b.id.localeCompare(a.id));
    }

    return filtered;
  }, [selectedCategory, products, searchQuery, priceRange, sortBy]);

  const itemsPerPage = 12;
  const categories = ['All', ...(config.categories?.map((c: any) => c.name) || [])];
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredProducts.slice(start, start + itemsPerPage);
  }, [filteredProducts, currentPage]);

  const getCartQuantity = (id: string) => cart.find(item => item.id === id)?.quantity || 0;

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-8">
        {/* Promotional Highlights */}
        <section className="mb-8 bg-slate-50 py-3 border border-slate-100 rounded-2xl">
          <div className="px-4">
            <div className="flex flex-wrap justify-center items-center gap-6 md:gap-12">
              <div className="flex items-center space-x-2">
                <div className="p-1 bg-primary/10 text-primary rounded-lg">
                  <Truck size={12} />
                </div>
                <span className="text-xs font-medium uppercase tracking-wider text-slate-900">Free Shipping</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="p-1 bg-primary/10 text-primary rounded-lg">
                  <CheckCircle2 size={12} />
                </div>
                <span className="text-xs font-medium uppercase tracking-wider text-slate-900">COD Available</span>
              </div>
            </div>
          </div>
        </section>

        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div className="relative">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 uppercase">
              Shop 
              <span className="text-primary ml-2">All Products</span>
            </h1>
            <div className="mt-1 flex items-center space-x-2">
              <div className="h-0.5 w-8 bg-primary/80 rounded-full" />
              <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">{filteredProducts.length} items curated for you</p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 w-full sm:w-auto">
            <div className="flex flex-col space-y-2 w-full sm:w-auto sm:min-w-[160px]">
              <div className="flex justify-between items-center px-1">
                <label className="text-xs font-medium uppercase tracking-wider text-slate-400">
                  {LOCALIZATION.CURRENCY}{priceRange[0].toLocaleString()} – {LOCALIZATION.CURRENCY}{priceRange[1].toLocaleString()}
                </label>
                <button 
                  onClick={() => setPriceRange([0, 100000])}
                  className="text-xs font-black uppercase text-primary hover:underline"
                >
                  Reset
                </button>
              </div>
              <input 
                type="range" 
                min="0" 
                max="100000" 
                step="500"
                value={priceRange[1]}
                onChange={(e) => {
                  setPriceRange([priceRange[0], parseInt(e.target.value)]);
                  setCurrentPage(1);
                }}
                className="w-full h-1.5 bg-slate-100 accent-primary rounded-lg cursor-pointer appearance-none"
              />
            </div>

            <div className="flex bg-slate-100 p-1 rounded-xl overflow-x-auto no-scrollbar max-w-full">
              {categories.map((cat, idx) => (
                <button
                  key={`desktop-cat-${cat}-${idx}`}
                  onClick={() => handleCategoryChange(cat)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-medium uppercase tracking-wider transition-all whitespace-nowrap ${
                    selectedCategory === cat 
                      ? 'bg-white text-slate-900 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
            
            <select 
              value={sortBy}
              onChange={(e) => {
                setSortBy(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full sm:w-auto bg-slate-100 border-none rounded-xl px-3 py-1.5 text-xs font-medium uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-primary/20 text-slate-900 cursor-pointer"
            >
              <option value="newest">Newest First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-6 content-start">
          <AnimatePresence mode="popLayout">
            {paginatedProducts.map((product, idx) => (
              <ProductCard key={`product-page-${product.id}-${idx}-${currentPage}`} product={product} onAddToCart={onAddToCart} onUpdateQuantity={onUpdateQuantity} onRemoveItem={onRemoveItem} cartQuantity={getCartQuantity(product.id)} />
            ))}
          </AnimatePresence>
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="mt-16 flex justify-center items-center space-x-2">
            <button
              onClick={() => {
                setCurrentPage(p => Math.max(1, p - 1));
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              disabled={currentPage === 1}
              className="px-4 h-10 bg-white text-slate-400 border border-slate-100 rounded-xl font-black text-xs uppercase tracking-widest hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Prev
            </button>
            <div className="flex items-center space-x-1">
              {[...Array(totalPages)].map((_, idx) => {
                const page = idx + 1;
                const isCurrent = currentPage === page;
                
                // Only show 5 pages around the current one if many pages exist
                if (totalPages > 7) {
                  if (page > 1 && page < totalPages && (page < currentPage - 1 || page > currentPage + 1)) {
                    if (page === currentPage - 2 || page === currentPage + 2) {
                      return <span key={`ellipsis-${page}`} className="px-2 text-slate-300 text-xs">...</span>;
                    }
                    return null;
                  }
                }

                return (
                  <button
                    key={`page-${page}`}
                    onClick={() => {
                      setCurrentPage(page);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-10 h-10 rounded-xl font-black text-xs transition-all ${
                      isCurrent 
                        ? 'bg-slate-900 text-white shadow-xl shadow-slate-900/10' 
                        : 'bg-white text-slate-400 border border-slate-100 hover:border-slate-200 hover:text-slate-900'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => {
                setCurrentPage(p => Math.min(totalPages, p + 1));
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              disabled={currentPage === totalPages}
              className="px-4 h-10 bg-white text-slate-400 border border-slate-100 rounded-xl font-black text-xs uppercase tracking-widest hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Next
            </button>
          </div>
        )}

        {filteredProducts.length === 0 && (
          <div className="py-24 text-center">
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-slate-300 border border-slate-100">
              <Package size={32} />
            </div>
            <h3 className="text-lg font-bold uppercase text-slate-900 mb-1">No products found</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Try adjusting your filters or search query.</p>
            <button 
              onClick={() => {
                handleCategoryChange('All');
                setPriceRange([0, 100000]);
                setSortBy('newest');
              }}
              className="mt-6 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-medium uppercase tracking-wider hover:bg-black transition-all shadow-lg shadow-slate-900/10"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductsPage;
