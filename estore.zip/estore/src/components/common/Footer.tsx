import React from 'react';
import { 
  Instagram, 
  Twitter, 
  Facebook, 
  Mail, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  CreditCard 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { LOCALIZATION } from '../../constants';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white border-t border-slate-200 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Section */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-slate-900 text-white rounded-2xl flex items-center justify-center shadow-xl shadow-slate-900/10 group-hover:scale-110 transition-transform duration-500">
                <span className="text-xl font-black italic tracking-tighter">M</span>
              </div>
              <span className="text-xl font-black tracking-tighter text-slate-900 uppercase">Modern<span className="text-slate-400">Store</span></span>
            </Link>
            <p className="text-slate-500 text-sm leading-relaxed font-medium">
              Elevating your lifestyle with premium products and seamless shopping experiences. Quality guaranteed.
            </p>
            <div className="flex items-center gap-4">
              {[Instagram, Twitter, Facebook].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all duration-300 border border-slate-100">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-xs font-medium text-slate-900 uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-4">
              {['New Arrivals', 'Best Sellers', 'Trending Now', 'Special Offers', 'Gift Cards'].map((link, i) => (
                <li key={i}>
                  <Link to="#" className="text-slate-500 hover:text-slate-900 text-sm font-medium transition-colors flex items-center gap-2 group">
                    <div className="w-1 h-1 bg-slate-200 rounded-full group-hover:bg-slate-900 transition-colors" />
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div className="space-y-6">
            <h4 className="text-xs font-medium text-slate-900 uppercase tracking-wider">Customer Support</h4>
            <ul className="space-y-4">
              {['Track Order', 'Shipping Policy', 'Returns & Exchanges', 'FAQs', 'Privacy Policy'].map((link, i) => (
                <li key={i}>
                  <Link to="#" className="text-slate-500 hover:text-slate-900 text-sm font-medium transition-colors flex items-center gap-2 group">
                    <div className="w-1 h-1 bg-slate-200 rounded-full group-hover:bg-slate-900 transition-colors" />
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-xs font-medium text-slate-900 uppercase tracking-wider">Get In Touch</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-4 group">
                <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center border border-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-all duration-300">
                  <MapPin size={18} />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Location</p>
                  <p className="text-sm font-bold text-slate-900 tracking-tight">123 Fashion Ave, NY 10001</p>
                </div>
              </div>
              <div className="flex items-start gap-4 group">
                <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center border border-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-all duration-300">
                  <Phone size={18} />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Phone</p>
                  <p className="text-sm font-bold text-slate-900 tracking-tight">+1 (555) 000-0000</p>
                </div>
              </div>
              <div className="flex items-start gap-4 group">
                <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center border border-slate-100 group-hover:bg-slate-900 group-hover:text-white transition-all duration-300">
                  <Mail size={18} />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Email</p>
                  <p className="text-sm font-bold text-slate-900 tracking-tight">hello@modernstore.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-y border-slate-100 mb-12">
          {[
            { icon: Truck, label: 'Free Shipping', desc: `On orders over ${LOCALIZATION.CURRENCY}999` },
            { icon: RotateCcw, label: 'Easy Returns', desc: '30-day return policy' },
            { icon: ShieldCheck, label: 'Secure Payment', desc: '100% secure checkout' },
            { icon: CreditCard, label: 'Multiple Options', desc: 'UPI, Cards, COD' }
          ].map((feature, i) => (
            <div key={i} className="flex items-center gap-4 group">
              <div className="w-12 h-12 bg-slate-50 text-slate-900 rounded-2xl flex items-center justify-center border border-slate-100 group-hover:scale-110 transition-transform duration-500">
                <feature.icon size={24} />
              </div>
              <div className="space-y-0.5">
                <p className="text-sm font-bold text-slate-900 tracking-tight">{feature.label}</p>
                <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">
            © {currentYear} ModernStore. All rights reserved.
          </p>
          <div className="flex items-center gap-8">
            {['Terms', 'Privacy', 'Cookies', 'Sitemap'].map((link, i) => (
              <Link key={i} to="#" className="text-xs font-medium text-slate-400 uppercase tracking-wider hover:text-slate-900 transition-colors">
                {link}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
