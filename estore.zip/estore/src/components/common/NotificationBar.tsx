import React from 'react';
import { motion } from 'motion/react';
import { Bell, X } from 'lucide-react';

interface NotificationBarProps {
  notifications: any[];
  onClose: (id: string) => void;
}

const NotificationBar = ({ notifications, onClose }: NotificationBarProps) => {
  if (!notifications || notifications.length === 0) return null;

  return (
    <div className="relative z-[100]">
      {notifications.map((notif) => (
        <motion.div
          key={notif.id}
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="bg-primary text-white overflow-hidden"
        >
          <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Bell size={16} className="shrink-0" />
              <p className="text-sm font-bold tracking-tight">{notif.message}</p>
            </div>
            <button 
              onClick={() => onClose(notif.id)}
              className="p-1 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default NotificationBar;
