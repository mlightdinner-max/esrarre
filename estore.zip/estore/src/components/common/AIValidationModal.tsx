import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, AlertCircle, Edit } from 'lucide-react';

interface AIValidationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  issues: string[];
  onSecondaryAction: () => void;
  secondaryActionLabel?: string;
}

const AIValidationModal = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  issues,
  onSecondaryAction,
  secondaryActionLabel = "Edit Information"
}: AIValidationModalProps) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            onClick={onClose} 
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
          />
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 20 }} 
            animate={{ scale: 1, opacity: 1, y: 0 }} 
            exit={{ scale: 0.95, opacity: 0, y: 20 }} 
            className="relative bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl space-y-6 border border-slate-200"
          >
            <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mx-auto border border-amber-100 shadow-sm">
              <ShieldAlert size={24} />
            </div>
            
            <div className="text-center space-y-1">
              <h2 className="text-lg font-bold tracking-tight text-slate-900">Wait, something's not right</h2>
              <p className="text-xs text-slate-500 font-bold uppercase tracking-widest leading-relaxed">Our AI detected some potential issues with your information:</p>
            </div>

            <div className="space-y-2">
              {issues.map((issue, idx) => (
                <div key={idx} className="flex items-start space-x-3 p-3 bg-amber-50 rounded-xl border border-amber-100">
                  <AlertCircle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-amber-900 font-bold tracking-tight">{issue}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-col space-y-2">
              <button 
                onClick={onSecondaryAction}
                className="w-full py-2.5 bg-slate-900 text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-black transition-all flex items-center justify-center space-x-2 shadow-lg shadow-slate-900/10"
              >
                <Edit size={14} />
                <span>{secondaryActionLabel}</span>
              </button>
              <button 
                onClick={onConfirm}
                className="w-full py-2.5 bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-widest rounded-xl hover:bg-slate-100 transition-all border border-slate-200"
              >
                Save Anyway & Proceed
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default AIValidationModal;
