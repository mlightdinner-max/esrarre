import React from 'react';
import { motion } from 'motion/react';
import { X, AlertCircle, Info } from 'lucide-react';
import Button from './Button';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  type?: 'danger' | 'warning' | 'info';
  isLoading?: boolean;
}

const ConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  type = 'info',
  isLoading = false
}: ConfirmationModalProps) => {
  if (!isOpen) return null;

  const variants: Record<string, 'danger' | 'warning' | 'dark'> = {
    danger: 'danger',
    warning: 'warning',
    info: 'dark'
  };

  const iconColors = {
    danger: 'bg-rose-50 text-rose-600',
    warning: 'bg-amber-50 text-amber-600',
    info: 'bg-blue-50 text-blue-600'
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white w-full max-w-md rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-200"
      >
        <div className="p-8 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xl font-black text-slate-950 uppercase italic tracking-tighter">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
            <X size={20} />
          </button>
        </div>
        <div className="p-8 space-y-6">
          <div className={`p-4 rounded-2xl border flex items-start gap-4 ${iconColors[type]} border-current/10`}>
            <div className={`p-2 rounded-lg ${type === 'danger' ? 'bg-rose-500' : type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'} text-white`}>
              {type === 'danger' ? <AlertCircle size={16} /> : type === 'warning' ? <AlertCircle size={16} /> : <Info size={16} />}
            </div>
            <div>
              <p className="text-sm font-semibold">Attention Required</p>
              <p className="text-xs font-medium leading-relaxed mt-1 opacity-80">
                {message}
              </p>
            </div>
          </div>
        </div>
        <div className="p-8 flex items-center justify-end gap-4 bg-slate-50/50">
          <Button 
            variant="ghost" 
            onClick={onClose}
            disabled={isLoading}
          >
            {cancelText}
          </Button>
          <Button 
            variant={variants[type]}
            onClick={() => { onConfirm(); if(!isLoading) onClose(); }}
            isLoading={isLoading}
          >
            {confirmText}
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default ConfirmationModal;
