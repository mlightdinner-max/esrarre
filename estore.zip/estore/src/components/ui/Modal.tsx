// Re-exports common/Modal as a named export for backwards compatibility.
// The single source of truth is src/components/common/Modal.tsx
export { default as Modal } from '../common/Modal';
