/**
 * AI Service for communicating with the backend AI proxy.
 * Handles graceful bypass if AI is unavailable.
 */

export interface AIStatus {
  isHealthy: boolean;
  lastError: string | null;
  isEnabled: boolean;
  isAvailable: boolean;
  cooldownUntil: number;
}

class AIService {
  private status: AIStatus | null = null;
  private lastChecked: number = 0;
  private CHECK_INTERVAL = 60000; // Check status every minute

  async getStatus(apiKey?: string): Promise<AIStatus> {
    if (!apiKey && this.status && Date.now() - this.lastChecked < this.CHECK_INTERVAL) {
      return this.status;
    }

    try {
      const url = new URL('/api/v1/ai/status', window.location.origin);
      if (apiKey) url.searchParams.append('apiKey', apiKey);
      
      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      this.status = data;
      this.lastChecked = Date.now();
      return data;
    } catch (error) {
      console.error("Failed to check AI status:", error);
      return {
        isHealthy: false,
        lastError: "Failed to connect to status endpoint",
        isEnabled: false,
        isAvailable: false,
        cooldownUntil: 0
      } as any;
    }
  }

  async generateDescription(name: string, category?: string, currentDescription?: string, apiKey?: string): Promise<string | null> {
    try {
      const response = await fetch('/api/v1/ai/generate-description', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, category, currentDescription, apiKey })
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        if (data.unavailable) return null;
        throw new Error(data.error || "Generation failed");
      }

      const data = await response.json();
      return data.text;
    } catch (error) {
      console.error("AI Description Error:", error);
      return null;
    }
  }

  async generateTags(name: string, category?: string, description?: string, apiKey?: string): Promise<string[]> {
    try {
      const response = await fetch('/api/v1/ai/generate-tags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, category, description, apiKey })
      });

      if (!response.ok) return [];

      const data = await response.json();
      return data.tags || [];
    } catch (error) {
      console.error("AI Tag Generation Error:", error);
      return [];
    }
  }

  async suggestTaxonomy(type: 'categories' | 'tags', apiKey?: string): Promise<string[]> {
    try {
      const response = await fetch('/api/v1/ai/generate-taxonomy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, apiKey })
      });

      if (!response.ok) return [];

      const data = await response.json();
      return data.suggestions || [];
    } catch (error) {
      console.error("AI Taxonomy Suggestion Error:", error);
      return [];
    }
  }

  async validateCheckout(formData: any, apiKey?: string): Promise<any> {
    try {
      const response = await fetch('/api/v1/ai/validate-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, apiKey })
      });

      if (!response.ok) return { issues: [], unavailable: true };

      const data = await response.json();
      return data;
    } catch (error) {
      console.error("AI Validation Error:", error);
      return { issues: [], unavailable: true };
    }
  }

  async getRecommendations(products: any[], historyNames: string[], apiKey?: string): Promise<string[]> {
    try {
      // Send only names to reduce payload size
      const productNames = products.map(p => p.name);
      const response = await fetch('/api/v1/ai/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products: productNames, historyNames, apiKey })
      });

      if (!response.ok) return [];

      const data = await response.json();
      return data.recommendedNames || [];
    } catch (error) {
      console.error("AI Recommendation Error:", error);
      return [];
    }
  }
}

export const aiService = new AIService();
