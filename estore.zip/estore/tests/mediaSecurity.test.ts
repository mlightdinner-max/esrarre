/**
 * Media route security tests
 *
 * Verifies that the sanitizePath helper and assertInsideUploads guard prevent
 * path traversal attacks regardless of encoding.
 *
 * The functions below mirror the implementation in src/server/routes/media.ts
 * so they can be tested in pure isolation without Express.
 */

import { describe, it, expect } from 'vitest';
import * as path from 'path';

const UPLOADS_DIR = '/app/uploads';

function sanitizePath(sub: string): string {
  let decoded = sub;
  try { decoded = decodeURIComponent(sub); } catch { /* keep original */ }
  return decoded
    .replace(/\\/g, '/')
    .split('/')
    .filter(seg => seg !== '' && seg !== '.' && seg !== '..')
    .join('/');
}

function assertInsideUploads(target: string): boolean {
  const resolved = path.resolve(target);
  const base = path.resolve(UPLOADS_DIR);
  return resolved === base || resolved.startsWith(base + path.sep);
}

describe('sanitizePath', () => {
  it('passes clean paths through unchanged', () => {
    expect(sanitizePath('products/shoes')).toBe('products/shoes');
  });

  it('strips literal ../ traversal — result stays inside uploads when joined', () => {
    const result = sanitizePath('../../../etc/passwd');
    expect(result).not.toContain('..');
    expect(assertInsideUploads(path.join(UPLOADS_DIR, result))).toBe(true);
  });

  it('strips URL-encoded ../ traversal (%2e%2e%2f) — stays inside uploads', () => {
    const result = sanitizePath('%2e%2e%2fetc%2fpasswd');
    expect(result).not.toContain('..');
    expect(assertInsideUploads(path.join(UPLOADS_DIR, result))).toBe(true);
  });

  it('strips mixed encoded/literal traversal', () => {
    const result = sanitizePath('products/%2e%2e/%2e%2e/etc/passwd');
    expect(result).not.toContain('..');
    expect(assertInsideUploads(path.join(UPLOADS_DIR, result))).toBe(true);
  });

  it('strips double-encoded ../ — second level is not decoded further', () => {
    const result = sanitizePath('%252e%252e%252fetc');
    expect(result).not.toContain('..');
  });

  it('strips leading slashes', () => {
    expect(sanitizePath('/absolute/path')).toBe('absolute/path');
  });

  it('strips trailing slashes', () => {
    expect(sanitizePath('some/path/')).toBe('some/path');
  });

  it('collapses double slashes', () => {
    expect(sanitizePath('a//b///c')).toBe('a/b/c');
  });

  it('normalises backslashes to forward slashes', () => {
    expect(sanitizePath('a\\b\\c')).toBe('a/b/c');
  });

  it('returns empty string for empty input', () => {
    expect(sanitizePath('')).toBe('');
  });
});

describe('assertInsideUploads', () => {
  it('accepts a path directly inside UPLOADS_DIR', () => {
    expect(assertInsideUploads(`${UPLOADS_DIR}/products/img.jpg`)).toBe(true);
  });

  it('accepts UPLOADS_DIR itself', () => {
    expect(assertInsideUploads(UPLOADS_DIR)).toBe(true);
  });

  it('rejects a path outside UPLOADS_DIR', () => {
    expect(assertInsideUploads('/etc/passwd')).toBe(false);
  });

  it('rejects a path that escapes via path.join traversal', () => {
    const malicious = path.join(UPLOADS_DIR, '..', 'etc', 'passwd');
    expect(assertInsideUploads(malicious)).toBe(false);
  });

  it('rejects a sibling directory with a similar prefix', () => {
    expect(assertInsideUploads('/app/uploads-evil')).toBe(false);
  });
});
