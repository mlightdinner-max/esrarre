/**
 * OrderService unit tests
 *
 * Covers:
 *  - calculateFinancials: coupon validation, discount computation, affiliate commission
 *  - detectDummy: keyword detection
 *  - processStatusChange: item/order state machine, terminal guards
 */

import { describe, it, expect } from 'vitest';
import { OrderService } from '../src/server/services/orderService';

// ── Fixtures ──────────────────────────────────────────────────────────────────

const makeProduct = (overrides: any = {}) => ({
  id: 'prod-1',
  name: 'Widget',
  price: 100,
  originalCost: 40,
  stock: 10,
  status: 'active',
  isDeleted: false,
  ...overrides,
});

const makeConfig = (overrides: any = {}) => ({
  orderStatuses: [
    { label: 'Delivered', isTerminal: true },
    { label: 'Cancelled', isTerminal: true },
    { label: 'Returned', isTerminal: true },
    { label: 'OPEN', isTerminal: false },
    { label: 'Processing', isTerminal: false },
    { label: 'Shipped', isTerminal: false },
    { label: 'WAITING TO CLOSE', isTerminal: true },
    { label: 'CLOSED', isTerminal: true },
  ],
  affiliateSettings: {
    defaultCommissionRate: 10,
    allowNonAssignedCommissions: false,
    nonAssignedCommissionRate: 5,
  },
  returnWindowDays: 5,
  ...overrides,
});

const makeOrderData = (overrides: any = {}) => ({
  items: [{ id: 'prod-1', name: 'Widget', quantity: 1, price: 100 }],
  shipping: 0,
  ...overrides,
});

// ── calculateFinancials ───────────────────────────────────────────────────────

describe('OrderService.calculateFinancials', () => {
  it('computes full price with no coupon', () => {
    const products = [makeProduct()];
    const config = makeConfig();
    const result = OrderService.calculateFinancials(makeOrderData(), products, config, []);

    expect(result.activeTotal).toBe(100);
    expect(result.discountRatio).toBe(1);
    expect(result.netMargin).toBe(60); // 100 - 40 cost
  });

  it('applies a valid percentage coupon', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'SAVE10', type: 'percentage', value: 10, status: 'active', usageCount: 0, usageLimit: 0 }],
    });
    const orderData = makeOrderData({ couponUsed: 'SAVE10' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBeCloseTo(90);
    expect(result.discountRatio).toBeCloseTo(0.9);
  });

  it('applies a valid flat coupon', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'FLAT20', type: 'flat', value: 20, status: 'active', usageCount: 0, usageLimit: 0 }],
    });
    const orderData = makeOrderData({ couponUsed: 'FLAT20' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBeCloseTo(80);
  });

  it('rejects an inactive coupon (no discount applied)', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'OLD', type: 'percentage', value: 50, status: 'inactive', usageCount: 0, usageLimit: 0 }],
    });
    const orderData = makeOrderData({ couponUsed: 'OLD' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBe(100); // No discount
  });

  it('rejects an expired coupon', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'EXPIRED', type: 'percentage', value: 50, status: 'active', usageCount: 0, usageLimit: 0, expiryDate: '2000-01-01' }],
    });
    const orderData = makeOrderData({ couponUsed: 'EXPIRED' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBe(100);
  });

  it('rejects a coupon that has hit its usage limit', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'USED', type: 'percentage', value: 50, status: 'active', usageCount: 5, usageLimit: 5 }],
    });
    const orderData = makeOrderData({ couponUsed: 'USED' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBe(100);
  });

  it('rejects coupon when order total is below minOrder', () => {
    const products = [makeProduct({ price: 50 })];
    const config = makeConfig({
      coupons: [{ code: 'BIG', type: 'percentage', value: 20, status: 'active', usageCount: 0, usageLimit: 0, minOrder: 100 }],
    });
    const orderData = makeOrderData({ items: [{ id: 'prod-1', name: 'Widget', quantity: 1, price: 50 }], couponUsed: 'BIG' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);

    expect(result.activeTotal).toBe(50);
  });

  it('clamps percentage coupon to 100%', () => {
    const products = [makeProduct()];
    const config = makeConfig({
      coupons: [{ code: 'FREE', type: 'percentage', value: 150, status: 'active', usageCount: 0, usageLimit: 0 }],
    });
    const result = OrderService.calculateFinancials(makeOrderData({ couponUsed: 'FREE' }), products, config, []);
    expect(result.activeTotal).toBeGreaterThanOrEqual(0);
  });

  it('adds shipping to the total', () => {
    const products = [makeProduct()];
    const config = makeConfig();
    const result = OrderService.calculateFinancials(makeOrderData({ shipping: 50 }), products, config, []);
    expect(result.activeTotal).toBe(150);
  });

  it('marks a product that no longer exists as invalid', () => {
    const products: any[] = []; // product not found
    const config = makeConfig();
    const result = OrderService.calculateFinancials(makeOrderData(), products, config, []);
    expect(result.enrichedItems[0].isValid).toBe(false);
  });

  it('marks a deactivated product as invalid', () => {
    const products = [makeProduct({ status: 'deactivated' })];
    const config = makeConfig();
    const result = OrderService.calculateFinancials(makeOrderData(), products, config, []);
    expect(result.enrichedItems[0].isValid).toBe(false);
  });

  it('calculates affiliate commission on assigned products', () => {
    const products = [makeProduct()];
    const config = makeConfig();
    const affiliate = { id: 'u1', role: 'Affiliate', affiliateId: 'AFF-1', commissionRate: 10, assignedProducts: ['prod-1'] };
    const result = OrderService.calculateFinancials(
      makeOrderData({ affiliateId: 'AFF-1' }),
      products,
      config,
      [affiliate as any]
    );
    expect(result.commissionAmount).toBeCloseTo(10); // 10% of 100
    expect(result.affiliateId).toBe('AFF-1');
  });

  it('does not apply commission when affiliate not found', () => {
    const products = [makeProduct()];
    const config = makeConfig();
    const result = OrderService.calculateFinancials(
      makeOrderData({ affiliateId: 'AFF-GHOST' }),
      products,
      config,
      []
    );
    expect(result.commissionAmount).toBe(0);
    expect(result.affiliateId).toBeNull();
  });

  it('client-supplied total cannot bypass coupon: ignores total in discount calculation', () => {
    const products = [makeProduct()]; // price = 100
    const config = makeConfig({
      coupons: [{ code: 'LEGIT', type: 'percentage', value: 10, status: 'active', usageCount: 0, usageLimit: 0 }],
    });
    // Attacker sends total=1 hoping for near-100% discount
    const orderData = makeOrderData({ total: 1, shipping: 0, couponUsed: 'LEGIT' });
    const result = OrderService.calculateFinancials(orderData, products, config, []);
    // Should be exactly 90 (10% off 100), not 1
    expect(result.activeTotal).toBeCloseTo(90);
  });
});

// ── detectDummy ───────────────────────────────────────────────────────────────

describe('OrderService.detectDummy', () => {
  it('flags order with "test" in customer name', () => {
    expect(OrderService.detectDummy({ customerName: 'Test User', email: 'a@b.com', phone: '1234567890', address: 'x', zip: '1' })).toBe(true);
  });
  it('flags order with "dummy" in email', () => {
    expect(OrderService.detectDummy({ customerName: 'Alice', email: 'dummy@example.com', phone: '1', address: 'y', zip: '2' })).toBe(true);
  });
  it('does not flag a normal order', () => {
    expect(OrderService.detectDummy({ customerName: 'Alice Smith', email: 'alice@store.com', phone: '9876543210', address: '123 Main St', zip: '110001' })).toBe(false);
  });
  it('is case-insensitive', () => {
    expect(OrderService.detectDummy({ customerName: 'FAKE NAME', email: 'real@email.com', phone: '1', address: 'a', zip: '1' })).toBe(true);
  });
});

// ── processStatusChange ───────────────────────────────────────────────────────

describe('OrderService.processStatusChange', () => {
  const config = makeConfig();

  const makeOrder = (overrides: any = {}): any => ({
    id: 'ORD-001',
    status: 'OPEN',
    items: [
      { id: 'i1', name: 'Widget', status: 'Pending', statusHistory: [] },
    ],
    statusHistory: [],
    ...overrides,
  });

  it('sets order to Processing when any item is Processing', () => {
    const order = makeOrder({ items: [{ id: 'i1', name: 'Widget', status: 'Processing', statusHistory: [] }] });
    const { updatedOrder } = OrderService.processStatusChange(order, { items: order.items }, config, 'Admin');
    expect(updatedOrder.status).toBe('Processing');
  });

  it('sets order to Shipped when any item is Shipped', () => {
    const order = makeOrder({ items: [{ id: 'i1', name: 'Widget', status: 'Shipped', statusHistory: [] }] });
    const { updatedOrder } = OrderService.processStatusChange(order, { items: order.items }, config, 'Admin');
    expect(updatedOrder.status).toBe('Shipped');
  });

  it('transitions to WAITING TO CLOSE when all items are Delivered', () => {
    const now = new Date().toISOString();
    const order = makeOrder({
      items: [{ id: 'i1', name: 'Widget', status: 'Delivered', deliveredAt: now, statusHistory: [] }],
    });
    const { updatedOrder } = OrderService.processStatusChange(order, { items: order.items }, config, 'Admin');
    expect(updatedOrder.status).toBe('WAITING TO CLOSE');
  });

  it('blocks non-SuperAdmin from changing a terminal item status', () => {
    const order = makeOrder({ items: [{ id: 'i1', name: 'Widget', status: 'Delivered', statusHistory: [] }] });
    const { error } = OrderService.processStatusChange(
      order,
      { items: [{ id: 'i1', name: 'Widget', status: 'Processing', statusHistory: [] }] },
      config,
      'Admin'
    );
    expect(error).toBeDefined();
    expect(error).toContain('terminal');
  });

  it('allows SuperAdmin to change a terminal item with an adminNote', () => {
    const order = makeOrder({ items: [{ id: 'i1', name: 'Widget', status: 'Delivered', statusHistory: [] }] });
    const { error, updatedOrder } = OrderService.processStatusChange(
      order,
      { items: [{ id: 'i1', name: 'Widget', status: 'Processing', statusHistory: [] }], adminNote: 'Reverting delivery' },
      config,
      'Super Admin'
    );
    expect(error).toBeUndefined();
    expect(updatedOrder.items?.[0]?.status).toBe('Processing');
  });

  it('requires adminNote to modify a CLOSED order (Admin)', () => {
    const order = makeOrder({ status: 'CLOSED' });
    const { error } = OrderService.processStatusChange(order, { status: 'OPEN' }, config, 'Admin');
    expect(error).toBeDefined();
  });

  it('sets CLOSED when all items are Cancelled', () => {
    const order = makeOrder({ items: [{ id: 'i1', name: 'Widget', status: 'Cancelled', statusHistory: [] }] });
    const { updatedOrder } = OrderService.processStatusChange(order, { items: order.items }, config, 'Admin');
    expect(updatedOrder.status).toBe('CLOSED');
  });
});
