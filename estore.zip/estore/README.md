# My Store — Full-Stack E-Commerce Platform

A high-performance, AI-integrated e-commerce platform with a React storefront and Node.js/Express backend. Everything is managed from a single admin panel after deployment.

---

## Technology Stack

| Layer | Technology |
|---|---|
| Frontend | React 19 + Tailwind CSS v4 + React Router v7 |
| Backend | Node.js 20 + Express 4 |
| Data | JSON file store with atomic writes and write-queue |
| AI | Google Gemini (optional) |
| Real-time | WebSockets (live visitor tracking) |
| Auth | JWT (24h) + bcryptjs + HMAC-signed CAPTCHA |
| Notifications | Nodemailer (email) + Twilio (WhatsApp) + Webhooks |

---

## First-Time Setup

### 1. Set Environment Variables

Copy `.env.example` to `.env` and fill in every value:

```bash
cp .env.example .env
```

Generate a strong JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

The server **refuses to start in production** if `JWT_SECRET`, `SUPER_ADMIN_PASSWORD`, or `SYSTEM_RESET_PASSWORD` are missing.

### 2. Build

```bash
npm install
npm run build
```

This produces a `dist/` folder containing:
- `dist/index.html` + all frontend assets (from Vite)
- `dist/server.js` (bundled Node.js server from esbuild)

### 3. Deploy

Upload to your server:
- `dist/` folder
- `data/` folder (empty JSON files — the server seeds them on first boot)
- `public/` folder (for uploaded images)
- `package.json`
- `.env`

### 4. Start

```bash
NODE_ENV=production node dist/server.js
```

Or with a process manager:
```bash
npm install -g pm2
pm2 start dist/server.js --name mystore
pm2 save
pm2 startup
```

---

## Reverse Proxy (Required for HTTPS)

The Node.js server speaks HTTP on port 3000. You **must** put Nginx or Caddy in front for TLS. The app automatically redirects HTTP → HTTPS when it detects the `X-Forwarded-Proto: http` header from the proxy.

### Nginx example

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Caddy example (automatic HTTPS)

```
yourdomain.com {
    reverse_proxy localhost:3000
}
```

---

## Hostinger (Recommended for non-developers)

1. Choose **Business Web Hosting** or **VPS**.
2. Run `npm run build` locally, then zip: `dist/`, `data/`, `public/`, `package.json`, `.env`.
3. Upload and extract to `public_html/` via File Manager.
4. In hPanel → **Advanced** → **Node.js**:
   - Application Root: `public_html/`
   - Startup File: `dist/server.js`
   - Node.js Version: `20.x`
5. Add Environment Variables (same as `.env` contents).
6. Click **NPM Install**, then **Save and Restart**.

---

## Admin Login

URL: `yourdomain.com/logintosft`  
Email: `super@example.com`  
Password: the value you set for `SUPER_ADMIN_PASSWORD`

All products, categories, orders, affiliates, and store settings are configured from the admin panel after login. The data files start empty — nothing needs to be pre-loaded.

---

## Data & Backups

All store data lives in the `data/` folder as JSON files. To back up:

1. Download the `data/` folder from your server (weekly recommended).
2. Download `public/uploads/` for product images.

To restore: upload both folders to the same paths and restart the server.

---

## API Pagination

All list endpoints support pagination:

| Parameter | Default | Max | Description |
|---|---|---|---|
| `page` | 1 | — | Page number |
| `limit` | 50 | 200 | Records per page |
| `limit=0` | — | — | Return all records |

Response shape:
```json
{ "data": [...], "total": 150, "page": 2, "pages": 3 }
```

---

## Health Check

```
GET /api/v1/health
```

Returns `200` with `{ "status": "ok", "storage": "writable" }` when the server is running and the data directory is writable. Returns `503` if storage is unavailable — useful for uptime monitors.

---

## FAQ

**Why is my site showing "Cannot GET /"?**  
Make sure the Startup File is `dist/server.js` (not `server.ts`) and that you ran `npm run build` before deploying.

**How do I change the admin password?**  
From the admin panel → System Configuration → Change Password. Or update `SUPER_ADMIN_PASSWORD` in your `.env` and restart.

**Can I run this on shared hosting?**  
Only if the host supports Node.js 20+. Standard shared Linux hosting (cPanel without Node.js) will not work.
